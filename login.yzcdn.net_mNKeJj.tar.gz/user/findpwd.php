<?php
$is_defend=true;
include("../includes/common.php");
if($islogin2==1){
	exit("<script language='javascript'>alert('您已登录！');window.location.href='./';</script>");
}

$csrf_token = md5(mt_rand(0,999).time());
$_SESSION['csrf_token'] = $csrf_token;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="utf-8" />
	<title>找回密码 - <?php echo $conf['sitename']?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link href="<?php echo $cdnpublic?>twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>jqueryui/1.12.1/jquery-ui.min.css" rel="stylesheet">
	<link href="<?php echo $cdnpublic?>font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>dripicons/2.0.0/webfont.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>metisMenu/3.0.7/metisMenu.min.css" rel="stylesheet" type="text/css" />
	<link href="./assets/css/app.min.css" rel="stylesheet" type="text/css" />
	<link href="./assets/css/captcha.css" rel="stylesheet" type="text/css" />
</head>

<body class="account-body accountbg">

	<!-- Log In page -->
	<div class="container">
		<div class="row vh-100 ">
			<div class="col-12 align-self-center">
				<div class="auth-page">
					<div class="card auth-card shadow-lg">
						<div class="card-body">
							<div class="px-3">
								<div class="auth-logo-box">
									<a href="../" class="logo logo-admin"><img src="../assets/img/logo.png" height="55" alt="logo" class="auth-logo"></a>
								</div><!--end auth-logo-box-->
								
								<div class="text-center auth-logo-text">
									<h4 class="mt-0 mb-3 mt-5">找回密码</h4>
									<p class="text-muted mb-0">请输入您的账号信息</p>  
								</div> <!--end auth-logo-text-->  

								
								<form class="form-horizontal auth-form my-4" action="reg.php">
								<input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>"><input type="hidden" name="type" value="<?php echo $conf['verifytype']==1?'phone':'email';?>">

									<?php if($conf['verifytype']==1){?>
									<div class="form-group">
										<div class="input-group mb-3"> 
											<span class="auth-form-icon">
												<i class="dripicons-phone"></i> 
											</span>
											<input type="text" class="form-control" id="account" name="account" placeholder="手机号码">
										</div>
									</div><!--end form-group-->
									<div class="form-group">
										<div class="input-group mb-3"> 
											<input type="text" class="form-control" id="code" name="code" placeholder="短信验证码" style="border-radius: 30px 0 0 30px;">
											<span class="input-group-append">
                                                <button type="button" class="btn btn-outline-secondary btn-round" style="border: 1px solid #ced4da;" id="sendcode">获取验证码</button>
                                            </span>
										</div>
									</div><!--end form-group-->
									<?php }else{?>
									<div class="form-group">
										<div class="input-group mb-3">
											<span class="auth-form-icon">
												<i class="dripicons-mail"></i> 
											</span>
											<input type="email" class="form-control" id="account" name="account" placeholder="邮箱">
										</div>                                    
									</div><!--end form-group-->
									<div class="form-group">
										<div class="input-group mb-3"> 
											<input type="text" class="form-control" id="code" name="code" placeholder="邮箱验证码" style="border-radius: 30px 0 0 30px;">
											<span class="input-group-append">
                                                <button type="button" class="btn btn-outline-secondary btn-round" style="border: 1px solid #ced4da;" id="sendcode">获取验证码</button>
                                            </span>
										</div>
									</div><!--end form-group-->
									<?php }?>

									<div class="form-group">
										<div class="input-group mb-3"> 
											<span class="auth-form-icon">
												<i class="dripicons-lock"></i> 
											</span>
											<input type="password" class="form-control" id="pwd" name="pwd" placeholder="请输入新密码">
										</div>
									</div><!--end form-group--> 

									<div class="form-group">
										<div class="input-group mb-3"> 
											<span class="auth-form-icon">
												<i class="dripicons-lock-open"></i> 
											</span>
											<input type="password" class="form-control" id="pwd2" name="pwd2" placeholder="请重新输入密码">
										</div>
									</div><!--end form-group--> 

		
									<div class="form-group mb-0 row">
										<div class="col-12 mt-2">
											<button class="btn btn-gradient-primary btn-round btn-block waves-effect waves-light" type="button" id="submit">确认提交 <i class="far fa-check-circle ml-1"></i></button>
										</div><!--end col--> 
									</div> <!--end form-group-->                           
								</form><!--end form-->
							</div><!--end /div-->
							
							<div class="m-3 text-center text-muted">
								<p class=""><a href="./login.php" class="text-primary ml-2">返回登录</a></p>
							</div>
						</div><!--end card-body-->
					</div><!--end card-->
				</div><!--end auth-card-->
			</div><!--end col-->           
		</div><!--end row-->
	</div><!--end container-->
	<!-- End Log In page -->

	<script src="<?php echo $cdnpublic?>jquery/3.4.1/jquery.min.js"></script>
	<script src="<?php echo $cdnpublic?>jqueryui/1.12.1/jquery-ui.min.js"></script>
	<script src="<?php echo $cdnpublic?>twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo $cdnpublic?>metisMenu/3.0.7/metisMenu.min.js"></script>
	<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
	<script src="<?php echo $cdnpublic?>node-waves/0.7.6/waves.js"></script>
	<script src="<?php echo $cdnpublic?>jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
	<script src="./assets/js/app.js"></script>
	<script src="//static.geetest.com/static/tools/gt.js"></script>
<script>
function invokeSettime(obj){
    var countdown=60;
    settime(obj);
    function settime(obj) {
        if (countdown == 0) {
            $(obj).attr("data-lock", "false");
            $(obj).text("获取验证码");
            countdown = 60;
            return;
        } else {
			$(obj).attr("data-lock", "true");
            $(obj).attr("disabled",true);
            $(obj).text("(" + countdown + ") s 重新发送");
            countdown--;
        }
        setTimeout(function() {
                    settime(obj) }
                ,1000)
    }
}
var handlerEmbed = function (captchaObj) {
	var sendto,type;
	captchaObj.onReady(function () {
		$("#wait").hide();
	}).onSuccess(function () {
		var result = captchaObj.getValidate();
		if (!result) {
			return alert('请完成验证');
		}
		var ii = layer.load(2, {shade:[0.1,'#fff']});
		$.ajax({
			type : "POST",
			url : "ajax.php?act=sendcode2",
			data : {type:type,sendto:sendto,geetest_challenge:result.geetest_challenge,geetest_validate:result.geetest_validate,geetest_seccode:result.geetest_seccode},
			dataType : 'json',
			success : function(data) {
				layer.close(ii);
				if(data.code == 0){
					new invokeSettime("#sendsms");
					layer.msg('发送成功，请注意查收！');
				}else{
					layer.alert(data.msg);
					captchaObj.reset();
				}
			} 
		});
	});
	$('#sendcode').click(function () {
		if ($(this).attr("data-lock") === "true") return;
		type = $("input[name='type']").val();
		sendto=$("input[name='account']").val();
		if(type=='phone'){
			if(sendto==''){layer.alert('手机号码不能为空！');return false;}
			if(sendto.length!=11){layer.alert('手机号码不正确！');return false;}
		}else{
			if(sendto==''){layer.alert('邮箱不能为空！');return false;}
			var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
			if(!reg.test(sendto)){layer.alert('邮箱格式不正确！');return false;}
		}
		captchaObj.verify();
	});
};
$(document).ready(function(){
	$("#submit").click(function(){
		if ($(this).attr("data-lock") === "true") return;
		var type=$("input[name='type']").val();
		var account=$("input[name='account']").val();
		var code=$("input[name='code']").val();
		var pwd=$("input[name='pwd']").val();
		var pwd2=$("input[name='pwd2']").val();
		if(account=='' || code=='' || pwd=='' || pwd2==''){layer.alert('请确保各项不能为空！');return false;}
		if(pwd!=pwd2){layer.alert('两次输入密码不一致！');return false;}
		if(type=='phone'){
			if(account.length!=11){layer.alert('手机号码不正确！');return false;}
		}else{
			var reg = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
			if(!reg.test(account)){layer.alert('邮箱格式不正确！');return false;}
		}
		var csrf_token=$("input[name='csrf_token']").val();
		var ii = layer.load(2, {shade:[0.1,'#fff']});
		$(this).attr("data-lock", "true");
		$.ajax({
			type : "POST",
			url : "ajax.php?act=findpwd",
			data : {type:type,account:account,code:code,pwd:pwd,csrf_token:csrf_token},
			dataType : 'json',
			success : function(data) {
				$("#submit").attr("data-lock", "false");
				layer.close(ii);
				if(data.code == 1){
					layer.alert(data.msg, {icon: 1}, function(){window.location.href="login.php"});
				}else{
					layer.alert(data.msg);
				}
			}
		});
	});
	$.ajax({
		url: "ajax.php?act=captcha&t=" + (new Date()).getTime(),
		type: "get",
		dataType: "json",
		success: function (data) {
			console.log(data);
			initGeetest({
				width: '100%',
				gt: data.gt,
				challenge: data.challenge,
				new_captcha: data.new_captcha,
				product: "bind",
				offline: !data.success
			}, handlerEmbed);
		}
	});
});
</script>
</body>
</html>