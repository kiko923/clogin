<?php
namespace plugins;

use Exception;

class alipay {

	static public $info = [
		'name'        => 'alipay',
		'showname'    => '支付宝',
		'link'        => 'https://open.alipay.com/',
		'sort'        => 13,
		'abroad'      => false,
		'input' => [
			'appid' => [
				'name' => '应用ID',
				'type' => 'input',
				'note' => '',
			],
			'publickey' => [
				'name' => '支付宝公钥',
				'type' => 'textarea',
				'note' => '如果用公钥证书模式此处需留空',
			],
			'privatekey' => [
				'name' => '应用私钥',
				'type' => 'textarea',
				'note' => '',
			],
			'usertype' => [
				'name' => '用户标识字段',
				'type' => 'select',
				'options' => ['UserId（默认）','OpenId'],
				'note' => '',
			],
		],
	];

	private $config;

	public function __construct($config)
	{
		$this->config = $config;
	}

	public function help(){
		global $siteurl;
		return '<p>●&nbsp;<a href="https://openhome.alipay.com/platform/appManage.htm" target="_blank" rel="noreferrer">申请地址</a>，应用内添加功能"获取会员信息"，授权回调地址填写：'.$siteurl.'return.php</p><p>●&nbsp;<b>如用户标识字段选OpenId，则不能随意更换应用，否则之前已登录的用户将全部失效！</b>推荐用UserId，但目前新创建的应用只能用OpenId</p><p>●&nbsp;如果使用公钥证书模式，需将<font color="red">应用公钥证书、支付宝公钥证书、支付宝根证书</font>3个crt文件放置于<font color="red">/includes/</font>文件夹。</p>';
	}

	public function login($state){
		global $siteurl;
		return $siteurl.'jump.php?state='.urlencode($state);
	}

	public function jump($state, $type = 0){
		global $siteurl;

		if (checkmobile()==false || strpos($_SERVER['HTTP_USER_AGENT'], 'AlipayClient')) {
			$alipay_config = $this->getConfig();
			$oauth = new \Alipay\AlipayOauthService($alipay_config);
			if ($type==1) {
				$scope = 'auth_user,auth_base';
			} else {
				$scope = 'auth_base';
			}
			$redirect_uri = $siteurl.'return.php';
			$oauth->oauth($redirect_uri, $state, $scope);
		}else{
			return PAGE_ROOT.'alipaywap.php';
		}
	}

	public function callback($code, $type = 0, $mode = 0){

		$alipay_config = $this->getConfig();
		try{
			$oauth = new \Alipay\AlipayOauthService($alipay_config);
			$res = $oauth->getToken($code);
		}catch(Exception $e){
			throw new Exception('支付宝快捷登录失败 '.$e->getMessage());
		}

		if($this->config['usertype'] == 1){
			if(empty($res['open_id'])) throw new Exception('OpenId字段为空');
			$user_id = $res['open_id'];
		}else{
			if(empty($res['user_id'])) throw new Exception('UserId字段为空');
			$user_id = $res['user_id'];
		}
		$access_token=$res['access_token'];
		$result = ['access_token'=>$access_token,'social_uid'=>$user_id];
		if($type==1){
			$userinfo = $oauth->userinfo($access_token);
			$result['faceimg'] = $userinfo['avatar'];
			$result['nickname'] = $userinfo['nick_name'];
			$gender_arr = ['M'=>'男', 'F'=>'女', 'm'=>'男', 'f'=>'女'];
			$result['location'] = $userinfo['province'].$userinfo['city'];
			$result['gender'] = $gender_arr[$userinfo['gender']];
		}
		return $result;
	}

	private function getConfig(){
		$alipay_config = [
			'app_id' => $this->config['appid'],
			'alipay_public_key' => $this->config['publickey'],
			'app_private_key' => $this->config['privatekey'],
		];
		if(empty($alipay_config['alipay_public_key']) && file_exists(SYSTEM_ROOT.'appCertPublicKey_'.$alipay_config['app_id'].'.crt')){
			$alipay_config['cert_mode'] = true;
			$alipay_config['app_cert_path'] = SYSTEM_ROOT.'appCertPublicKey_'.$alipay_config['app_id'].'.crt';
			$alipay_config['alipay_cert_path'] = SYSTEM_ROOT.'alipayCertPublicKey_RSA2.crt';
			$alipay_config['root_cert_path'] = SYSTEM_ROOT.'alipayRootCert.crt';
		}
		return $alipay_config;
	}

}