<?php
namespace plugins;

use Exception;

class qq {

	static public $info = [
		'name'        => 'qq',
		'showname'    => 'ＱＱ',
		'link'        => 'https://connect.qq.com/',
		'sort'        => 11,
		'abroad'      => false,
		'input' => [
			'appid' => [
				'name' => 'AppId',
				'type' => 'input',
				'note' => '',
			],
			'appkey' => [
				'name' => 'AppKey',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const VERSION = "2.0";
	const GET_AUTH_CODE_URL = "https://graph.qq.com/oauth2.0/authorize";
	const GET_ACCESS_TOKEN_URL = "https://graph.qq.com/oauth2.0/token";
	const GET_OPENID_URL = "https://graph.qq.com/oauth2.0/me";
	const GET_USER_INFO_URL = "https://graph.qq.com/user/get_user_info";

	private $appid;
	private $appkey;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->appid = $config['appid'];
		$this->appkey = $config['appkey'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;<a href="https://connect.qq.com/" target="_blank" rel="noreferrer">QQ互联申请地址</a>，回调地址填写：'.$siteurl.'return.php<br/>●&nbsp;<b>注意：配置好之后请勿随意更换应用，否则之前已登录的用户将全部失效！</b>';
	}

	public function login($state){
		$param = [
			"response_type" => "code",
			"client_id" => $this->appid,
			"redirect_uri" => $this->callback,
			"state" => $state
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		$access_token = $this->get_access_token($code);
		$openid = $this->get_openid($access_token);

		$result = [
			'access_token' => $access_token,
			'social_uid' => $openid,
		];

		if($type == 1){
			$userinfo = $this->get_userinfo($access_token, $openid);
			$faceimg = $userinfo['figureurl_qq_2']?$userinfo['figureurl_qq_2']:$userinfo['figureurl_qq_1'];
			$faceimg = str_replace('http://','https://',$faceimg);
			$result['faceimg'] = $faceimg;
			$result['nickname'] = $userinfo['nickname'];
			$result['gender'] = $userinfo['gender'];
		}

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"grant_type" => "authorization_code",
			"client_id" => $this->appid,
			"redirect_uri" => $this->callback,
			"client_secret" => $this->appkey,
			"code" => $code
		];

		$url = self::GET_ACCESS_TOKEN_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		if(strpos($response, "callback") !== false){
			$arr = jsonp_decode($response, true);
		}else{
			parse_str($response, $arr);
		}
		if(isset($arr['access_token'])){
			return $arr['access_token'];
		}elseif(isset($arr['error'])){
			throw new Exception('获取access_token失败 ['.$arr['error'].']'.$arr['error_description']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_openid($access_token){
		$param = [
			"access_token" => $access_token
		];

		$url = self::GET_OPENID_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = jsonp_decode($response, true);
		if(isset($arr['openid'])){
			return $arr['openid'];
		}elseif(isset($arr['error'])){
			throw new Exception('获取openid失败 ['.$arr['error'].']'.$arr['error_description']);
		}else{
			throw new Exception('获取openid失败，原因未知');
		}
	}

	private function get_userinfo($access_token, $openid){
		$param = [
			"access_token" => $access_token,
			"oauth_consumer_key" => $this->appid,
			"openid" => $openid
		];

		$url = self::GET_USER_INFO_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['ret']) && $arr['ret'] == 0){
			return $arr;
		}elseif(isset($arr['msg'])){
			throw new Exception('获取用户信息失败 ['.$arr['ret'].']'.$arr['msg']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}