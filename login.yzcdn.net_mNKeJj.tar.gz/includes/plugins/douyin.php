<?php
namespace plugins;

use Exception;

class douyin {

	static public $info = [
		'name'        => 'douyin',
		'showname'    => '抖音',
		'link'        => 'https://developer.open-douyin.com/',
		'sort'        => 16,
		'abroad'      => false,
		'input' => [
			'client_key' => [
				'name' => 'Client Key',
				'type' => 'input',
				'note' => '',
			],
			'client_secret' => [
				'name' => 'Client Secret',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://open.douyin.com/platform/oauth/connect";
	const GET_ACCESS_TOKEN_URL = "https://open.douyin.com/oauth/access_token/";
	const GET_USER_INFO_URL = "https://open.douyin.com/oauth/userinfo/";

	private $client_key;
	private $client_secret;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->client_key = $config['client_key'];
		$this->client_secret = $config['client_secret'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;<a href="https://developer.open-douyin.com/" target="_blank" rel="noreferrer">申请地址</a>，创建网站应用，授权回调地址填写：'.$siteurl.'return.php<br/>●&nbsp;<b>注意：配置好之后请勿随意更换应用，否则之前已登录的用户将全部失效！</b>';
	}

	public function login($state){
		$param = [
			"client_key" => $this->client_key,
			"response_type" => "code",
			"scope" => 'user_info',
			"redirect_uri" => $this->callback,
			"state" => $state
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		[$access_token, $open_id] = $this->get_access_token($code);
		$userinfo = $this->get_userinfo($access_token, $open_id);

		$result = [
			'access_token' => $access_token,
			'social_uid' => $open_id,
			'faceimg' => $userinfo['avatar'],
			'nickname' => $userinfo['nickname'],
		];

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"grant_type" => "authorization_code",
			"code" => $code,
			"client_key" => $this->client_key,
			"client_secret" => $this->client_secret
		];

		$url = self::GET_ACCESS_TOKEN_URL;
		$response = get_curl_api(self::$info['abroad'], $url, json_encode($param), 0, ['Content-Type: application/json']);
		$arr = json_decode($response, true);
		if(isset($arr['data']['error_code']) && $arr['data']['error_code']==0){
			return [$arr['data']['access_token'], $arr['data']['open_id']];
		}elseif(isset($arr['data']['error_code'])){
			throw new Exception('获取access_token失败 ['.$arr['data']['error_code'].']'.$arr['data']['description']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_userinfo($access_token, $open_id){
		$param = [
			'access_token' => $access_token,
			"open_id" => $open_id
		];

		$url = self::GET_USER_INFO_URL;
		$response = get_curl_api(self::$info['abroad'], $url, http_build_query($param));
		$arr = json_decode($response, true);
		if(isset($arr['data']['error_code']) && $arr['data']['error_code']==0){
			return $arr['data'];
		}elseif(isset($arr['data']['error_code'])){
			throw new Exception('获取用户信息失败 ['.$arr['data']['error_code'].']'.$arr['data']['description']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}