<?php
namespace plugins;

use Exception;

class microsoft {

	static public $info = [
		'name'        => 'microsoft',
		'showname'    => '微软',
		'link'        => 'https://apps.dev.microsoft.com/',
		'sort'        => 18,
		'abroad'      => true,
		'input' => [
			'client_id' => [
				'name' => '应用程序ID',
				'type' => 'input',
				'note' => '',
			],
			'client_secret' => [
				'name' => '应用程序密码',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize";
	const GET_ACCESS_TOKEN_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/token";
	const GET_USER_INFO_URL = "https://graph.microsoft.com/v1.0/me";

	private $client_id;
	private $client_secret;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->client_id = $config['client_id'];
		$this->client_secret = $config['client_secret'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;<a href="https://aka.ms/appregistrations" target="_blank" rel="noreferrer">申请地址</a>，受支持的帐户类型
		必须选"所有 Microsoft 帐户用户"，重定向URI填写：'.$siteurl.'return.php';
	}

	public function login($state){
		$param = [
			"response_type" => "code",
			"client_id" => $this->client_id,
			"redirect_uri" => $this->callback,
			"scope" => 'User.Read',
			"response_mode" => "query",
			"state" => $state,
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		$access_token = $this->get_access_token($code);
		$userinfo = $this->get_userinfo($access_token);

		$result = [
			'access_token' => $access_token,
			'social_uid' => $userinfo['id'],
			'faceimg' => $userinfo['photo'],
			'nickname' => $userinfo['displayName'],
		];

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"grant_type" => "authorization_code",
			"code" => $code,
			"client_id" => $this->client_id,
			"client_secret" => $this->client_secret,
			"redirect_uri" => $this->callback
		];

		$url = self::GET_ACCESS_TOKEN_URL;
		$response = get_curl_api(self::$info['abroad'], $url, http_build_query($param));
		$arr = json_decode($response, true);
		if(isset($arr['access_token'])){
			return $arr['access_token'];
		}elseif(isset($arr['error'])){
			throw new Exception('获取access_token失败 ['.$arr['error'].']'.$arr['error_description']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_userinfo($access_token){
		$url = self::GET_USER_INFO_URL;
		$response = get_curl_api(self::$info['abroad'], $url, 0, 0, ['Authorization: Bearer '.$access_token]);
		$arr = json_decode($response, true);
		if(isset($arr['id'])){
			return $arr;
		}elseif(isset($arr['error'])){
			throw new Exception('获取用户信息失败 '.$arr['error']['message']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}