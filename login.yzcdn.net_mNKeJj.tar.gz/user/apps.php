<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='应用列表';
include './head.php';

function display_status($status,$appid){
	if($status == 3){
		return '<a href="javascript:auditApp('.$appid.')" title="点击查看原因"><font color=red><i class="fa fa-exclamation-circle"></i>未通过</font></a>';
	}elseif($status == 2){
		return '<font color=orange><i class="fa fa-asterisk"></i>待审核</font>';
	}elseif($status == 1){
		return '<font color=green><i class="fa fa-check-circle"></i>开启</font>';
	}else{
		return '<font color=red><i class="fa fa-times-circle"></i>关闭</font>';
	}
}

if(isset($_GET['kw']) && !empty($_GET['kw'])){
	$kw = trim(daddslashes(strip_tags($_GET['kw'])));
	$sql = " (name LIKE '%{$kw}%' OR appid='$kw') AND uid='$uid' AND status<4";
	$link = '&kw='.$kw;
	$numrows=$DB->getColumn("SELECT count(*) FROM pre_apps WHERE{$sql}");
	$con = '包含'.$kw.'的共有'.$numrows.'个应用';
}else{
	$sql = " uid='$uid' AND status<4";
	$numrows=$DB->getColumn("SELECT count(*) FROM pre_apps WHERE{$sql}");
	$con = '您当前共有'.$numrows.'个应用';
}

$pagesize=20;
$pages=ceil($numrows/$pagesize);
$page=isset($_GET['page'])?intval($_GET['page']):1;
$offset=$pagesize*($page - 1);

$list=$DB->getAll("SELECT * FROM pre_apps WHERE{$sql} order by appid desc limit $offset,$pagesize");
?>
<style>
.table tbody tr>td:nth-child(1){min-width:120px;}
.table tbody tr>td:nth-child(3){min-width:100px;}
.table tbody tr>td:nth-child(4){min-width:100px;}
.table tbody tr>td:nth-child(5){min-width:80px;}
.table tbody tr>td:nth-child(6){min-width:180px;}
@media (max-width: 576px){.contents{padding: 0;}}
</style>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active">应用列表</li>
					</ol>
				</div>
				<h4 class="page-title">应用列表</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-12 contents">
			<div class="card">
				<div class="card-body">
					<h4 class="mt-0 header-title">您当前共有<?php echo $numrows?>个应用<a href="appadd.php" class="btn btn-gradient-success waves-effect waves-light float-right" style="margin-top: -8px;"><i class="fas fa-plus"></i> 创建应用</a></h4>
					<p></p>

					<div class="table-responsive">
						<table class="table mb-0 table-centered">
							<thead>
							<tr>
								<th>应用名称</th>
								<th>APPID</th>
								<th>回调域名</th>
								<th>创建时间</th>
								<th>应用状态</th>
								<th>操作</th>
							</tr>
							</thead>
							<tbody>
<?php foreach($list as $row){
	$domains=$DB->getAll("select * from pre_appdomain where appid='{$row['appid']}'");
	$domaintext = '';
	$i=0;
	foreach($domains as $domain){
		$domaintext .= $domain['domain'].'<br/>';$i++;
		if($i==3){
			$domaintext = substr($domaintext,0,-5);
			$domaintext .= '<a href="javascript:showDomains('.$row['appid'].')">(...'.count($domains).')</a>';
            break;
        }
	}
?>
							<tr>
								<td><div class="avatar-box thumb-lg align-self-center mr-2 d-none d-sm-inline-block"><span class="avatar-title bg-primary rounded-circle"><i class="fas fa-cube"></i></span></div>
									<span class="font-weight-bold"><?php echo $row['name']?></span>
								</td>
								<td><?php echo $row['appid']?></td>
								<td><?php echo $domaintext?></td>
								<td><?php echo date("Y-m-d",strtotime($row['addtime']))?></td>
								<td><?php echo display_status($row['status'],$row['appid'])?></td>
								<td>
								<a href="appinfo.php?appid=<?php echo $row['appid']?>" class="btn btn-gradient-primary waves-effect waves-light btn-sm mb-1">应用详情</a>
								<a href="appstat.php?appid=<?php echo $row['appid']?>" class="btn btn-gradient-warning waves-effect waves-light btn-sm mb-1">应用统计</a><br/>
								<a href="accounts.php?appid=<?php echo $row['appid']?>" class="btn btn-gradient-pink waves-effect waves-light btn-sm">账号列表</a>
								<a href="logs.php?appid=<?php echo $row['appid']?>" class="btn btn-gradient-purple waves-effect waves-light btn-sm">记录列表</a>
								</td>
							</tr>
<?php }?>
							</tbody>
						</table><!--end /table-->
					</div><!--end /tableresponsive-->
<?php echo'<nav aria-label="Page navigation example"><ul class="pagination justify-content-center">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li class="page-item"><a class="page-link" href="apps.php?page='.$first.$link.'">首页</a></li>';
echo '<li class="page-item"><a class="page-link" href="apps.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="page-item disabled"><a class="page-link">首页</a></li>';
echo '<li class="page-item disabled"><a class="page-link">&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li class="page-item"><a class="page-link" href="apps.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="page-item disabled"><a class="page-link">'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li class="page-item"><a class="page-link" href="apps.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li class="page-item"><a class="page-link" href="apps.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li class="page-item"><a class="page-link" href="apps.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="page-item disabled"><a class="page-link">&raquo;</a></li>';
echo '<li class="page-item disabled"><a class="page-link">尾页</a></li>';
}
echo'</ul></nav>';?>
				</div><!--end card-body-->
			</div>
		</div><!--end col-->
	</div><!--end row-->

</div><!-- container -->

<?php include 'foot.php';?>
<script>
function showDomains(appid) {
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'GET',
		url : 'ajax2.php?act=showDomains&appid='+appid,
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				var item = '<table class="table table-condensed table-hover">';
				$.each(data.data, function(k,v){
					item += '<tr><td>'+v+'</td></tr>';
				});
				item += '</table>';
				layer.open({
				  type: 1,
				  shadeClose: true,
				  title: '回调域名白名单',
				  skin: 'layui-layer-rim',
				  content: item
				});
			}else{
				layer.msg(data.msg, {icon:2, time:1500});
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
function auditApp(appid) {
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'GET',
		url : 'ajax2.php?act=getAppInfo&appid='+appid,
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.note, {icon:0, title:'查看审核不通过原因'});
			}else{
				layer.msg(data.msg, {icon:2, time:1500});
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
</script>