<?php
namespace plugins;

use Exception;

class google {

	static public $info = [
		'name'        => 'google',
		'showname'    => '谷歌',
		'link'        => 'https://www.google.com/',
		'sort'        => 17,
		'abroad'      => true,
		'input' => [
			'client_id' => [
				'name' => 'Client ID',
				'type' => 'input',
				'note' => '',
			],
			'client_secret' => [
				'name' => 'Client Secret',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://accounts.google.com/o/oauth2/auth";
	const GET_ACCESS_TOKEN_URL = "https://oauth2.googleapis.com/token";
	const GET_USER_INFO_URL = "https://www.googleapis.com/oauth2/v1/userinfo";

	private $client_id;
	private $client_secret;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->client_id = $config['client_id'];
		$this->client_secret = $config['client_secret'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;<a href="https://console.cloud.google.com/apis/credentials/consent" target="_blank" rel="noreferrer">申请地址</a>，凭据里面授权重定向URI填写：'.$siteurl.'return.php';
	}

	public function login($state){
		$param = [
			"response_type" => "code",
			"access_type" => "offline",
			"client_id" => $this->client_id,
			"redirect_uri" => $this->callback,
			"scope" => 'https://www.googleapis.com/auth/userinfo.profile',
			"state" => $state,
			"approval_prompt" => "auto"
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		$access_token = $this->get_access_token($code);
		$userinfo = $this->get_userinfo($access_token);

		$result = [
			'access_token' => $access_token,
			'social_uid' => $userinfo['id'],
			'faceimg' => $userinfo['picture'],
			'nickname' => $userinfo['name'],
			'location' => $userinfo['location'],
		];

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"grant_type" => "authorization_code",
			"code" => $code,
			"client_id" => $this->client_id,
			"client_secret" => $this->client_secret,
			"redirect_uri" => $this->callback
		];

		$url = self::GET_ACCESS_TOKEN_URL;
		$response = get_curl_api(self::$info['abroad'], $url, http_build_query($param));
		$arr = json_decode($response, true);
		if(isset($arr['access_token'])){
			return $arr['access_token'];
		}elseif(isset($arr['error'])){
			throw new Exception('获取access_token失败 ['.$arr['error'].']'.$arr['error_description']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_userinfo($access_token){
		$param = [
			"access_token" => $access_token
		];

		$url = self::GET_USER_INFO_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['id'])){
			return $arr;
		}elseif(isset($arr['error'])){
			throw new Exception('获取用户信息失败 '.$arr['error']['message']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}