<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='应用登录记录列表';
include './head.php';

$appid=intval($_GET['appid']);
$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");

$logintype = [];
$loginselect = '';
$rs = $DB->getAll("SELECT name,showname FROM pre_type ORDER BY sort ASC");
foreach($rs as $row){
	$logintype[$row['name']] = $row['showname'];
	$loginselect .= '<option value="'.$row['name'].'">'.$row['showname'].'</option>';
}
unset($rs);

?>
<style>
@media (max-width: 576px){.contents{padding: 0;}}
#loglist table>tbody>tr>td{overflow: hidden;text-overflow: ellipsis;white-space: nowrap;max-width:300px;}
.form-inline .form-control {
    display: inline-block;
    width: auto;
    vertical-align: middle;
}
.form-inline .form-group {
    display: inline-block;
    margin-bottom: 0;
    vertical-align: middle;
}
#accountdetail .title{word-break:keep-all;}
#accountdetail .content{word-break:break-all;}
</style>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="./apps.php">应用列表</a></li>
						<li class="breadcrumb-item active">应用登录记录列表</li>
					</ol>
				</div>
				<h4 class="page-title">应用登录记录列表</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-12 contents">
<?php if(!$row){?><div class="card">
				<div class="card-body">
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<strong>该应用不存在</strong>
					</div>
				</div>
				</div>
<?php }else{?>
			<div class="card">
				<div class="card-body">
<form onsubmit="return searchOrder()" method="GET" class="form-inline"><input type="hidden" name="appid" value="<?php echo $appid?>">
  <div class="form-group ml-2">
    <label>搜索</label>
  </div>
  <div class="form-group ml-2">
    <input type="text" class="form-control" name="kw" placeholder="第三方账号UID或网站域名" style="width: 240px;">
  </div>
  <div class="form-group ml-2">
	<select name="type" class="form-control"><option value="0">所有登录方式</option><?php echo $loginselect?></select>
  </div>
  <div class="form-group ml-2">
	<button class="btn btn-primary" type="submit"><i class="fas fa-search"></i>搜索</button>&nbsp;
	<a href="javascript:searchClear()" class="btn btn-light"><i class="fas fa-redo"></i>重置</a>
  </div>
</form>
				<div id="listTable"></div>
				</div><!--end card-body-->
			</div>
<?php }?>
		</div><!--end col-->
	</div><!--end row-->

</div><!-- container -->

<?php include 'foot.php';?>
<script>
var logintype = <?php echo json_encode($logintype)?>;
function listTable(query){
	var url = window.document.location.href.toString();
	var queryString = url.split("?")[1];
	query = query || queryString;
	if(query == 'start' || query == undefined){
		query = '';
		history.replaceState({}, null, './logs.php');
	}else if(query != undefined){
		history.replaceState({}, null, './logs.php?'+query);
	}
	layer.closeAll();
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'GET',
		url : 'logs-table.php?'+query,
		dataType : 'html',
		cache : false,
		success : function(data) {
			layer.close(ii);
			$("#listTable").html(data)
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
function searchOrder(){
	var appid=$("input[name='appid']").val();
	var kw=$("input[name='kw']").val();
	var type=$("select[name='type']").val();
	if(kw==''){
		listTable('appid='+appid+'&type='+type);
	}else{
		listTable('appid='+appid+'&kw='+kw+'&type='+type);
	}
	return false;
}
function searchClear(){
	var appid=$("input[name='appid']").val();
	$("input[name='kw']").val('');
	$("select[name='type']").val(0);
	listTable('appid='+appid);
}
function account_detail(type,openid){
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	var appid=$("input[name='appid']").val();
	$.ajax({
		type : 'POST',
		url : 'ajax2.php?act=account_detail',
		data : {appid:appid, type:type, openid:openid},
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				var item = '<table class="table table-condensed table-hover" id="accountdetail">';
				item += '<tr><td class="title table-secondary"><b>登录方式</b></td><td class="content">'+logintype[data.type]+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>OpenId</b></td><td class="content">'+data.openid+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>昵称</b></td><td class="content">'+data.nickname+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>头像</b></td><td class="content">'+data.faceimg+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>所在地</b></td><td class="content">'+data.location+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>性别</b></td><td class="content">'+data.gender+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>登录IP</b></td><td class="content">'+data.ip+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>首次登录时间</b></td><td class="content">'+data.addtime+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>最后登录时间</b></td><td class="content">'+data.lasttime+'</td></tr>';
				item += '<tr><td class="title table-secondary"><b>操作</b></td><td class="content"><a href="./logs.php?appid='+appid+'&type='+data.type+'&openid='+data.openid+'">查看该账号登录记录</a></td></tr>';
				item += '</table>';
				layer.open({
				  type: 1,
				  shadeClose: true,
				  title: '查看账号详情',
				  skin: 'layui-layer-rim',
				  content: item
				});
			}else{
				layer.msg(data.msg, {icon:2, time:1500});
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
$(document).ready(function(){
	listTable();
})
</script>