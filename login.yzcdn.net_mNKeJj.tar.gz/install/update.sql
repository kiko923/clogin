ALTER TABLE `pre_regcode`
ADD COLUMN `scene` varchar(20) NOT NULL DEFAULT '',
ADD COLUMN `errcount` int(11) NOT NULL DEFAULT '0';