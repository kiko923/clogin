<?php
$alipay_config = [
	//应用ID
	'app_id' => $conf['alipay_appid'],

	//支付宝公钥
	'alipay_public_key' => $conf['alipay_publickey'],

	//应用私钥
	'app_private_key' => $conf['alipay_privatekey'],
];
if(empty($alipay_config['alipay_public_key']) && file_exists(SYSTEM_ROOT.'appCertPublicKey_'.$alipay_config['app_id'].'.crt')){
    $alipay_config['cert_mode'] = true;
    $alipay_config['app_cert_path'] = SYSTEM_ROOT.'appCertPublicKey_'.$alipay_config['app_id'].'.crt';
    $alipay_config['alipay_cert_path'] = SYSTEM_ROOT.'alipayCertPublicKey_RSA2.crt';
    $alipay_config['root_cert_path'] = SYSTEM_ROOT.'alipayRootCert.crt';
}
return $alipay_config;