<?php
/**
 * 微信小程序跳转登录页面
**/
if(!defined('IN_CRONLITE'))exit();

$DB->exec("UPDATE `pre_logs` SET `ip`=:ip WHERE id=:id", [':ip'=>real_ip(), ':id'=>$logid]);

try{
	$wxqrcode = new \lib\WechatQrcode($config['mpappid'], $config['mpsecret']);
	$openlink = $wxqrcode->wxa_generate_scheme('pages/clogin/clogin', 'siteurl='.$siteurl.'&state='.$_GET['state']);
}catch(Exception $e){
	sysmsg($e->getMessage());
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta charset="UTF-8">
    <title>微信快捷登录</title>
    <meta id="viewport" name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <link href="./assets/css/wechat_login.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="content">
        <header class="page_header_upice">
            <div class="logo_upice"><svg t="1653317093163" class="icon" viewBox="0 0 1756 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="1320" width="200" height="200"><path d="M615.497143 330.057143c0 22.674286 18.285714 40.96 40.96 40.96s40.96-18.285714 40.96-40.96-18.285714-40.96-40.96-40.96S615.497143 307.382857 615.497143 330.057143L615.497143 330.057143z" p-id="1321" fill="#07C160"></path><path d="M934.582857 541.805714c0 17.737143 14.445714 32.182857 32.182857 32.182857s32.182857-14.445714 32.182857-32.182857-14.445714-32.182857-32.182857-32.182857C948.845714 509.805714 934.582857 524.068571 934.582857 541.805714z" p-id="1322" fill="#07C160"></path><path d="M824.502857 330.057143c0 22.674286 18.285714 40.96 40.96 40.96s40.96-18.285714 40.96-40.96-18.285714-40.96-40.96-40.96S824.502857 307.382857 824.502857 330.057143L824.502857 330.057143z" p-id="1323" fill="#07C160"></path><path d="M1361.371429 167.862857c0-79.542857-65.462857-142.262857-142.262857-142.262857L533.577143 25.6C453.851429 25.6 391.314286 91.062857 391.314286 167.862857l0 688.457143c0 79.542857 65.462857 142.262857 142.262857 142.262857l688.457143 0c79.542857 0 142.262857-65.462857 142.262857-142.262857L1361.371429 167.862857zM755.931429 674.377143c-36.754286 0-66.377143-7.497143-103.314286-14.811429L549.668571 711.314286l29.44-88.685714c-73.874286-51.565714-117.942857-118.125714-117.942857-199.131429 0-140.251429 132.754286-250.88 294.948571-250.88 145.005714 0 272.091429 88.32 297.691429 207.177143-9.325714-0.914286-18.834286-1.645714-28.342857-1.645714-140.068571 0-250.697143 104.411429-250.697143 233.325714 0 21.394286 3.291429 42.057143 9.142857 61.805714C774.4 674.011429 765.257143 674.377143 755.931429 674.377143zM1190.948571 777.691429l22.125714 73.691429-80.822857-44.251429c-29.44 7.314286-59.062857 14.811429-88.502857 14.811429-140.251429 0-250.88-95.817143-250.88-213.942857 0-117.942857 110.445714-213.942857 250.88-213.942857 132.571429 0 250.514286 96.182857 250.514286 213.942857C1294.262857 674.377143 1250.194286 733.257143 1190.948571 777.691429z" p-id="1324" fill="#07C160"></path><path d="M1095.131429 541.805714c0 17.737143 14.445714 32.182857 32.182857 32.182857 17.737143 0 32.182857-14.445714 32.182857-32.182857s-14.445714-32.182857-32.182857-32.182857C1109.577143 509.805714 1095.131429 524.068571 1095.131429 541.805714z" p-id="1325" fill="#07C160"></path></svg></div>
            <p class="title_upice">微信小程序快捷登录</p>
        </header>
        <div class="page_content">
            <div id="web_login">
                <div class="login_form_panel">
                    <div class="btn_group">
                        <div href="javascript:void(0);" id="onekey" class="ui-button-main ui-button-primary">一键登录</div>
                        <div href="javascript:void(0);" class="ui-button-main ui-button-primary weak" style="margin-top:30px" id="logincomplete">已完成登录</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="error_tips" class="msgbox alert hide">
        <div id="error_message" class="text"></div>
    </div>
    <div class="copyright">
        <?php echo $conf['sitename']?><br/>&copy; <?php echo date("Y")?>
    </div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="./assets/js/loginui.js"></script>
<script>
var qrcode_url = "<?php echo $qrcode_url?>";
var state = "<?php echo $_GET['state']?>";
function jump(){
	window.location.href='<?php echo $openlink?>';
}
function close(){
	if(navigator.userAgent.indexOf("MicroMessenger/") > -1){
		if (typeof WeixinJSBridge == "undefined") {
			if (document.addEventListener) {
				document.addEventListener('WeixinJSBridgeReady', jsApiCall, false);
			} else if (document.attachEvent) {
				document.attachEvent('WeixinJSBridgeReady', jsApiCall);
				document.attachEvent('onWeixinJSBridgeReady', jsApiCall);
			}
		} else {
			jsApiCall();
		}
		function jsApiCall() {
			WeixinJSBridge.call('closeWindow');
		}
	}else{
		window.opener=null;window.close();
	}
}
$(document).ready(function(){
	var ua = window.navigator.userAgent;
	if(ua.indexOf('Android')>-1 && ua.match(/Quark|SogouMSE|SogouMobileBrowser|OppoBrowser|HeyTapBrowser|SamsungBrowser|MQQBrowser|baidubrowser|baiduboxapp|QihooBrowser|UCBrowser|2345Browser|Firefox|LieBaoFast|MiuiBrowser|opr|vivo|MicroMessenger/i) || ua.indexOf('Android')==-1){
		jump();
	}
	setTimeout('checkopenid()', 2000);
	$("#onekey").click(function(){
		var self = $(this);
		self.text('正在拉起微信小程序...');
		jump();
		clearTimeout(window.openAppClock);
		window.openAppClock = setTimeout(function(){ self.text('一键登录'); }, 2000);
	});
	$("#logincomplete").click(function(){
		checkopenid(false)
	})
});
function checkopenid(auto){
	auto = auto || true;
	$.ajax({
		type: "GET",
		dataType: "json",
		url: "ajax.php?act=login&state="+encodeURIComponent(state),
		success: function (data, textStatus) {
			if (data.code == 0) {
				ui_load.startLoading();
				$("#logincomplete").text(data.msg);
				if(window.location.search.indexOf('&client=1')>0){
					close();
				}else{
					setTimeout(function(){ window.location.href=data.url }, 600);
				}
			}else if (data.code == 1) {
				if(auto) setTimeout('checkopenid()', 2000);
			}else{
				ui_alert.show(data.msg);
			}
		},
		error: function (data) {
			ui_alert.show('服务器错误');
			return false;
		}
	});
}
</script>
</body>
</html>