<?php

namespace lib;

use Exception;

class Third{

	static public $info = [
		'name'        => 'third',
		'showname'    => '对接同系统',
		'input' => [
			'appurl' => [
				'name' => '接口地址',
				'type' => 'input',
				'note' => '',
			],
			'appid' => [
				'name' => 'AppId',
				'type' => 'input',
				'note' => '',
			],
			'appkey' => [
				'name' => 'AppKey',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	private $appurl;
	private $appid;
	private $appkey;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->appurl = $config['appurl'];
		$this->appid = $config['appid'];
		$this->appkey = $config['appkey'];
		$this->callback = $siteurl.'return.php';
	}

	static public function help(){
		return '●&nbsp;可对接任意其他彩虹聚合登录站点，接口地址必须以http://或https://开头，以/结尾';
	}

	public function login($state, $type){
		$param = [
			"act" => "login",
			"appid" => $this->appid,
			"appkey" => $this->appkey,
			"type" => $type,
			"redirect_uri" => $this->callback,
			"state" => $state
		];

		$url =  $this->appurl.'connect.php?'.http_build_query($param);
		$data = get_curl($url);
		$arr = json_decode($data, true);
		if(isset($arr['code']) && $arr['code'] == 0){
			return $arr['url'];
		}elseif(isset($arr['msg'])){
			throw new Exception('获取登录url失败：'.$arr['msg']);
		}else{
			throw new Exception('获取登录url失败：请求接口失败');
		}
	}

	public function callback($code, $type){
		$param = [
			"act" => "callback",
			"appid" => $this->appid,
			"appkey" => $this->appkey,
			"type" => $type,
			"code" => $code
		];

		$url =  $this->appurl.'connect.php?'.http_build_query($param);
		$data = get_curl($url);
		$arr = json_decode($data, true);
		if(isset($arr['code']) && $arr['code'] == 0){
			return $arr;
		}elseif(isset($arr['msg'])){
			throw new Exception('获取用户信息失败：'.$arr['msg']);
		}else{
			throw new Exception('获取用户信息失败：请求接口失败');
		}
	}
}