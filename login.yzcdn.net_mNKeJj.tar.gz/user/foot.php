			<footer class="footer text-center text-sm-right">
				&copy; <?php echo date("Y")?> <a href="../" target="_blank"><?php echo $conf['sitename']?></a></span>
			</footer><!--end footer-->
		</div>
		<!-- end page content -->
	</div>
	<!-- end page-wrapper -->

	<script src="<?php echo $cdnpublic?>jquery/3.4.1/jquery.min.js"></script>
	<script src="<?php echo $cdnpublic?>jqueryui/1.12.1/jquery-ui.min.js"></script>
	<script src="<?php echo $cdnpublic?>twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo $cdnpublic?>metisMenu/3.0.7/metisMenu.min.js"></script>
	<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
	<script src="<?php echo $cdnpublic?>node-waves/0.7.6/waves.js"></script>
	<script src="<?php echo $cdnpublic?>jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
	<script src="./assets/js/app.js"></script>
	<script>
		function searchApp(){
			var kw = $("input[name='appkw']").val();
			if(kw!=''){
				window.location.href='./apps.php?kw='+encodeURIComponent(kw);
			}else{
				window.location.href='./apps.php';
			}
		}
	</script>
</body>
</html>