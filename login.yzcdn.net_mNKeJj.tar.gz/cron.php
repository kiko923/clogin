<?php
//日常维护文件

include './includes/common.php';

maintain_daily();