<?php
/**
 * 登录
**/
$is_defend=true;
include("../includes/common.php");

if(isset($_GET['logout'])){
	if(!checkRefererHost())exit();
	setcookie("user_token", "", time() - 604800);
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功注销本次登录！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
	exit("<script language='javascript'>alert('您已登录！');window.location.href='./';</script>");
}
$csrf_token = md5(mt_rand(0,999).time());
$_SESSION['csrf_token'] = $csrf_token;
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="utf-8" />
	<title>登录 - <?php echo $conf['sitename']?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link href="<?php echo $cdnpublic?>twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>jqueryui/1.12.1/jquery-ui.min.css" rel="stylesheet">
	<link href="<?php echo $cdnpublic?>font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>dripicons/2.0.0/webfont.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>metisMenu/3.0.7/metisMenu.min.css" rel="stylesheet" type="text/css" />
	<link href="./assets/css/app.min.css" rel="stylesheet" type="text/css" />
	<link href="./assets/css/captcha.css" rel="stylesheet" type="text/css" />
</head>

<body class="account-body accountbg">

	<!-- Log In page -->
	<div class="container">
		<div class="row vh-100 ">
			<div class="col-12 align-self-center">
				<div class="auth-page">
					<div class="card auth-card shadow-lg">
						<div class="card-body">
							<div class="px-3">
								<div class="auth-logo-box">
									<a href="../" class="logo logo-admin"><img src="../assets/img/logo.png" height="55" alt="logo" class="auth-logo"></a>
								</div><!--end auth-logo-box-->
								
								<div class="text-center auth-logo-text">
									<h4 class="mt-0 mb-3 mt-5">用户登录</h4>
									<p class="text-muted mb-0">请输入您的账号信息</p>  
								</div> <!--end auth-logo-text-->  

								
								<form class="form-horizontal auth-form my-4" action="login.php">
								<input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>">

									<div class="form-group">
										<div class="input-group mb-3">
											<span class="auth-form-icon">
												<i class="dripicons-user"></i>
											</span>
											<input type="text" class="form-control" id="username" name="user" placeholder="用户名/手机号/邮箱">
										</div>
									</div><!--end form-group--> 
		
									<div class="form-group">
										<div class="input-group mb-3">
											<span class="auth-form-icon">
												<i class="dripicons-lock"></i>
											</span>
											<input type="password" class="form-control" id="password" name="pass" placeholder="请输入密码">
										</div>
									</div><!--end form-group--> 

									<?php if($conf['captcha_open_login']==1){?>
									<div class="form-group" id="captcha" style="margin: auto;"><div id="captcha_text">
										正在加载验证码
									</div>
									<div id="captcha_wait">
										<div class="loading">
											<div class="loading-dot"></div>
											<div class="loading-dot"></div>
											<div class="loading-dot"></div>
											<div class="loading-dot"></div>
										</div>
									</div></div>
									<div id="captchaform"></div>
									<?php }?>

									<div class="form-group row mt-4">
										<div class="col-sm-6">
											<div class="custom-control custom-switch switch-success">
												<input type="checkbox" class="custom-control-input" id="customSwitchSuccess" checked>
												<label class="custom-control-label text-muted" for="customSwitchSuccess">记住登录信息</label>
											</div>
										</div><!--end col--> 
										<div class="col-sm-6 text-right">
											<a href="findpwd.php" class="text-muted font-13"><i class="dripicons-lock"></i> 找回密码</a>                                    
										</div><!--end col-->
									</div><!--end form-group--> 
		
									<div class="form-group mb-0 row">
										<div class="col-12 mt-2">
											<button class="btn btn-gradient-primary btn-round btn-block waves-effect waves-light" type="button" id="submit">立即登录 <i class="fas fa-sign-in-alt ml-1"></i></button>
										</div><!--end col--> 
									</div> <!--end form-group-->                           
								</form><!--end form-->
							</div><!--end /div-->
							
							<div class="m-3 text-center text-muted">
								<p class="">还没有账号？ <a href="./reg.php" class="text-primary ml-2">免费注册</a></p>
							</div>
						</div><!--end card-body-->
					</div><!--end card-->
					<?php if($conf['login_qq']==1 || $conf['login_wx']==1 || $conf['login_alipay']==1){?>
					<div class="account-social text-center mt-4">
						<h6 class="my-4">第三方登录</h6>
						<ul class="list-inline mb-4">
							<?php if($conf['login_qq']==1){?><li class="list-inline-item">
								<a href="javascript:connect('qq')" class="" title="QQ快捷登录">
									<i class="fab fa-qq" style="background-color: #1bc1fa;color: #fff;"></i>
								</a>
							</li><?php }?>
							<?php if($conf['login_wx']==1){?><li class="list-inline-item">
								<a href="javascript:connect('wx')" class="" title="微信快捷登录">
									<i class="fab fa-weixin" style="background-color: #2aae67;color: #fff;"></i>
								</a>
							</li><?php }?>
							<?php if($conf['login_alipay']==1){?><li class="list-inline-item">
								<a href="javascript:connect('alipay')" class="" title="支付宝快捷登录">
									<i class="fab fa-alipay" style="background-color: #1677ff;color: #fff;"></i>
								</a>
							</li><?php }?>
						</ul>
					</div><!--end account-social-->
					<?php }?>
				</div><!--end auth-page-->
			</div><!--end col-->           
		</div><!--end row-->
	</div><!--end container-->
	<!-- End Log In page -->

	<script src="<?php echo $cdnpublic?>jquery/3.4.1/jquery.min.js"></script>
	<script src="<?php echo $cdnpublic?>jqueryui/1.12.1/jquery-ui.min.js"></script>
	<script src="<?php echo $cdnpublic?>twitter-bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
	<script src="<?php echo $cdnpublic?>metisMenu/3.0.7/metisMenu.min.js"></script>
	<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
	<script src="<?php echo $cdnpublic?>node-waves/0.7.6/waves.js"></script>
	<script src="<?php echo $cdnpublic?>jQuery-slimScroll/1.3.8/jquery.slimscroll.min.js"></script>
	<script src="./assets/js/app.js"></script>
	<script src="//static.geetest.com/static/tools/gt.js"></script>
<script>
var captcha_open = 0;
var handlerEmbed = function (captchaObj) {
	captchaObj.appendTo('#captcha');
	captchaObj.onReady(function () {
		$("#captcha_wait").hide();
	}).onSuccess(function () {
		var result = captchaObj.getValidate();
		if (!result) {
			return alert('请完成验证');
		}
		$("#captchaform").html('<input type="hidden" name="geetest_challenge" value="'+result.geetest_challenge+'" /><input type="hidden" name="geetest_validate" value="'+result.geetest_validate+'" /><input type="hidden" name="geetest_seccode" value="'+result.geetest_seccode+'" />');
	});
};
$(document).ready(function(){
	if($("#captcha").length>0) captcha_open=1;
	$("#submit").click(function(){
		var user=$("input[name='user']").val();
		var pass=$("input[name='pass']").val();
		if(user=='' || pass==''){layer.alert('账号和密码不能为空！');return false;}
		submitLogin(user,pass);
	});
	if(captcha_open==1){
	$.ajax({
		url: "./ajax.php?act=captcha&t=" + (new Date()).getTime(),
		type: "get",
		dataType: "json",
		success: function (data) {
			$('#captcha_text').hide();
			$('#captcha_wait').show();
			initGeetest({
				gt: data.gt,
				challenge: data.challenge,
				new_captcha: data.new_captcha,
				product: "popup",
				width: "100%",
				offline: !data.success
			}, handlerEmbed);
		}
	});
	}
});
function submitLogin(user,pass){
	var csrf_token=$("input[name='csrf_token']").val();
	var data = {user:user, pass:pass, csrf_token:csrf_token};
	if(captcha_open == 1){
		var geetest_challenge = $("input[name='geetest_challenge']").val();
		var geetest_validate = $("input[name='geetest_validate']").val();
		var geetest_seccode = $("input[name='geetest_seccode']").val();
		if(geetest_challenge == ""){
			layer.alert('请先完成滑动验证！'); return false;
		}
		var adddata = {geetest_challenge:geetest_challenge, geetest_validate:geetest_validate, geetest_seccode:geetest_seccode};
	}
	var ii = layer.load();
	$.ajax({
		type: "POST",
		dataType: "json",
		data: Object.assign(data, adddata),
		url: "ajax.php?act=login",
		success: function (data, textStatus) {
			layer.close(ii);
			if (data.code == 0) {
				layer.msg(data.msg, {icon: 16,time: 10000,shade:[0.3, "#000"]});
				setTimeout(function(){ window.location.href=data.url }, 1000);
			}else{
				layer.alert(data.msg, {icon: 2});
			}
		},
		error: function (data) {
			layer.msg('服务器错误', {icon: 2});
			return false;
		}
	});
}
function connect(type){
	var csrf_token=$("input[name='csrf_token']").val();
	var ii = layer.load();
	$.ajax({
		type : "POST",
		url : "ajax.php?act=connect",
		data : {type:type, csrf_token:csrf_token},
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				window.location.href = data.url;
			}else{
				layer.alert(data.msg, {icon: 7});
			}
		}
	});
}
</script>
</body>
</html>