<?php
include("../includes/common.php");
$title='后台管理';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<div class="row">
<div class="col-xs-12 col-sm-10 col-md-8 col-lg-6 center-block" style="float: none;">
<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add'){
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">添加应用</h3></div>';
echo '<div class="panel-body">';
echo '<form action="./edit.php?my=add_submit" method="POST" onsubmit="return checkURL(\'url\');">
<div class="form-group">
<label>应用名称:</label><br>
<input type="text" class="form-control" name="name" value="" required>
</div>
<div class="form-group">
<label>应用网址:</label><br>
<input type="text" class="form-control" name="url" value="" required placeholder="填写网站首页网址">
</div>
<div class="form-group">
<label>是否获取昵称头像:</label><br>
<select class="form-control" name="type"><option value="1">是</option><option value="0">否</option></select>
</div>
<div class="form-group">
<label>是否限制域名:</label><br>
<select class="form-control" name="limit"><option value="0">否</option><option value="1">是</option></select>
</div>
<div class="form-group">
<label>域名白名单:</label><br>
<textarea class="form-control" name="domains" rows="5" placeholder="一行填写一个域名"></textarea>
<font color="green">应用域名校验规则：'.($conf['domaincheck']==1?'只校验主域名':'校验完整域名').'</font>
</div>
<div class="form-group">
<label>应用状态:</label><br>
<select class="form-control" name="status"><option value="1">开启</option><option value="0">关闭</option><option value="2">待审核</option><option value="3">未通过</option></select>
</div>
<div class="form-group">
<label>用户UID:</label><br>
<input type="number" class="form-control" name="uid" value="0" min="0">
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定添加"></form>';
echo '<br/><a href="./apps.php">>>返回应用列表</a>';
echo '</div></div>';
}
elseif($my=='add_submit')
{
$name=trim($_POST['name']);
$url=str_replace('，',',',trim($_POST['url']));
$type=intval($_POST['type']);
$limit=intval($_POST['limit']);
$status=intval($_POST['status']);
$uid=intval($_POST['uid']);
$domains=trim($_POST['domains']);
if($name==NULL or $url==NULL){
showmsg('必填项不能为空！',3);
} else {
$rows=$DB->getRow("select * from pre_apps where name='$name' AND status<4 limit 1");
if($rows)
	showmsg('应用名称已存在！',3);
$appkey = md5(mt_rand(0,999).time());
$sql="insert into `pre_apps` (`uid`,`appkey`,`name`,`url`,`addtime`,`type`,`limit`,`status`) values (:uid, :appkey, :name, :url, NOW(), :type, :limit, :status)";
if($DB->exec($sql, ['uid'=>$uid, 'appkey'=>$appkey, 'name'=>$name, 'url'=>$url, 'type'=>$type, 'limit'=>$limit, 'status'=>$status])!==false){
	$appid=$DB->lastInsertId();
	$domains = str_replace(array("\r\n", "\r", "\n"), "[br]", $domains);
	$domains = explode("[br]",$domains);
	foreach($domains as $domain){
		if(empty($domain))continue;
		$DB->exec("INSERT INTO pre_appdomain (`appid`,`domain`,`addtime`,`status`) VALUES (:appid, :domain, NOW(), 1)", [':appid'=>$appid, ':domain'=>$domain]);
	}
	showmsg('添加应用成功！<br/>APPID：'.$appid.'<br/>APPKEY：'.$appkey.'<br/><br/><a href="./apps.php">>>返回应用列表</a>',1);
}else
	showmsg('添加应用失败！'.$DB->error(),4);
}
}
elseif($my=='edit'){
$appid=intval($_GET['appid']);
$row=$DB->getRow("select * from pre_apps where appid='$appid' limit 1");
if(!$row)showmsg('应用不存在',3);
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改应用</h3></div>';
echo '<div class="panel-body"><ul class="nav nav-tabs">
<li align="center" class="active"><a href="#">基本信息</a></li>
<li align="center"><a href="./edit.php?my=editdomain&appid='.$appid.'">域名白名单</a></li>
</ul>';
echo '<form action="./edit.php?my=edit_submit&appid='.$appid.'" method="POST" onsubmit="return checkURL(\'url\');">
<div class="form-group">
<label>APPID:</label><br>
<input type="text" class="form-control" name="appid" value="'.$row['appid'].'" readonly>
</div>
<div class="form-group">
<label>APPKEY:</label><br>
<input type="text" class="form-control" name="appkey" value="'.$row['appkey'].'" readonly>
<a href="./edit.php?my=reset&appid='.$row['appid'].'" class="btn btn-sm btn-danger" onclick="return confirm(\'你确实要重置APPKEY吗？\');">重置APPKEY</a>
</div>
<div class="form-group">
<label>应用名称:</label><br>
<input type="text" class="form-control" name="name" value="'.$row['name'].'" required>
</div>
<div class="form-group">
<label>应用网址:</label><br>
<input type="text" class="form-control" name="url" value="'.$row['url'].'" required placeholder="填写网站首页网址">
</div>
<div class="form-group">
<label>是否获取昵称头像:</label><br>
<select class="form-control" name="type" default="'.$row['type'].'"><option value="1">是</option><option value="0">否</option></select>
</div>
<div class="form-group">
<label>是否限制域名:</label><br>
<select class="form-control" name="limit" default="'.$row['limit'].'"><option value="0">否</option><option value="1">是</option></select>
</div>
<div class="form-group">
<label>应用状态:</label><br>
<select class="form-control" name="status" default="'.$row['status'].'"><option value="1">开启</option><option value="0">关闭</option><option value="2">待审核</option><option value="3">未通过</option></select>
</div>
<div class="form-group">
<label>用户UID:</label><br>
<input type="number" class="form-control" name="uid" value="'.$row['uid'].'" min="0">
</div>
<input type="submit" class="btn btn-primary btn-block" value="确定修改"></form>';
echo '<br/><a href="./apps.php">>>返回应用列表</a>';
echo '</div></div>';
}
elseif($my=='edit_submit')
{
$appid=intval($_GET['appid']);
$row=$DB->getRow("select * from pre_apps where appid='$appid' limit 1");
if(!$row)showmsg('记录不存在',3);
$name=trim($_POST['name']);
$url=str_replace('，',',',trim($_POST['url']));
$type=intval($_POST['type']);
$limit=intval($_POST['limit']);
$status=intval($_POST['status']);
$uid=intval($_POST['uid']);
if($name==NULL or $url==NULL){
showmsg('必填项不能为空！',3);
} else {
$sql="UPDATE `pre_apps` SET `uid`=:uid,`name`=:name,`url`=:url,`type`=:type,`limit`=:limit,`status`=:status WHERE appid=:appid";
if($DB->exec($sql, ['uid'=>$uid, 'appid'=>$appid, 'name'=>$name, 'url'=>$url, 'type'=>$type, 'limit'=>$limit, 'status'=>$status])!==false){
	showmsg('修改应用成功！<br/><br/><a href="./apps.php">>>返回应用列表</a>',1);
}else
	showmsg('修改应用失败！'.$DB->error(),4);
}
}
elseif($my=='editdomain'){
$appid=intval($_GET['appid']);
$row=$DB->getRow("select * from pre_apps where appid='$appid' limit 1");
if(!$row)showmsg('应用不存在',3);
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改应用</h3></div>';
echo '<div class="panel-body"><ul class="nav nav-tabs">
<li align="center"><a href="./edit.php?my=edit&appid='.$appid.'">基本信息</a></li>
<li align="center" class="active"><a href="#">域名白名单</a></li>
</ul>';

$rules = $conf['domaincheck']==1?'应用域名校验规则：<font color="red">只校验主域名</font>，例如baidu.com和www.baidu.com，只需添加主域名baidu.com即可。':'应用域名校验规则：<font color="red">校验完整域名</font>，例如baidu.com和www.baidu.com，需要分别都添加。';
if($conf['domainlimit'] == 0 || $row['limit']==0)$rules = '当前应用已关闭回调域名校验，因此无论是否配置域名白名单都允许调用';

echo '<div class="alert alert-info" role="alert"><font color="green">'.$rules.'</font></div>';
$list = $DB->getAll("select * from pre_appdomain where appid='$appid'");
echo '<div class="list-group">';
foreach($list as $domain){
echo '<div class="list-group-item">'.$domain['domain'].'<a href="edit.php?my=deldomain&id='.$domain['id'].'" class="btn btn-xs btn-danger pull-right">删除</a></div>';
}
echo '<div class="list-group-item"><form action="./edit.php?my=adddomain&appid='.$appid.'" method="POST" class="form-inline">
<div class="form-group">
<input type="text" class="form-control" name="domain" value="" required>
</div>
<input type="submit" class="btn btn-success" value="添加域名">
</form></div>';
echo '</div>';
echo '<br/><a href="./apps.php">>>返回应用列表</a>';
echo '</div></div>';
}
elseif($my=='adddomain'){
$appid=intval($_GET['appid']);
$domain=trim($_POST['domain']);
if($DB->getRow("select * from pre_appdomain where appid='$appid' AND domain='$domain' limit 1"))exit("<script language='javascript'>alert('域名已存在');history.go(-1);</script>");
$DB->exec("INSERT INTO pre_appdomain (`appid`,`domain`,`addtime`,`status`) VALUES (:appid, :domain, NOW(), 1)", [':appid'=>$appid, ':domain'=>$domain]);
exit("<script language='javascript'>alert('域名添加成功');history.go(-1);</script>");
}
elseif($my=='reset'){
$appid=intval($_GET['appid']);
$appkey = md5(mt_rand(0,999).time());
$sql=$DB->exec("UPDATE pre_apps SET appkey='$appkey' WHERE appid='$appid'");
exit("<script language='javascript'>alert('APPKEY重置成功');history.go(-1);</script>");
}
elseif($my=='del'){
$appid=intval($_GET['appid']);
$sql=$DB->exec("DELETE FROM pre_apps WHERE appid='$appid'");
$DB->exec("DELETE FROM pre_appdomain WHERE appid='$appid'");
$DB->exec("DELETE FROM pre_accounts WHERE appid='$appid'");
$DB->exec("DELETE FROM pre_logs WHERE appid='$appid'");
if($sql){$res='删除成功！';}
else{$res='删除失败！';}
exit("<script language='javascript'>alert('{$res}');history.go(-1);</script>");
}
elseif($my=='del_account'){
$id=intval($_GET['id']);
$sql=$DB->exec("DELETE FROM pre_accounts WHERE id='$id'");
if($sql){$res='删除成功！';}
else{$res='删除失败！';}
exit("<script language='javascript'>alert('{$res}');history.go(-1);</script>");
}
elseif($my=='deldomain'){
$id=intval($_GET['id']);
$sql=$DB->exec("DELETE FROM pre_appdomain WHERE id='$id'");
if($sql){$res='删除成功！';}
else{$res='删除失败！';}
exit("<script language='javascript'>alert('{$res}');history.go(-1);</script>");
}
elseif($my=='resetToken'){
saveSetting('wechat_token', getSid());
$CACHE->clear();
exit("<script language='javascript'>alert('Token重置成功');history.go(-1);</script>");
}
?>
    </div>
  </div>
<?php include './foot.php';?>
<script>
function checkURL(name)
{
	var url = $("input[name='"+name+"']").val();
	if(url == "")return;

	if (url.indexOf(" ")>=0){
		url = url.replace(/ /g,"");
	}
	if (url.toLowerCase().indexOf("http://")<0 && url.toLowerCase().indexOf("https://")<0){
		url = "http://"+url;
	}
	if (url.slice(url.length-1)=="/"){
		url = url.substring(0,url.length-1);
	}
	$("input[name='"+name+"']").val(url);
	return true;
}
$(document).ready(function(){
	var items = $("select[default]");
	for (i = 0; i < items.length; i++) {
		$(items[i]).val($(items[i]).attr("default")||0);
	}
})
</script>
</body>
</html>