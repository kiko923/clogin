<?php
namespace plugins;

use Exception;

class dingtalk {

	static public $info = [
		'name'        => 'dingtalk',
		'showname'    => '钉钉',
		'link'        => 'https://open.dingtalk.com/',
		'sort'        => 21,
		'abroad'      => false,
		'input' => [
			'client_id' => [
				'name' => 'AppKey',
				'type' => 'input',
				'note' => '',
			],
			'client_secret' => [
				'name' => 'AppSecret',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://login.dingtalk.com/oauth2/auth";
	const GET_ACCESS_TOKEN_URL = "https://api.dingtalk.com/v1.0/oauth2/userAccessToken";
	const GET_USER_INFO_URL = "https://api.dingtalk.com/v1.0/contact/users/me";

	private $client_id;
	private $client_secret;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->client_id = $config['client_id'];
		$this->client_secret = $config['client_secret'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;<a href="https://open-dev.dingtalk.com/" target="_blank" rel="noreferrer">申请地址</a>，创建企业内部应用，进入应用后点击钉钉登录与分享，回调的URL填写：'.$siteurl.'return.php，在权限管理添加“通讯录个人信息读权限”<br/>●&nbsp;<b>注意：配置好之后请勿随意更换企业，否则之前已登录的用户将全部失效！</b>';
	}

	public function login($state){
		$param = [
			"response_type" => "code",
			"client_id" => $this->client_id,
			"redirect_uri" => $this->callback,
			"scope" => 'openid',
			"state" => $state,
			"prompt" => "consent"
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		$access_token = $this->get_access_token($code);
		$userinfo = $this->get_userinfo($access_token);

		$result = [
			'access_token' => $access_token,
			'social_uid' => $userinfo['unionId'],
			'faceimg' => $userinfo['avatarUrl'],
			'nickname' => $userinfo['nick'],
			'mobile' => $userinfo['mobile'],
			'email' => $userinfo['email'],
		];

		return $result;
	}

	private function get_access_token($code){
		$param = [
			'clientId' => $this->client_id,
			'clientSecret' => $this->client_secret,
			'code' => $code,
			'grantType' => 'authorization_code'
		];
		$header = [
			'Content-Type: application/json'
		];

		$url = self::GET_ACCESS_TOKEN_URL;
		$response = get_curl_api(self::$info['abroad'], $url, json_encode($param), 0, $header);
		$arr = json_decode($response, true);
		if(isset($arr['accessToken'])){
			return $arr['accessToken'];
		}elseif(isset($arr['code'])){
			throw new Exception('获取access_token失败 ['.$arr['code'].']'.$arr['message']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_userinfo($access_token){
		$header = [
			'x-acs-dingtalk-access-token: '.$access_token,
			'Content-Type: application/json'
		];

		$url = self::GET_USER_INFO_URL;
		$response = get_curl_api(self::$info['abroad'], $url, 0, 0, $header);
		$arr = json_decode($response, true);
		if(isset($arr['unionId'])){
			return $arr;
		}elseif(isset($arr['code'])){
			throw new Exception('获取用户信息失败 ['.$arr['code'].']'.$arr['message']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}