<?php
include "../../includes/common.php";

$wechatpay_config = require('inc/wxpay.config.php');

$isSuccess = true;
try{
	$client = new \WeChatPay\PaymentService($wechatpay_config);
	$data = $client->notify();

	$out_trade_no = $data['out_trade_no'];
	$transaction_id = $data['transaction_id'];
	$total_fee = $data['total_fee'];
	$openid = $data['openid'];

	$srow=$DB->getRow("SELECT * FROM pre_order WHERE trade_no='{$out_trade_no}' LIMIT 1");
	if($srow['status']==0){
		if($DB->exec("UPDATE `pre_order` SET `status` ='1' WHERE `trade_no`='{$out_trade_no}'")){
			$DB->exec("UPDATE `pre_order` SET `endtime` ='$date',`api_trade_no` ='$transaction_id' WHERE `trade_no`='{$out_trade_no}'");
			processOrder($srow);
		}
	}
}catch(Exception $e){
	$isSuccess = false;
	$errmsg = $e->getMessage();
}

$client->replyNotify($isSuccess, $errmsg);
