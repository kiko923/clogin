<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='创建应用';
include './head.php';

$csrf_token = md5(mt_rand(0,999).time());
$_SESSION['csrf_token'] = $csrf_token;
?>
<style>
label > span.required {
    color: #ff4d4d;
}
.button{cursor: pointer;}
</style>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active">创建应用</li>
					</ol>
				</div>
				<h4 class="page-title">创建应用</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-sm-12 col-md-10 col-lg-8 contents" style="margin: 0 auto;float: none;">
			<div class="card">
				<div class="card-body">
					<h4>创建应用</h4><hr/>
					<?php if($conf['app_audit']==1){?><div class="alert alert-info alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true"><i class="fas fa-times"></i></span>
						</button>
						<strong>提示：</strong> 当前已开启应用审核模式，应用创建后需要等管理员审核通过后才能使用。
					</div><?php }?>
					<?php if(!empty($conf['ggappadd'])){?><div class="alert alert-warning alert-dismissible fade show" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close">
							<span aria-hidden="true"><i class="fas fa-times"></i></span>
						</button>
						<strong>公告：</strong> <?php echo $conf['ggappadd']?>
					</div><?php }?>
					<form class="form-horizontal devform" onsubmit="return addSubmit()" id="form-info"><input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>">
						<div class="form-group">
							<label>应用名称 <span class="required">*</span></label>
							<input type="text" class="form-control" name="name" placeholder="填写应用名称" required>
						</div>
						<div class="form-group">
							<label>应用首页网址 <span class="required">*</span></label>
							<input type="text" class="form-control" name="url" placeholder="填写你的网站首页网址" required>
							<small class="form-text text-muted"><i class="fas fa-info-circle"></i> 请填写已建设好的并且可以访问的网址</small>
						</div>
						<div class="form-group">
							<label>回调域名白名单<span class="required">*</span>&nbsp;<span class="fas fa-plus-circle button" id="add-callback-url"></span></label>
							<div class="input-group callback-url-group pb-1">
								<input type="text" class="form-control" name="domain[]" placeholder="填写回调域名白名单，<?php echo $conf['domaincheck']==1?'只填写主域名即可':'需填写完整域名'?>" required>
								<div class="input-group-append">
									<button type="button" class="btn btn-outline-info js-delete" disabled><i class="far fa-trash-alt"></i></button>
								</div>
							</div>
						</div>
						<small class="form-text text-muted"><i class="fas fa-info-circle"></i> 请填写需要调用网站的域名，<font color="red"><?php echo $conf['domaincheck']==1?'只填写主域名即可':'需填写完整域名'?></font>，此项后期可随时变更</small><br/>
						<div class="form-group">
						<input type="submit" id="submit" value="确定提交" class="btn btn-gradient-primary btn-block waves-effect waves-light"/><br/>
						</div>
					</form>
				</div><!--end card-body-->
			</div>
		</div><!--end col-->
	</div><!--end row-->

</div><!-- container -->

<?php include 'foot.php';?>
<script>
function checkURL(name)
{
	var url = $("input[name='"+name+"']").val();
	if(url == "")return;

	if (url.indexOf(" ")>=0){
		url = url.replace(/ /g,"");
	}
	if (url.toLowerCase().indexOf("http://")<0 && url.toLowerCase().indexOf("https://")<0){
		url = "http://"+url;
	}
	if (url.slice(url.length-1)=="/"){
		url = url.substring(0,url.length-1);
	}
	$("input[name='"+name+"']").val(url);
	return true;
}
function addSubmit(){
	var name = $("input[name='name']").val();
	if(name == ''){
		layer.alert('应用名称不能为空！');return false;
	}
	var url = $("input[name='url']").val();
	if(url == ''){
		layer.alert('应用首页网址不能为空！');return false;
	}
	if(url.indexOf('.')==-1){
		layer.alert('应用首页网址不正确！');return false;
	}
	checkURL('url');
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax2.php?act=appadd',
		data : $("#form-info").serialize(),
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg,{
					icon: 1,
					closeBtn: false
				}, function(){
				  window.location.href='./apps.php'
				});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
	return false;
}
</script>
<script>
  var $addCallbackUrl = $('#add-callback-url')
  var $callbaclUlfield = $addCallbackUrl.closest('.form-group')
  $callbaclUlfield.on('click', '.js-delete', function(){
    $(this).closest('.callback-url-group').remove()
    if($callbaclUlfield.find('.callback-url-group').length === 1){
      $callbaclUlfield.find('.js-delete').prop('disabled',true)
    }
  })
  $addCallbackUrl.on('click', function(){
    var html=''
    html += '<div class="input-group callback-url-group pb-1">'
    html += $(".callback-url-group").html()
    html += '</div>'
    $callbaclUlfield.append(html)
    if($callbaclUlfield.find('.callback-url-group').length > 1){
      $callbaclUlfield.find('.js-delete').prop('disabled',false)
    }
  })
</script>