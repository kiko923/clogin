<?php
namespace plugins;

use Exception;

class wx {

	static public $info = [
		'name'        => 'wx',
		'showname'    => '微信',
		'link'        => 'https://return.yzcdn.net/',
		'sort'        => 12,
		'abroad'      => false,
		'input' => [
			'mplogintype' => [
				'name' => '微信登录模式',
				'type' => 'select',
				'options' => ['公众号网页授权登录','关注公众号自动登录','使用微信小程序登录'],
				'note' => '',
			],
			'mpappid' => [
				'name' => '公众号或小程序APPID',
				'type' => 'input',
				'note' => '填写微信公众号或小程序的APPID',
			],
			'mpsecret' => [
				'name' => '公众号或小程序SECRET',
				'type' => 'input',
				'note' => '',
			],
			'openappid' => [
				'name' => '开放平台应用APPID',
				'type' => 'input',
				'note' => '填写微信开放平台的应用ID（可不填，填写后全部使用UnionID）',
			],
			'opensecret' => [
				'name' => '开放平台应用SECRET',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://return.yzcdn.net/connect/qrconnect";
	const GET_AUTH_CODE_URL_MP = "https://return.yzcdn.net/connect/oauth2/authorize";
	const GET_ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token";
	const GET_USERINFO_URL = "https://api.weixin.qq.com/sns/userinfo";

	private $mpappid;
	private $mpsecret;
	private $mplogintype;
	private $openappid;
	private $opensecret;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->mpappid = $config['mpappid'];
		$this->mpsecret = $config['mpsecret'];
		$this->mplogintype = $config['mplogintype'];
		$this->openappid = $config['openappid'];
		$this->opensecret = $config['opensecret'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		return '●&nbsp;可以只填写公众号或小程序的APPID和SECRET，这种情况下使用公众号或小程序实现快捷登录（支持PC+手机），需要有服务号或小程序并且已认证，公众号需配置网页授权域名，小程序需配置Request合法域名。<br/>●&nbsp;如果填写开放平台的APPID和SECRET，可以实现PC端调用开放平台快捷登录，并且能够在多个公众号、小程序、网站应用获取到唯一用户标识。在<a href="https://return.yzcdn.net/" target="_blank" rel="noreferrer">开放平台</a>认证后申请网站应用，并且绑定公众号或小程序，配置网页授权域名。<br/>●&nbsp;如果只填写开放平台的APPID和SECRET，不填写公众号的，则只支持PC端登录。<br/>●&nbsp;<b>注意：配置好之后请勿随意更换公众号或小程序或应用，否则之前已登录的用户将全部失效！</b><br/>●&nbsp;<a href="./set.php?mod=wxqrcode" target="_blank">点击查看关注公众号自动登录设置</a>';
	}

	public function login($state){
		global $siteurl;
		if(empty($this->mpappid) && !empty($this->openappid)){
			$param = [
				"appid" => $this->openappid,
				"redirect_uri" => $this->callback,
				"response_type" => "code",
				"scope" => "snsapi_login",
				"state" => $state
			];
	
			$url = self::GET_AUTH_CODE_URL.'?'.http_build_query($param);
		} else{
			$url = $siteurl.'jump.php?state='.urlencode($state);
		}
		return $url;
	}

	public function jump($state, $type = 0){
		if(!empty($this->openappid) && checkmobile()==false && strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')===false){
			$param = [
				"appid" => $this->openappid,
				"redirect_uri" => $this->callback,
				"response_type" => "code",
				"scope" => "snsapi_login",
				"state" => $state
			];
	
			$url = self::GET_AUTH_CODE_URL.'?'.http_build_query($param);
			header("Location: ".$url);
			exit;
		}
		elseif (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') && $this->mplogintype != 2) {
			if(isset($_GET['confirm']) || !isset($_GET['client'])){
				$param = [
					"appid" => $this->mpappid,
					"redirect_uri" => $this->callback,
					"response_type" => "code",
					"scope" => $type == 1 ? "snsapi_userinfo" : "snsapi_base",
					"state" => $state
				];
		
				$url = self::GET_AUTH_CODE_URL_MP.'?'.http_build_query($param)."#wechat_redirect";
				header("Location: ".$url);
				exit;
			}else{
				return PAGE_ROOT.'wxlogin.php';
			}
		}else{
			if($this->mplogintype == 2 && checkmobile()){
				return PAGE_ROOT.'wxminiapp.php';
			}
			elseif ($this->mplogintype == 1) {
                return PAGE_ROOT.'wxmpscan.php';
            }
			else{
				return PAGE_ROOT.'wxqrcode.php';
			}
		}
	}

	public function callback($code, $type = 0, $mode = 0){
		if($mode == 1){
			list($access_token, $openid) = $this->get_access_token_mp($code);
		}else{
			list($access_token, $openid) = $this->get_access_token($code);
		}
		
		if($type==1 || !empty($this->openappid)){
			$userinfo = $this->get_userinfo($access_token, $openid);
			$result = [
				'access_token' => $access_token,
				'social_uid' => !empty($this->openappid) ? $userinfo['unionid'] : $openid,
				'faceimg' => $userinfo['headimgurl'],
				'nickname' => $userinfo['nickname'],
				'location' => $userinfo['province'].$userinfo['city'],
				'gender' => $userinfo['sex']==2?'女':'男',
			];
		}else{
			$result = [
				'access_token' => $access_token,
				'social_uid' => $openid,
			];
		}

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"appid" => $this->openappid,
			"secret" => $this->opensecret,
			"code" => $code,
			"grant_type" => "authorization_code"
		];

		$url = self::GET_ACCESS_TOKEN_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['access_token']) && isset($arr['openid'])){
			return [$arr['access_token'], $arr['openid']];
		}elseif(isset($arr['errcode'])){
			throw new Exception('获取openid失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}else{
			throw new Exception('获取openid失败，原因未知');
		}
	}

	private function get_access_token_mp($code){
		$param = [
			"appid" => $this->mpappid,
			"secret" => $this->mpsecret,
			"code" => $code,
			"grant_type" => "authorization_code"
		];

		$url = self::GET_ACCESS_TOKEN_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['access_token']) && isset($arr['openid'])){
			if(isset($arr['is_snapshotuser']) && $arr['is_snapshotuser']==1){
				throw new Exception('未成功获取到个人信息，请点击使用完整服务，然后返回重试');
			}
			return [$arr['access_token'], $arr['openid']];
		}elseif(isset($arr['errcode'])){
			throw new Exception('获取openid失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}else{
			throw new Exception('获取openid失败，原因未知');
		}
	}

	private function get_userinfo($access_token, $openid){
		$param = [
			"access_token" => $access_token,
			"openid" => $openid,
			"lang" => "zh_CN"
		];

		$url = self::GET_USERINFO_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['unionid']) || isset($arr['openid'])){
			return $arr;
		}elseif(isset($arr['errcode'])){
			throw new Exception('获取用户信息失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}