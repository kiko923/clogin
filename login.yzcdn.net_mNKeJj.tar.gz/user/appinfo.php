<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='应用详情';
include './head.php';

$mod=isset($_GET['mod'])?$_GET['mod']:'base';

$csrf_token = md5(mt_rand(0,999).time());
$_SESSION['csrf_token'] = $csrf_token;

$appid=intval($_GET['appid']);
$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
if($row){
	$domains=$DB->getAll("select * from pre_appdomain where appid='{$appid}'");
	$domaintext = '';
	$domaintext2 = '';
	$domaincount=0;
	foreach($domains as $domain){
		$domaintext .= $domain['domain']."\r\n";
		$domaintext2 .= '<li class="list-group-item">'.$domain['domain'].'<a href="javascript:delDomain('.$domain['id'].')" class="btn btn-sm btn-outline-danger float-right domainitem">删除</a></li>';
		$domaincount++;
	}
	$domaintext = substr($domaintext,0,-2);

	$rules = $conf['domaincheck']==1?'应用域名校验规则：<font color="red">只校验主域名</font>，例如baidu.com和www.baidu.com，只需添加主域名baidu.com即可。':'应用域名校验规则：<font color="red">校验完整域名</font>，例如baidu.com和www.baidu.com，需要分别都添加。';
	if($conf['domainlimit'] == 0 || $row['limit']==0)$rules = '当前应用已关闭回调域名校验，因此无论是否配置域名白名单都允许调用';
}
?>
<style>
label > span.required {
    color: #ff4d4d;
}
.domainitem{margin-top: -5px;margin-bottom: -6px;}
</style>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="./apps.php">应用列表</a></li>
						<li class="breadcrumb-item active">应用详情</li>
					</ol>
				</div>
				<h4 class="page-title">应用详情</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-sm-12 col-md-10 col-lg-8 contents" style="margin: 0 auto;float: none;">
			<div class="card">
				<div class="card-body">
<?php if(!$row){?><div class="alert alert-danger alert-dismissible fade show" role="alert">
						<strong>该应用不存在</strong>
					</div>
<?php }else{?>
<?php if($mod=='domain'){?>
					<h5>修改回调域名白名单</h5><hr/>
					<div class="alert alert-info alert-dismissible fade show" role="alert"><font color="green"><?php echo $rules?></font></div>
					<ul class="list-group">
						<?php echo $domaintext2?>
						<li class="list-group-item"><form onsubmit="return addDomain()" method="POST"><input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>"><input type="hidden" name="appid" value="<?php echo $row['appid']?>">
						<div class="form-group"><div class="input-group">
						<input type="text" class="form-control" name="domain" value="" required>
						<div class="input-group-append"><button class="btn btn-outline-success waves-effect waves-light" type="submit">添加域名</button></div>
						</div></div>
						</form></li>
					</ul>
					<a href="appinfo.php?appid=<?php echo $row['appid']?>">返回应用详情</a>
<?php }else{?>
					<h5>查看应用信息</h5><hr/>
					<form class="form-horizontal devform">
						<div class="form-group">
							<label>接口地址</label>
							<div class="input-group">
								<input type="text" class="form-control" name="apiurl" value="<?php echo $siteurl?>" readonly>
								<div class="input-group-append">
									<button type="button" class="btn btn-outline-info copy-btn" title="复制接口地址" data-clipboard-text="<?php echo $siteurl?>"><i class="far fa-copy"></i></button>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label>APPID</label>
							<div class="input-group">
								<input type="text" class="form-control" name="appid" value="<?php echo $row['appid']?>" readonly>
								<div class="input-group-append">
									<button type="button" class="btn btn-outline-info copy-btn" title="复制APPID" data-clipboard-text="<?php echo $row['appid']?>"><i class="far fa-copy"></i></button>
								</div>
							</div>
						</div>
						<div class="form-group">
							<label>APPKEY</label>
							<div class="input-group">
								<input type="text" class="form-control" name="appkey" value="<?php echo $row['appkey']?>" readonly>
								<div class="input-group-append">
									<button type="button" class="btn btn-outline-info copy-btn" title="复制APPKEY" data-clipboard-text="<?php echo $row['appkey']?>"><i class="far fa-copy"></i></button>
								</div>
							</div>
							<a href="javascript:resetAppkey(<?php echo $row['appid']?>)" class="btn btn-outline-danger btn-sm mt-2">重置APPKEY</a>
						</div>
						<div class="form-group">
							<label>回调域名白名单 <a href="appinfo.php?mod=domain&appid=<?php echo $row['appid']?>">[修改]</a></label>
							<textarea class="form-control" name="domains" rows="5" readonly><?php echo $domaintext?></textarea>
						</div>
					</form>
					<h5>编辑应用信息</h5><hr/>
					<form class="form-horizontal devform" onsubmit="return editSubmit()" id="form-info"><input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>"><input type="hidden" name="appid" value="<?php echo $row['appid']?>">
						<div class="form-group">
							<label>应用名称 <span class="required">*</span></label>
							<input type="text" class="form-control" name="name" placeholder="填写应用名称" value="<?php echo $row['name']?>" required>
						</div>
						<div class="form-group">
							<label>应用首页网址 <span class="required">*</span></label>
							<input type="text" class="form-control" name="url" placeholder="填写你的网站首页网址" value="<?php echo $row['url']?>" required>
							<small class="form-text text-muted"><i class="fas fa-info-circle"></i> 请填写已建设好的并且可以访问的网址</small>
						</div>
						
						<div class="form-group">
						<input type="submit" id="submit" value="确定保存" class="btn btn-gradient-primary btn-block waves-effect waves-light"/><br/>
						</div>
					</form>
					<a href="apps.php">返回应用列表</a>
<?php }?>
<?php }?>
				</div><!--end card-body-->
			</div>
		</div><!--end col-->
	</div><!--end row-->

</div><!-- container -->

<?php include 'foot.php';?>
<script src="<?php echo $cdnpublic?>clipboard.js/1.7.1/clipboard.min.js"></script>
<script>
$(document).ready(function(){
var clipboard = new Clipboard('.copy-btn');
clipboard.on('success', function (e) {
	layer.msg('复制成功！', {icon: 1});
});
clipboard.on('error', function (e) {
	layer.msg('复制失败，请长按链接后手动复制', {icon: 2});
});
})
function checkURL(name)
{
	var url = $("input[name='"+name+"']").val();
	if(url == "")return;

	if (url.indexOf(" ")>=0){
		url = url.replace(/ /g,"");
	}
	if (url.toLowerCase().indexOf("http://")<0 && url.toLowerCase().indexOf("https://")<0){
		url = "http://"+url;
	}
	if (url.slice(url.length-1)=="/"){
		url = url.substring(0,url.length-1);
	}
	$("input[name='"+name+"']").val(url);
	return true;
}
function editSubmit(){
	var name = $("input[name='name']").val();
	if(name == ''){
		layer.alert('应用名称不能为空！');return false;
	}
	var url = $("input[name='url']").val();
	if(url == ''){
		layer.alert('应用首页网址不能为空！');return false;
	}
	if(url.indexOf('.')==-1){
		layer.alert('应用首页网址不正确！');return false;
	}
	checkURL('url');
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax2.php?act=appedit',
		data : $("#form-info").serialize(),
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg,{
					icon: 1,
					closeBtn: false
				}, function(){
				  window.location.reload();
				});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
	return false;
}
function resetAppkey(appid){
	var confirmobj = layer.confirm('是否确定重置APPKEY？', {
	  btn: ['确定','取消']
	}, function(){
		$.ajax({
			type : 'POST',
			url : 'ajax2.php?act=resetAppkey',
			data : 'appid='+appid+'&submit=do',
			dataType : 'json',
			success : function(data) {
				if(data.code == 0){
					layer.alert('重置APPKEY成功！', {icon:1}, function(){window.location.reload()});
				}else{
					layer.alert(data.msg, {icon:2});
				}
			},
			error:function(data){
				layer.msg('服务器错误');
				return false;
			}
		});
	}, function(){
		layer.close(confirmobj);
	});
}
function addDomain(){
	var appid = $("input[name='appid']").val();
	var domain = $("input[name='domain']").val();
	if(domain == ''){
		layer.alert('域名不能为空！');return false;
	}
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax2.php?act=addDomain',
		data : {appid:appid, domain:domain},
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg,{
					icon: 1,
					closeBtn: false
				}, function(){
				  window.location.reload()
				});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
	return false;
}
function delDomain(id){
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax2.php?act=delDomain',
		data : {id:id},
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg,{
					icon: 1,
					closeBtn: false
				}, function(){
				  window.location.reload()
				});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
</script>