<?php
/**
 * 用户组设置
**/
include("../includes/common.php");
$title='用户组设置';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<style>
.table>tbody>tr>td{vertical-align: middle;max-width:480px}</style>
<div class="row">
    <div class="col-sm-12 col-md-10 col-lg-8 center-block" style="float: none;">
<?php

$logintype = [];
$rs = $DB->getAll("SELECT * FROM pre_type WHERE status=1 ORDER BY sort ASC");
foreach($rs as $row){
	$logintype[$row['name']] = $row['showname'];
}
unset($rs);

function display_info($info){
	global $logintype;
	$result = '';
	if(!empty($info)){
		$arr = json_decode($info, true);
	}
	foreach($logintype as $name=>$showname){
		if($arr && isset($arr[$name]) && $arr[$name]=='0')continue;
		$result .= '<label><img src="../assets/icon/'.$name.'.png" width="18px" title="'.$showname.'">&nbsp;'.$showname.'</label>&nbsp;&nbsp;';
	}
	return $result;
}

$list = $DB->getAll("SELECT * FROM pre_group");
?>
<div class="modal" id="modal-store" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content animated flipInX">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal"><span
							aria-hidden="true">&times;</span><span
							class="sr-only">Close</span></button>
				<h4 class="modal-title" id="modal-title">用户组修改/添加</h4>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" id="form-store">
					<input type="hidden" name="action" id="action"/>
					<input type="hidden" name="gid" id="gid"/>
					<div class="form-group">
						<label class="col-sm-2 control-label no-padding-right">显示名称</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="name" id="name" placeholder="不要与其他用户组名称重复">
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">登录开关</label>
						<div class="col-sm-10">
<?php
foreach($logintype as $key=>$value)
{
echo '<label><input type="checkbox" name="info['.$key.']" value="1" checked><b>'.$value.'</b></label>&nbsp;&nbsp;';
}
?>
						</div>
					</div>
					<div class="form-group">
						<label class="col-sm-2 control-label">数量上限</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="ucount" id="ucount" placeholder="填写第三方账号数量上限，0或留空为无上限">
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-white" data-dismiss="modal">关闭</button>
				<button type="button" class="btn btn-primary" id="store" onclick="save()">保存</button>
			</div>
		</div>
	</div>
</div>

<div class="panel panel-success">
   <div class="panel-heading"><h3 class="panel-title">系统共有 <b><?php echo count($list);?></b> 个用户组&nbsp;<span class="pull-right"><a href="javascript:addframe()" class="btn btn-default btn-xs"><i class="fa fa-plus"></i> 新增</a></span></h3></div>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>GID</th><th>用户组名称</th><th>可用登录方式</th><th>数量上限</th><th>操作</th></tr></thead>
          <tbody>
<?php
foreach($list as $res)
{
echo '<tr><td><b>'.$res['gid'].'</b></td><td>'.$res['name'].'</td><td>'.display_info($res['info']).'</td><td>'.$res['ucount'].'</td><td><a class="btn btn-xs btn-default" href="./ulist.php?column=gid&value='.$res['gid'].'">用户</a>&nbsp;<a class="btn btn-xs btn-info" onclick="editframe('.$res['gid'].')">编辑</a>&nbsp;<a class="btn btn-xs btn-danger" onclick="delItem('.$res['gid'].')">删除</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
	  <div class="panel-footer">
          <span class="glyphicon glyphicon-info-sign"></span> 提示：未设置用户组的用户是默认用户组
        </div>
	</div>
    </div>
  </div>
<?php include './foot.php';?>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
<script>
function addframe(){
	$("#modal-store").modal('show');
	$("#modal-title").html("新增用户组");
	$("#action").val("add");
	$("#gid").val('');
	$("#name").val('');
	$("#ucount").val('');
}
function editframe(id){
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'GET',
		url : 'ajax_user.php?act=getGroup&gid='+id,
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				$("#modal-store").modal('show');
				$("#modal-title").html("修改用户组");
				$("#action").val("edit");
				$("#gid").val(data.gid);
				$("#name").val(data.name);
				$("#ucount").val(data.ucount);
				if(data.info!=null){
					$.each(data.info, function (i, res) {
						if(res == '0') $("input[name='info["+i+"]']").prop('checked',false);
					})
				}
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
function save(){
	if($("#name").val()==''){
		layer.alert('请确保各项不能为空！');return false;
	}
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	$.ajax({
		type : 'POST',
		url : 'ajax_user.php?act=saveGroup',
		data : $("#form-store").serialize(),
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg,{
					icon: 1,
					closeBtn: false
				}, function(){
				  window.location.reload()
				});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	});
}
function delItem(id) {
	if(id==0){
		layer.msg('系统自带默认用户组不支持删除');
		return false;
	}
	var confirmobj = layer.confirm('你确实要删除此用户组吗？', {
	  btn: ['确定','取消']
	}, function(){
	  $.ajax({
		type : 'GET',
		url : 'ajax_user.php?act=delGroup&gid='+id,
		dataType : 'json',
		success : function(data) {
			if(data.code == 0){
				window.location.reload()
			}else{
				layer.alert(data.msg, {icon: 2});
			}
		},
		error:function(data){
			layer.msg('服务器错误');
			return false;
		}
	  });
	}, function(){
	  layer.close(confirmobj);
	});
}
</script>
</body>
</html>