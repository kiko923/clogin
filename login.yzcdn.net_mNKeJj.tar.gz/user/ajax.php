<?php
include("../includes/common.php");
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

if(!checkRefererHost())exit('{"code":403}');

@header('Content-Type: application/json; charset=UTF-8');

switch($act){
case 'test':
	if(!$conf['test_open'])exit('{"code":-1,"msg":"未开启聚合登录测试"}');
	$appkey = $DB->getColumn("select appkey from pre_apps where appid='{$conf['test_appid']}' limit 1");
	if(!$appkey)exit('{"code":-1,"msg":"测试应用APPID不存在"}');
	$type = isset($_POST['type'])?$_POST['type']:exit('{"code":-1,"msg":"type不能为空"}');
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');

	$Oauth_config['appid'] = $conf['test_appid'];
	$Oauth_config['appkey'] = $appkey;
	$Oauth=new \lib\TestLogin($Oauth_config);
	$arr = $Oauth->login($type);
	exit(json_encode($arr));
break;
case 'login':
	$user=trim($_POST['user']);
	$pass=trim($_POST['pass']);
	if(empty($user) || empty($pass))exit('{"code":-1,"msg":"请确保各项不能为空"}');
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');

	if($conf['captcha_open_login']==1){
		if(!isset($_SESSION['gtserver']))exit('{"code":-1,"msg":"验证加载失败"}');
		if(!verify_captcha())exit('{"code":-1,"msg":"验证失败，请重新验证"}');
	}

	$userrow=$DB->getRow("SELECT * FROM pre_user WHERE user=:user OR email=:user OR phone=:user limit 1", [':user'=>$user]);
	$pass=getMd5Pwd($pass, $userrow['uid']);

	if($userrow && $pass==$userrow['pwd']) {
		$uid = $userrow['uid'];
		if(isset($_SESSION['Oauth_social_type']) && isset($_SESSION['Oauth_social_uid'])){
			if($_SESSION['Oauth_social_type'] == 'qq'){
				$typecolumn = 'qq_uid';
			}elseif($_SESSION['Oauth_social_type'] == 'wx'){
				$typecolumn = 'wx_uid';
			}elseif($_SESSION['Oauth_social_type'] == 'alipay'){
				$typecolumn = 'alipay_uid';
			}
			$DB->update('user', [$typecolumn=>$_SESSION['Oauth_social_uid']], ['uid'=>$uid]);
			unset($_SESSION['Oauth_social_type']);
			unset($_SESSION['Oauth_social_uid']);
		}
		$DB->insert('userlog', ['uid'=>$uid, 'type'=>'用户登录', 'date'=>'NOW()', 'ip'=>$clientip]);
		$session=md5($userrow['user'].$userrow['pwd'].$password_hash);
		$expiretime=time()+604800;
		$token=authcode("{$uid}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
		ob_clean();
		setcookie("user_token", $token, time() + 604800);
		$DB->exec("update `pre_user` set `lasttime`=NOW() where `uid`='$uid'");
		$result=array("code"=>0,"msg"=>"登录成功！正在跳转到用户中心","url"=>"./");
		unset($_SESSION['csrf_token']);
	}else {
		$result=array("code"=>-1,"msg"=>"用户名或密码不正确！");
	}
	exit(json_encode($result));
break;
case 'connect':
	$type = isset($_POST['type'])?$_POST['type']:exit('{"code":-1,"msg":"type不能为空"}');
	if(!$conf['default_appid'])exit('{"code":-1,"msg":"未配置默认应用APPID"}');
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');

	$state = md5(uniqid(rand(), TRUE));
	$_SESSION['Oauth_state'] = $state;
	$redirect_uri = $siteurl.'user/connect.php';

	$connect = new \lib\Connect($conf['default_appid']);
	$arr = $connect->login($type, $redirect_uri, $state);
	exit(json_encode($arr));
break;
case 'captcha':
	$GtSdk = new \lib\GeetestLib($conf['captcha_id'], $conf['captcha_key']);
	$data = array(
		'user_id' => isset($uid)?$uid:'public',
		'client_type' => "web",
		'ip_address' => $clientip
	);
	$result = $GtSdk->pre_process($data);
	$_SESSION['gtserver'] = $result['success'];
	exit(json_encode($result));
break;
case 'sendcode':
	$sendto=htmlspecialchars(strip_tags(trim($_POST['sendto'])));
	if($conf['reg_open']==0)exit('{"code":-1,"msg":"未开放用户注册"}');
	if(isset($_SESSION['send_code_time']) && $_SESSION['send_code_time']>time()-10){
		exit('{"code":-1,"msg":"请勿频繁发送验证码"}');
	}

	if(!isset($_SESSION['gtserver']))exit('{"code":-1,"msg":"验证加载失败"}');
	if(!verify_captcha())exit('{"code":-1,"msg":"验证失败，请重新验证"}');

	if($conf['verifytype']==1){
		$row=$DB->getRow("select * from pre_user where phone=:phone limit 1", [':phone'=>$sendto]);
		if($row){
			exit('{"code":-1,"msg":"该手机号已经注册过用户，如需找回用户信息，请返回登录页面点击找回密码"}');
		}
		$type = 1;
	}else{
		$row=$DB->getRow("select * from pre_user where email=:email limit 1", [':email'=>$sendto]);
		if($row){
			exit('{"code":-1,"msg":"该邮箱已经注册过用户，如需找回用户信息，请返回登录页面点击找回密码"}');
		}
		$type = 0;
	}
	$result = \lib\VerifyCode::send_code('reg', $type, $sendto);
	if($result === true){
		$_SESSION['send_code_time']=time();
		exit('{"code":0,"msg":"succ"}');
	}else{
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}
break;
case 'reg':
	if($conf['reg_open']==0)exit('{"code":-1,"msg":"未开放用户注册"}');
	$user=htmlspecialchars(strip_tags(trim($_POST['user'])));
	$email=htmlspecialchars(strip_tags(trim($_POST['email'])));
	$phone=htmlspecialchars(strip_tags(trim($_POST['phone'])));
	$code=trim($_POST['code']);
	$pwd=trim($_POST['pwd']);

	if(isset($_SESSION['reg_submit']) && $_SESSION['reg_submit']>time()-600){
		exit('{"code":-1,"msg":"请勿频繁注册"}');
	}
	if($conf['verifytype']==1 && empty($phone) || $conf['verifytype']==0 && empty($email) || empty($code) || empty($pwd) || empty($user)){
		exit('{"code":-1,"msg":"请确保各项不能为空"}');
	}
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');
	if (!preg_match('/^[a-zA-Z0-9\x7f-\xff]+$/',$user)) {
		exit('{"code":-1,"msg":"用户名只能为英文、数字与汉字"}');
	} elseif ($DB->getRow("SELECT uid FROM pre_user WHERE user=:user LIMIT 1", [':user'=>$user])) {
		exit('{"code":-1,"msg":"用户名已存在"}');
	} elseif (strlen($pwd) < 6) {
		exit('{"code":-1,"msg":"密码不能低于6位"}');
	}elseif ($pwd == $user) {
		exit('{"code":-1,"msg":"密码不能和用户名相同"}');
	}elseif ($pwd == $email) {
		exit('{"code":-1,"msg":"密码不能和邮箱相同"}');
	}elseif ($pwd == $phone) {
		exit('{"code":-1,"msg":"密码不能和手机号码相同"}');
	}elseif (is_numeric($pwd)) {
		exit('{"code":-1,"msg":"密码不能为纯数字"}');
	}
	if($conf['verifytype']==1){
		if(!is_numeric($phone) || strlen($phone)!=11){
			exit('{"code":-1,"msg":"手机号码不正确"}');
		}
		$row=$DB->getRow("select * from pre_user where phone=:phone limit 1", [':phone'=>$phone]);
		if($row){
			exit('{"code":-1,"msg":"该手机号已经注册过用户，如需找回用户信息，请返回登录页面点击找回密码"}');
		}
	}else{
		if(!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $email)){
			exit('{"code":-1,"msg":"邮箱格式不正确"}');
		}
		$row=$DB->getRow("select * from pre_user where email=:email limit 1", [':email'=>$email]);
		if($row){
			exit('{"code":-1,"msg":"该邮箱已经注册过用户，如需找回用户信息，请返回登录页面点击找回密码"}');
		}
	}
	if($conf['verifytype']==1){
		$sendto = $phone;
		$type = 1;
	}else{
		$sendto = $email;
		$type = 0;
	}
	$result = \lib\VerifyCode::verify_code('reg', $type, $sendto, $code);
	if($result !== true){
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}
	$sds=$DB->exec("INSERT INTO `pre_user` (`user`, `money`, `email`, `phone`, `addtime`, `lasttime`, `status`) VALUES (:user, '0.00', :email, :phone, NOW(), NOW(), 1)", [':user'=>$user, ':email'=>$email, ':phone'=>$phone]);
	$uid=$DB->lastInsertId();
	if($sds){
		$pwd = getMd5Pwd($pwd, $uid);
		$DB->exec("update `pre_user` set `pwd` ='{$pwd}' where `uid`='$uid'");
		\lib\VerifyCode::void_code();
		$_SESSION['reg_submit']=time();
		unset($_SESSION['csrf_token']);

		$DB->insert('userlog', ['uid'=>$uid, 'type'=>'用户登录', 'date'=>'NOW()', 'ip'=>$clientip]);
		$session=md5($user.$pwd.$password_hash);
		$expiretime=time()+604800;
		$token=authcode("{$uid}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
		ob_clean();
		setcookie("user_token", $token, time() + 604800);
		$result=array("code"=>0,"msg"=>"注册成功！即将跳转到用户中心","url"=>"./");
	}else{
		$result=array("code"=>-1,"msg"=>"注册失败！".$DB->error());
	}
	exit(json_encode($result));
break;
case 'sendcode2':
	$verifytype=$_POST['type'];
	$sendto=htmlspecialchars(strip_tags(trim($_POST['sendto'])));
	if(isset($_SESSION['send_code_time']) && $_SESSION['send_code_time']>time()-10){
		exit('{"code":-1,"msg":"请勿频繁发送验证码"}');
	}

	if(!isset($_SESSION['gtserver']))exit('{"code":-1,"msg":"验证加载失败"}');
	if(!verify_captcha())exit('{"code":-1,"msg":"验证失败，请重新验证"}');

	if($verifytype=='phone'){
		$userrow=$DB->getRow("select * from pre_user where phone=:phone limit 1", [':phone'=>$sendto]);
		if(!$userrow){
			exit('{"code":-1,"msg":"该手机号未找到对应用户"}');
		}
		$type = 1;
	}else{
		$userrow=$DB->getRow("select * from pre_user where email=:email limit 1", [':email'=>$sendto]);
		if(!$userrow){
			exit('{"code":-1,"msg":"该邮箱未找到对应用户"}');
		}
		$type = 0;
	}
	$result = \lib\VerifyCode::send_code('find', $type, $sendto);
	if($result === true){
		$_SESSION['send_code_time']=time();
		exit(json_encode(['code'=>0, 'msg'=>'succ']));
	}else{
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}
break;
case 'findpwd':
	$verifytype=$_POST['type'];
	$account=htmlspecialchars(strip_tags(trim($_POST['account'])));
	$code=trim($_POST['code']);
	$pwd=trim($_POST['pwd']);

	if(empty($account) || empty($code) || empty($pwd)){
		exit('{"code":-1,"msg":"请确保各项不能为空"}');
	}
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');
	if (strlen($pwd) < 6) {
		exit('{"code":-1,"msg":"密码不能低于6位"}');
	}elseif ($pwd == $account && $verifytype=='email') {
		exit('{"code":-1,"msg":"密码不能和邮箱相同"}');
	}elseif ($pwd == $account && $verifytype=='phone') {
		exit('{"code":-1,"msg":"密码不能和手机号码相同"}');
	}elseif (is_numeric($pwd)) {
		exit('{"code":-1,"msg":"密码不能为纯数字"}');
	}
	if($verifytype=='phone'){
		if(!is_numeric($account) || strlen($account)!=11){
			exit('{"code":-1,"msg":"手机号码不正确"}');
		}
		$userrow=$DB->getRow("select * from pre_user where phone=:account limit 1", [':account'=>$account]);
		if(!$userrow){
			exit('{"code":-1,"msg":"该手机号未找到注册商户"}');
		}
	}else{
		if(!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $account)){
			exit('{"code":-1,"msg":"邮箱格式不正确"}');
		}
		$userrow=$DB->getRow("select * from pre_user where email=:account limit 1", [':account'=>$account]);
		if(!$userrow){
			exit('{"code":-1,"msg":"该邮箱未找到注册商户"}');
		}
	}
	if($verifytype=='phone'){
		$type = 1;
	}else{
		$type = 0;
	}
	$result = \lib\VerifyCode::verify_code('find', $type, $account, $code);
	if($result !== true){
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}

	$pwd = getMd5Pwd($pwd, $userrow['uid']);
	$sqs=$DB->exec("update `pre_user` set `pwd` ='{$pwd}' where `uid`='{$userrow['uid']}'");
	if($sqs!==false){
		\lib\VerifyCode::void_code();
		exit('{"code":1,"msg":"重置密码成功！您的用户名：'.$userrow['user'].'"}');
	}else{
		exit('{"code":-1,"msg":"重置密码失败！'.$DB->error().'"}');
	}
break;
default:
	exit('{"code":-4,"msg":"No Act"}');
break;
}