<?php
include("./includes/common.php");
?>
<!DOCTYPE html>
<html lang="cn">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<link rel="shortcut icon" href="favicon.ico">
		
		<meta content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" name="viewport">
		<meta content="yes" name="apple-mobile-web-app-capable">
		<meta content="black" name="apple-mobile-web-app-status-bar-style">
		<meta content="telephone=no" name="format-detection">
		<meta content="email=no" name="format-detection">
		
		<title>对接插件下载 - <?php echo $conf['title']?></title>
		<meta name="keywords" content="<?php echo $conf['keywords']?>">
		<meta name="description" content="<?php echo $conf['description']?>" />
		
		<link href="<?php echo $cdnpublic?>twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
		<link href="<?php echo $cdnpublic?>font-awesome/5.14.0/css/all.min.css" rel="stylesheet">
		
		<link href="./assets/css/style.css" rel="stylesheet">
<style>
body{padding-top: 0;}
.clogin-header{position: unset;}
.card{margin-bottom: 10px;}
</style>
	</head>
	<body>
		<header class="clogin-header">
			<div class="container">
				<nav class="navbar navbar-expand-lg navbar-light">
					<a class="navbar-brand" href="../">
						<img src="/assets/img/logo.png"> <?php echo $conf['sitename']?>
						</a>
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse" id="navbarSupportedContent">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item active">
								<a class="nav-link" href="../">首页</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/user/">用户中心</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/doc.php">开发文档</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/plugins.php">对接插件</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/user/test.php">接口测试</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="/agreement.php">隐私政策</a>
							</li>
							<li class="nav-item">
								<a class="nav-link" href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes" target="_blank">联系我们</a>
							</li>

						</ul>
					</div>
				</nav>
			</div>
		</header>
		
		<section class="clogin-section clogin-info">
			<div class="container">
				<div class="clogin-section-title text-center">
					<h2>本站对接插件下载</h2>
				</div>
<div class="row">
<div class="col-md-3">
<div class="list-group">
  <a href="#doc1" class="list-group-item list-group-item-action">WordPress博客对接插件</a>
  <a href="#doc2" class="list-group-item list-group-item-action">Z-Blog博客对接插件</a>
  <a href="#doc3" class="list-group-item list-group-item-action">Emlog博客对接插件</a>
  <a href="#doc4" class="list-group-item list-group-item-action">Typecho博客对接插件</a>
  <a href="#doc5" class="list-group-item list-group-item-action">Discuz!X论坛对接插件</a>
  <a href="#doc6" class="list-group-item list-group-item-action">魔方财务系统对接插件</a>
  <a href="#doc7" class="list-group-item list-group-item-action">SWAPIDC对接插件</a>
  <a href="#doc8" class="list-group-item list-group-item-action">WHMCS对接插件</a>
  <a href="#doc9" class="list-group-item list-group-item-action">苹果CMSV10对接插件</a>
  <a href="#doc10" class="list-group-item list-group-item-action">HYBBS对接插件</a>
  <a href="#doc11" class="list-group-item list-group-item-action">Eyoucms对接插件</a>
  <a href="#doc12" class="list-group-item list-group-item-action">XiunoBBS对接插件</a>
  <a href="#doc13" class="list-group-item list-group-item-action">FastAdmin对接插件</a>
  <a href="#doc14" class="list-group-item list-group-item-action">阿帕云对接插件</a>
  <a href="#doc15" class="list-group-item list-group-item-action">XunRuiCMS对接插件</a>
  <a href="#doc16" class="list-group-item list-group-item-action">魔方业务V10对接插件</a>
</div>
</div>
<div class="col-md-9">

<div class="card" id="doc1" style="">
<div class="card-header" style="color:#FF0000">
WordPress博客对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/wordpress_plugin.zip" target="_blank">wordpress_plugin.zip</a>
<!--丨<a href="./cj/zibll.webp" target="_blank">子比主题对接教程</a>-->
<p>
<br>
使用方法：
<br><br>
上传到 /wp-content/plugins 目录解压，然后在后台插件列表启用即可。包含QQ、微信、支付宝、微博、百度、华为、钉钉、谷歌、微软、Facebook、Twitter登录方式。
</p>
</div>
</div>

<div class="card" id="doc2" style="">
<div class="card-header" style="color:#FF0000">
Z-Blog博客对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/zblog_laycenter_plugin.zip" target="_blank">zblog_laycenter_plugin.zip</a>
<p>
<br>
使用方法：
<br><br>
需要先安装LayCenter插件，然后上传到 /zb_users/LayCenter目录解压，没有LayCenter文件夹就新建一个，然后在LayCenter后台应用列表启用即可。包含QQ、微信、支付宝、微博4种登录方式。<br><br>
<a href="//dl.wicdn.com/clogin/plugins/zblog_ytuser_plugin.zip" target="_blank">zblog_ytuser_plugin.zip</a><br><br>
需要先安装YtUser插件，然后上传到 /zb_users/plugin/YtUser 目录解压覆盖，在login.php里面修改接口地址，在后台填写QQ登录的appid和appkey
</p>
</div>
</div>

<div class="card" id="doc3" style="">
<div class="card-header" style="color:#FF0000">
Emlog博客对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/emlog_plugin.zip" target="_blank">插件下载</a>（适用于emlog5.3.1版本）
<br><br>
<a href="//dl.wicdn.com/clogin/plugins/emlog_pro_plugin.zip" target="_blank">插件下载</a>（适用于emlog pro版本）
<p>
<br>
使用方法：
<br><br>
上传到 /content/plugins 目录解压，然后在后台插件列表开启，包含QQ和微信登录方式，由于emlog对于用户权限的控制问题，仅支持管理员或作者账号绑定快捷登录。
</p>
</div>
</div>

<div class="card" id="doc4" style="">
<div class="card-header" style="color:#FF0000">
Typecho博客对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/typecho_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到 /usr/plugins 目录解压，在后台插件列表开启即可，包含QQ、微信、支付宝、微博登录方式。插件开启后需要自行修改模板代码，加入登录按钮代码。<br><br>
<a href="//dl.wicdn.com/clogin/plugins/Request.zip" target="_blank">Request.zip</a><br><br>
Typecho 1.2.1版本有bug，登录方式无法保存，修复方法，下载Request.zip解压到/var/Typecho目录下。
</p>
</div>
</div>

<div class="card" id="doc5" style="">
<div class="card-header" style="color:#FF0000">
Discuz!X论坛对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/discuzx_plugins.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到 /source/plugin 目录解压，然后在后台插件列表就可以看到。包含QQ和微信2种登录方式，兼容DiscuzX 3.2~3.4版本，兼容utf-8、gbk、big5编码。
</p>
</div>
</div>

<div class="card" id="doc6" style="">
<div class="card-header" style="color:#FF0000">
魔方财务系统对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/idcsmart.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到 /modules/oauth 目录解压（测试版上传到 /public/plugins/oauth），然后在后台【系统】->【第三方登录】配置并开启即可。包含QQ、微信、支付宝、微博、百度5种登录方式。
</p>
</div>
</div>


<div class="card" id="doc7">
<div class="card-header" style="color:#FF0000">
SWAPIDC对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/swapidc_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到 /swap_mac/swap_plugins 目录解压，导入install.sql到数据库，然后在后台插件设置开启。包含QQ、微信、微博、支付宝4种登录方式。
</p>
</div>
</div>

<div class="card" id="doc8" style=" ">
<div class="card-header" style="color:#FF0000">
WHMCS对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/whmcs_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
直接上传到根目录解压，在后台“插件模块”开启，并配置信息，然后在顶部“插件管理”->“<?php echo $conf['sitename']?>”，查看模板变量，自行修改模板文件。包含QQ、微信、微博、支付宝4种登录方式。只支持whmcs 8.x版本
</p>
</div>
</div>

<div class="card" id="doc9" style=" ">
<div class="card-header" style="color:#FF0000">
苹果CMSV10对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/clogin_maccms10.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到根目录解压，在后台“整合登录配置”配置好密钥开启即可。包含QQ和微信登录方式。如果需要改登录接口地址，是在/extend/login/ThinkOauth.php里面。
</p>
</div>
</div>

<div class="card" id="doc10" style=" ">
<div class="card-header" style="color:#FF0000">
HYBBS对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/hybbs_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到 /Plugin 目录解压，包含QQ、微信登录方式。
</p>
</div>
</div>

<div class="card" id="doc11" style=" ">
<div class="card-header" style="color:#FF0000">
Eyoucms对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/eyoucms_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到根目录解压覆盖，直接替换原有的QQ、微信、微博登录。
</p>
</div>
</div>

<div class="card" id="doc12" style=" ">
<div class="card-header" style="color:#FF0000">
XiunoBBS对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/xiunobbs_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到根目录解压覆盖，直接替换原有的QQ、微信、微博登录。
</p>
</div>
</div>

<div class="card" id="doc13" style=" ">
<div class="card-header" style="color:#FF0000">
FastAdmin对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/fastadmin_addon.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
1.网站目录里找到  <font color="red">application/config.php</font>  文件，将  <font color="red">unknownsources</font>  的值置为  <font color="red">true</font>  。<br>
<br>2.修改网站根目录 <font color="red">.env</font>文件，将  <font color="red">debug</font>  的值置为  <font color="red">true</font> <br>
<br>3.网站目录里找到 <font color="red">vendor/karsonzhang/fastadmin-addons/src/addons/service.php</font>  文件 , 将 <font color="red">Service::valid($params);</font>  注释掉然后在后台插件管理，点击本地安装。
</p>
</div>
</div>

<div class="card" id="doc14" style=" ">
<div class="card-header" style="color:#FF0000">
阿帕云对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/apayun_plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
需要申请阿帕云开发者权限，然后上传插件，在后台我开发的插件里面安装，包含QQ、微信、微博、支付宝、百度登录方式。
</p>
</div>
</div>

<div class="card" id="doc15" style=" ">
<div class="card-header" style="color:#FF0000">
XunRuiCMS对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/xunruicms-plugin.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到根目录解压覆盖，包含QQ、微信、微博3种登录方式。分别在文件里面修改接口地址，在后台填写appid和appkey
</p>
</div>
</div>

<div class="card" id="doc16" style=" ">
<div class="card-header" style="color:#FF0000">
魔方业务V10对接<?php echo $conf['sitename']?>插件
</div>
<div class="card-body">
<a href="//dl.wicdn.com/clogin/plugins/idcsmart_business.zip" target="_blank">插件下载</a>
<p>
<br>
使用方法：
<br><br>
上传到 /public/plugins/addon 解压，在后台应用列表安装，在前台导航设置添加用户中心的导航链接。包含QQ、微信、微博、支付宝、百度等登录方式。
</p>
</div>
</div>

</div>
</div>

			</div>
		</section>

<footer class="clogin-footer text-center">
			<p>Copyright &copy;<?php echo date("Y")?> <?php echo $conf['sitename']?>&nbsp;&nbsp;<?php echo $conf['footer']?></p>
		</footer>
		
		<script src="<?php echo $cdnpublic?>jquery/3.4.1/jquery.min.js"></script>
		<script src="<?php echo $cdnpublic?>twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
		
	</body>
</html>