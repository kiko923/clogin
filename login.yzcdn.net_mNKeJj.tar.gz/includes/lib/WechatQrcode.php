<?php

namespace lib;
use Exception;

// 微信扫码登录类
class WechatQrcode
{
	private $appid;
	private $appsecret;
	private $access_token;

	public function __construct($appid, $appsecret)
	{
		$this->appid = $appid;
		$this->appsecret = $appsecret;
	}

	// 获取用户信息
	public function getUserInfo($openId){
		$access_token = $this->getAccessToken();
		$url = 'https://api.weixin.qq.com/cgi-bin/user/info?access_token='.$access_token.'&openid='.$openId.'&lang=zh_CN';
		$res = get_curl($url);
		$arr = json_decode($res, true);
		if(isset($arr['openid'])){
			return $arr;
		}else{
			throw new Exception('获取用户信息失败.'.$arr['errmsg']);
		}
	}

	// 获取带参数的二维码
	public function createWechatQrcode($scene_str, $expire_seconds = 600){
		$access_token = $this->getAccessToken();
		$url = 'https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token='.$access_token;
		$param = [
			'expire_seconds'=>$expire_seconds,
			'action_name'=>'QR_STR_SCENE',
			'action_info'=>[
				'scene'=>[
					'scene_str'=>$scene_str
				]
			]
		];
		$post = json_encode($param);
		$res = $this->httpPost($url, $post);
		$arr = json_decode($res, true);
		if(isset($arr['url'])){
			return $arr['url'];
		}else{
			throw new Exception('生成二维码失败.'.$arr['errmsg']);
		}
	}

	private function getAccessToken() {
		global $DB;
		if(!empty($this->access_token)) return $this->access_token;
		$cachekey = 'wxtoken_'.$this->appid;
		$DB->beginTransaction();
		$data = $DB->getColumn("SELECT v FROM pre_cache WHERE k=:key LIMIT 1 FOR UPDATE", [':key'=>$cachekey]);
		$arr = json_decode($data, true);
		if($arr['access_token'] && strtotime($arr['expiretime']) - 200 >= time()){
			$DB->rollback();
			$this->access_token = $arr['access_token'];
			return $this->access_token;
		}

		$url = "https://api.weixin.qq.com/cgi-bin/stable_token";
		$post = json_encode(['grant_type'=>'client_credential', 'appid'=>$this->appid, 'secret'=>$this->appsecret]);
		$output = get_curl($url, $post);
		$res = json_decode($output, true);
		if (isset($res['access_token'])) {
			$arr['expire_time'] = time() + $res['expires_in'];
			$arr['access_token'] = $res['access_token'];
			$data = json_encode($arr);
			$DB->exec("REPLACE INTO pre_cache VALUES (:key, :value, :expire)", [':key'=>$cachekey, ':value'=>$data, ':expire'=>0]);
			$this->access_token = $res['access_token'];
			$DB->commit();
			return $this->access_token;
		}elseif(isset($res['errmsg'])){
			$DB->rollback();
			throw new Exception('AccessToken获取失败：'.$res['errmsg']);
		}else{
			$DB->rollback();
			throw new Exception('AccessToken获取失败');
		}
	}

	public function wxa_generate_scheme($path, $query, $expire = 600){
		$access_token = $this->getAccessToken();
		$url = "https://api.weixin.qq.com/wxa/generatescheme?access_token=".$access_token;
		$data = ['jump_wxa'=>['path'=>$path, 'query'=>$query]];
		if($expire>0){
			$data['is_expire'] = true;
			$data['expire_time'] = time()+$expire;
		}
		$output = get_curl($url, json_encode($data));
		$res = json_decode($output, true);
		if ($res && $res['errcode'] == 0) {
			return $res['openlink'];
		}else{
			throw new Exception('urlscheme生成失败：'.$res['errmsg']);
		}
	}

	public function wxa_jscode2session($code){
		$param = [
			'appid' => $this->appid,
			'secret' => $this->appsecret,
			'js_code' => $code,
			'grant_type' => 'authorization_code'
		];
		$url = 'https://api.weixin.qq.com/sns/jscode2session?'.http_build_query($param);
		$output = get_curl($url);
		$res = json_decode($output, true);
		if ($res && $res['errcode'] == 0) {
			return $res;
		}else{
			throw new Exception('登录凭证获取失败：'.$res['errmsg']);
		}
	}

	private function httpPost($url,$data){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, $url);
		curl_setopt($curl, CURLOPT_HTTPHEADER, array("Content-Type: application/json; charset=utf-8"));
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_TIMEOUT, 10);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($curl, CURLOPT_POST, 1);
		curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
		$res = curl_exec($curl);
		curl_close($curl);
		return $res;
	}
}
