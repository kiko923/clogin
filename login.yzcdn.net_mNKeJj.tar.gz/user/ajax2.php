<?php
include("../includes/common.php");
if($islogin2==1){}else exit('{"code":-3,"msg":"No Login"}');
$act=isset($_GET['act'])?daddslashes($_GET['act']):null;

if(!checkRefererHost())exit('{"code":403}');

@header('Content-Type: application/json; charset=UTF-8');

switch($act){
case 'getcount':
	$lastday=date("Y-m-d",strtotime("-1 day")).' 00:00:00';
	$today=date("Y-m-d").' 00:00:00';

	$count1=$DB->getColumn("SELECT count(*) FROM pre_apps WHERE uid={$uid} AND status<4");
	$count2=$DB->getColumn("SELECT count(*) FROM pre_accounts WHERE uid={$uid}");
	$count3=$DB->getColumn("SELECT count(*) FROM pre_accounts WHERE uid={$uid} AND TO_DAYS(NOW())-TO_DAYS(addtime)=0");
	$count4=$DB->getColumn("SELECT count(*) FROM pre_accounts WHERE uid={$uid} AND TO_DAYS(NOW())-TO_DAYS(addtime)=1");

	$list = [];
	$applist = $DB->getAll("SELECT appid,name,status FROM pre_apps WHERE uid={$uid} AND status<4 ORDER BY appid DESC LIMIT 5");
	foreach($applist as $row){
		$accounts = $DB->getColumn("SELECT count(*) FROM pre_accounts WHERE appid={$row['appid']}");
		$logs = $DB->getColumn("SELECT count(*) FROM pre_logs WHERE appid={$row['appid']} AND status=1");
		$list[] = ['appid'=>$row['appid'], 'name'=>$row['name'], 'status'=>$row['status'], 'accounts'=>$accounts, 'logs'=>$logs];
	}

	foreach($list as $val){
		$key_arrays[]=$val['accounts'];
	}
	array_multisort($key_arrays,SORT_DESC,SORT_NUMERIC,$list);

	$result=['code'=>0, 'count1'=>$count1, 'count2'=>$count2, 'count3'=>$count3, 'count4'=>$count4, 'list'=>$list];
	exit(json_encode($result));
break;
case 'sendcode':
	$situation=trim($_POST['situation']);
	$target=htmlspecialchars(strip_tags(trim($_POST['target'])));
	if(isset($_SESSION['send_code_time']) && $_SESSION['send_code_time']>time()-10){
		exit('{"code":-1,"msg":"请勿频繁发送验证码"}');
	}
	if(!isset($_SESSION['gtserver']))exit('{"code":-1,"msg":"验证加载失败"}');
	if(!verify_captcha($uid))exit('{"code":-1,"msg":"验证失败，请重新验证"}');

	if($conf['verifytype']==1 || $situation=='bindphone'){
		if($situation=='bind' || $situation=='bindphone'){
			if(empty($target) || strlen($target)!=11){
				exit('{"code":-1,"msg":"请填写正确的手机号码！"}');
			}
			if($target==$userrow['phone']){
				exit('{"code":-1,"msg":"你填写的手机号码和之前一样"}');
			}
			$row=$DB->getRow("select * from pre_user where phone=:phone limit 1", [':phone'=>$target]);
			if($row){
				exit('{"code":-1,"msg":"该手机号码已经绑定过其它用户"}');
			}
		}else{
			if(empty($userrow['phone']) || strlen($userrow['phone'])!=11){
				exit('{"code":-1,"msg":"请先绑定手机号码！"}');
			}
			$target=$userrow['phone'];
		}
		$type = 1;
	}else{
		if($situation=='bind'){
			if(!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $target)){
				exit('{"code":-1,"msg":"邮箱格式不正确"}');
			}
			if($target==$userrow['email']){
				exit('{"code":-1,"msg":"你填写的邮箱和之前一样"}');
			}
			$row=$DB->getRow("select * from pre_user where email=:email limit 1", [':email'=>$target]);
			if($row){
				exit('{"code":-1,"msg":"该邮箱已经绑定过其它用户"}');
			}
		}else{
			if(empty($userrow['email']) || strpos($userrow['email'],'@')===false){
				exit('{"code":-1,"msg":"请先绑定邮箱！"}');
			}
			$target=$userrow['email'];
		}
		$type = 0;
	}
	$result = \lib\VerifyCode::send_code('edit', $type, $target, $uid);
	if($result === true){
		$_SESSION['send_code_time']=time();
		exit(json_encode(['code'=>0, 'msg'=>'succ']));
	}else{
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}
break;
case 'verifycode':
	$code=trim($_POST['code']);
	if($conf['verifytype']==1){
		$sendto = $userrow['phone'];
		$type = 1;
	}else{
		$sendto = $userrow['email'];
		$type = 0;
	}
	$result = \lib\VerifyCode::verify_code('edit', $type, $sendto, $code, $uid);
	if($result === true){
		$_SESSION['verify_ok']=$uid;
		\lib\VerifyCode::void_code();
		exit(json_encode(['code'=>1, 'msg'=>'succ']));
	}else{
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}
break;
case 'edit_info':
	$email=htmlspecialchars(strip_tags(trim($_POST['email'])));
	$qq=htmlspecialchars(strip_tags(trim($_POST['qq'])));

	if($qq==null){
		exit('{"code":-1,"msg":"请确保每项都不为空"}');
	}
	if(strlen($qq)<5 || strlen($qq)>10 || !is_numeric($qq)){
		exit('{"code":-1,"msg":"请填写正确的QQ"}');
	}
	if($conf['verifytype']==1){
		if(!preg_match('/^[A-z0-9._-]+@[A-z0-9._-]+\.[A-z0-9._-]+$/', $email)){
			exit('{"code":-1,"msg":"邮箱格式不正确"}');
		}
		$sqs = $DB->update('user', ['email'=>$email, 'qq'=>$qq], ['uid'=>$uid]);
	}else{
		$sqs = $DB->update('user', ['qq'=>$qq], ['uid'=>$uid]);
	}
	if($sqs!==false){
		exit('{"code":1,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"保存失败！'.$DB->error().'"}');
	}
break;
case 'edit_bind':
	$email=htmlspecialchars(strip_tags(trim($_POST['email'])));
	$phone=htmlspecialchars(strip_tags(trim($_POST['phone'])));
	$code=trim($_POST['code']);

	if($code==null || $email==null && $phone==null){
		exit('{"code":-1,"msg":"请确保每项都不为空"}');
	}
	if(empty($_SESSION['verify_ok']) || $_SESSION['verify_ok']!=$uid){
		if($conf['verifytype']==1 && !empty($userrow['phone']) && strlen($userrow['phone'])==11){
			exit('{"code":2,"msg":"请先完成验证"}');
		}elseif($conf['verifytype']==0 && !empty($userrow['email']) && strpos($userrow['email'],'@')!==false && !empty($email) && empty($phone)){
			exit('{"code":2,"msg":"请先完成验证"}');
		}
	}
	if($conf['verifytype']==1 || $conf['verifytype']==0 && empty($email) && !empty($phone)){
		$sendto = $phone;
		$type = 1;
	}else{
		$sendto = $email;
		$type = 0;
	}
	$result = \lib\VerifyCode::verify_code('edit', $type, $sendto, $code, $uid);
	if($result !== true){
		exit(json_encode(['code'=>-1, 'msg'=>$result]));
	}
	if($conf['verifytype']==1 || $conf['verifytype']==0 && empty($email) && !empty($phone)){
		$sqs=$DB->update('user', ['phone'=>$phone], ['uid'=>$uid]);
	}else{
		$sqs=$DB->update('user', ['email'=>$email], ['uid'=>$uid]);
	}
	if($sqs!==false){
		exit('{"code":1,"msg":"succ"}');
	}else{
		exit('{"code":-1,"msg":"保存失败！'.$DB->error().'"}');
	}
break;
case 'checkbind':
	if($conf['verifytype']==1 && (empty($userrow['phone']) || strlen($userrow['phone'])!=11)){
		exit('{"code":1,"msg":"bind"}');
	}elseif($conf['verifytype']==0 && (empty($userrow['email']) || strpos($userrow['email'],'@')===false)){
		exit('{"code":1,"msg":"bind"}');
	}elseif(isset($_SESSION['verify_ok']) && $_SESSION['verify_ok']===$uid){
		exit('{"code":1,"msg":"bind"}');
	}else{
		exit('{"code":2,"msg":"need verify"}');
	}
break;
case 'edit_pwd':
	$oldpwd=trim($_POST['oldpwd']);
	$newpwd=trim($_POST['newpwd']);
	$newpwd2=trim($_POST['newpwd2']);

	if(!empty($userrow['pwd']) && $oldpwd==null || $newpwd==null || $newpwd2==null){
		exit('{"code":-1,"msg":"请确保每项都不为空"}');
	}
	if(!empty($userrow['pwd']) && getMd5Pwd($oldpwd, $uid)!=$userrow['pwd']){
		exit('{"code":-1,"msg":"旧密码不正确"}');
	}
	if($newpwd!=$newpwd2){
		exit('{"code":-1,"msg":"两次输入密码不一致！"}');
	}
	if($oldpwd==$newpwd){
		exit('{"code":-1,"msg":"旧密码和新密码相同！"}');
	}
	if (strlen($newpwd) < 6) {
		exit('{"code":-1,"msg":"新密码不能低于6位"}');
	}elseif ($newpwd == $userrow['email']) {
		exit('{"code":-1,"msg":"新密码不能和邮箱相同"}');
	}elseif ($newpwd == $userrow['phone']) {
		exit('{"code":-1,"msg":"新密码不能和手机号码相同"}');
	}elseif (is_numeric($newpwd)) {
		exit('{"code":-1,"msg":"新密码不能为纯数字"}');
	}
	$pwd = getMd5Pwd($newpwd, $uid);
	$sqs=$DB->exec("update `pre_user` set `pwd` ='{$pwd}' where `uid`='$uid'");
	if($sqs!==false){
		exit('{"code":1,"msg":"修改密码成功！请牢记新密码"}');
	}else{
		exit('{"code":-1,"msg":"修改密码失败！'.$DB->error().'"}');
	}
break;
case 'connect':
	$type = isset($_POST['type'])?$_POST['type']:exit('{"code":-1,"msg":"type不能为空"}');
	if(!$conf['default_appid'])exit('{"code":-1,"msg":"未配置默认应用APPID"}');
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');

	$state = md5(uniqid(rand(), TRUE));
	$_SESSION['Oauth_state'] = $state;
	$redirect_uri = $siteurl.'user/connect.php';

	$connect = new \lib\Connect($conf['default_appid']);
	$arr = $connect->login($type, $redirect_uri, $state);
	exit(json_encode($arr));
break;

case 'groupinfo':
	$gid=intval($_POST['gid']);
	$row=$DB->getRow("select * from pre_group where gid='$gid'");
	if(!$row)
		exit('{"code":-1,"msg":"当前会员等级不存在！"}');
	if($row['isbuy']==0)
		exit('{"code":-1,"msg":"当前会员等级无法购买！"}');
	$usergroup=$DB->getRow("select * from pre_group where gid='{$userrow['gid']}'");
	if($usergroup['isbuy']==1 && $usergroup['sort']>$row['sort'])exit('{"code":-1,"msg":"你的会员等级高于此会员等级，无法降级购买"}');
	if($gid==$userrow['gid'] && $userrow['gexpire']==null)exit('{"code":-1,"msg":"你当前的会员等级有效期已是永久"}');
	if($row['expire']==0)$expire='永久';
	else $expire=$row['expire'].'个月';
	$result = ['code'=>0,'msg'=>'succ','gid'=>$gid,'name'=>$row['name'],'price'=>$row['price'],'expire'=>$row['expire']];
	exit(json_encode($result));
break;
case 'groupbuy':
	$gid=intval($_POST['gid']);
	$row=$DB->getRow("select * from pre_group where gid='$gid'");
	if(!$row)
		exit('{"code":-1,"msg":"当前会员等级不存在！"}');
	if($row['isbuy']==0)
		exit('{"code":-1,"msg":"当前会员等级无法购买！"}');
	$usergroup=$DB->getRow("select * from pre_group where gid='{$userrow['gid']}'");
	if($usergroup['isbuy']==1 && $usergroup['sort']>$row['sort'])exit('{"code":-1,"msg":"你的会员等级高于此会员等级，无法降级购买"}');
	if($gid==$userrow['gid'] && $userrow['gexpire']==null)exit('{"code":-1,"msg":"你当前的会员等级有效期已是永久"}');
	if($conf['app_audit'] == 1 && $conf['app_buylimit'] == 1){
		$appcount=$DB->getColumn("SELECT count(*) FROM pre_apps WHERE uid={$uid} AND status=1");
		if($appcount==0){
			exit('{"code":-1,"msg":"至少有一个应用通过审核之后，才能购买VIP"}');
		}
	}
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');
	$money = $row['price'];
	$type=trim($_POST['type']);
	$num=intval($_POST['num']);
	if($num<=0 || $num>300)exit('{"code":-1,"msg":"数量不正确"}');
	$money = round($money * $num, 2);
	if($row['expire']>0){
		$expirenum = $num*$row['expire'];
		if($gid==$userrow['gid'])$expire = date("Y-m-d",strtotime("+ {$expirenum} month", strtotime($userrow['gexpire'])));
		else $expire = date("Y-m-d",strtotime("+ {$expirenum} month"));
	}else{
		$expire = null;
	}
	if($type=='rmb'){
		if($money>$userrow['money'])exit('{"code":-1,"msg":"余额不足，请选择其他方式支付"}');
		changeUserMoney($uid, $money, false, '购买会员');
		changeUserGroup($uid, $gid, $expire);
		unset($_SESSION['csrf_token']);
		$result = ['code'=>1, 'msg'=>'购买会员成功！'];
		exit(json_encode($result));
	}else{
		$name = '购买会员:'.$row['name'];
		$trade_no=date("YmdHis").rand(11111,99999);
		$return_url=$siteurl.'user/groupbuy.php?ok=1&trade_no='.$trade_no;
		$input = json_encode(['gid'=>$gid, 'expire'=>$expire]);
		if(!$DB->exec("INSERT INTO `pre_order` (`trade_no`,`uid`,`tid`,`num`,`type`,`addtime`,`name`,`money`,`input`,`ip`,`status`) VALUES (:trade_no, :uid, 1, :num, :type, NOW(), :name, :money, :input, :clientip, 0)", [':trade_no'=>$trade_no, ':uid'=>$uid, ':num'=>$num, ':type'=>$type, ':name'=>$name, ':money'=>$money, ':input'=>$input, ':clientip'=>$clientip]))exit('{"code":-1,"msg":"创建订单失败，请返回重试！"}');
		unset($_SESSION['csrf_token']);
		$result = ['code'=>0, 'orderid'=>$trade_no];
		exit(json_encode($result));
	}
break;

case 'getAppInfo':
	$appid=intval($_GET['appid']);
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	exit(json_encode(['code'=>0, 'status'=>$row['status'], 'note'=>$row['note']]));
break;
case 'appadd':
	$name = trim(strip_tags($_POST['name']));
	$url = trim(strip_tags($_POST['url']));
	$domains = $_POST['domain'];
	if(empty($name) || empty($url) || count($domains)==0)exit('{"code":-1,"msg":"不能为空"}');
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');
	if (!preg_match('/^[a-zA-Z0-9\x7f-\xff]+$/',$name)) {
		exit('{"code":-1,"msg":"应用名称只能为汉字、数字或英文"}');
	}
	if (!preg_match('/http[s]?:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is',$url)) {
		exit('{"code":-1,"msg":"应用首页网址不正确"}');
	}
	$rows=$DB->getRow("select * from pre_apps where name=:name AND status<4 limit 1", [':name'=>$name]);
	if($rows)exit('{"code":-1,"msg":"应用名称已存在！"}');

	$rows=$DB->getRow("select * from pre_apps where uid='$uid' and status=2 limit 1");
	if($rows)exit('{"code":-1,"msg":"当前有待审核状态的应用，请等待审核通过，然后才能继续创建应用"}');

	$rows=$DB->getRow("select * from pre_apps where uid='$uid' and status=3 limit 1");
	if($rows)exit('{"code":-1,"msg":"当前有审核未通过的应用，无法继续创建新应用，如有疑问请联系管理员"}');

	$domainlist = [];
	$i=1;
	foreach($domains as $domain){
		if(!checkdomain($domain))exit('{"code":-1,"msg":"第'.$i.'个回调域名不正确"}');
		if(in_array($domain, $domainlist))exit('{"code":-1,"msg":"第'.$i.'个回调域名重复"}');
		$domainlist[] = $domain;
		$i++;
	}

	$status = $conf['app_audit']==1?2:1;
	$appkey = md5(mt_rand(0,999).time());
	$sql="insert into `pre_apps` (`uid`,`appkey`,`name`,`url`,`addtime`,`type`,`limit`,`status`) values (:uid, :appkey, :name, :url, NOW(), :type, :limit, :status)";
	if($DB->exec($sql, ['uid'=>$uid, 'appkey'=>$appkey, 'name'=>$name, 'url'=>$url, 'type'=>1, 'limit'=>1, 'status'=>$status])!==false){
		$appid=$DB->lastInsertId();
		foreach($domainlist as $domain){
			if(empty($domain))continue;
			$DB->exec("INSERT INTO pre_appdomain (`appid`,`domain`,`addtime`,`status`) VALUES (:appid, :domain, NOW(), 1)", [':appid'=>$appid, ':domain'=>$domain]);
		}
		exit('{"code":0,"msg":"创建应用成功！"}');
	}else
		exit('{"code":-1,"msg":"创建应用失败！['.$DB->error().']"}');
break;
case 'appedit':
	$appid = intval($_POST['appid']);
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	$name = trim(strip_tags($_POST['name']));
	$url = trim(strip_tags($_POST['url']));
	if(empty($name) || empty($url))exit('{"code":-1,"msg":"不能为空"}');
	if(!$_POST['csrf_token'] || $_POST['csrf_token']!=$_SESSION['csrf_token'])exit('{"code":-1,"msg":"CSRF TOKEN ERROR"}');
	if (!preg_match('/^[a-zA-Z0-9\x7f-\xff]+$/',$name)) {
		exit('{"code":-1,"msg":"应用名称只能为汉字、数字或英文"}');
	}
	if (!preg_match('/http[s]?:\/\/[\w.]+[\w\/]*[\w.]*\??[\w=&\+\%]*/is',$url)) {
		exit('{"code":-1,"msg":"应用首页网址不正确"}');
	}
	$rows=$DB->getRow("select * from pre_apps where name=:name AND status<4 AND appid!=:appid limit 1", [':name'=>$name,':appid'=>$appid]);
	if($rows)exit('{"code":-1,"msg":"应用名称已存在！"}');

	$sql="update `pre_apps` set `name`=:name,`url`=:url where appid=:appid";
	if($DB->exec($sql, [':name'=>$name, ':url'=>$url, ':appid'=>$appid])!==false){
		exit('{"code":0,"msg":"修改成功"}');
	}else
		exit('{"code":-1,"msg":"修改失败！['.$DB->error().']"}');
break;
case 'showDomains':
	$appid=intval($_GET['appid']);
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	$rows=$DB->getAll("select * from pre_appdomain where appid='$appid'");
	$data = [];
	foreach($rows as $row){
		$data[] = $row['domain'];
	}
	$result = ['code'=>0,'msg'=>'succ','data'=>$data];
	exit(json_encode($result));
break;
case 'resetAppkey':
	$appid=intval($_POST['appid']);
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	if(isset($_POST['submit'])){
		$appkey = md5(mt_rand(0,999).time());
		$sql = "UPDATE pre_apps SET `appkey`='$appkey' WHERE appid='$appid'";
		if($DB->exec($sql)!==false)exit('{"code":0,"msg":"重置APP密钥成功","appkey":"'.$appkey.'"}');
		else exit('{"code":-1,"msg":"重置APP密钥失败['.$DB->error().']"}');
	}
break;
case 'addDomain':
	$appid=intval($_POST['appid']);
	$domain=trim($_POST['domain']);
	if(empty($appid)||empty($domain))exit('{"code":-1,"msg":"不能为空"}');
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	if(!checkdomain($domain))exit('{"code":-1,"msg":"域名不正确"}');
	if($DB->getRow("select * from pre_appdomain where appid=:appid AND domain=:domain limit 1", [':appid'=>$appid, ':domain'=>$domain]))exit('{"code":-1,"msg":"域名已存在"}');
	$DB->exec("INSERT INTO pre_appdomain (`appid`,`domain`,`addtime`,`status`) VALUES (:appid, :domain, NOW(), 1)", [':appid'=>$appid, ':domain'=>$domain]);
	exit('{"code":0,"msg":"域名添加成功"}');
break;
case 'delDomain':
	$id=intval($_POST['id']);
	$row = $DB->getRow("select * from pre_appdomain where id=:id limit 1", [':id'=>$id]);
	if(!$row)exit('{"code":-1,"msg":"记录不存在"}');
	$appid = $row['appid'];
	$approw = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$approw)exit('{"code":-1,"msg":"应用不存在"}');
	$DB->exec("DELETE FROM pre_appdomain WHERE id=:id", [':id'=>$id]);
	exit('{"code":0,"msg":"域名删除成功"}');
break;
case 'appstat':
	$appid=intval($_GET['appid']);
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	$count1=$DB->getColumn("SELECT count(*) FROM pre_accounts WHERE appid={$appid}");
	$count2=$DB->getColumn("SELECT count(*) FROM pre_accounts WHERE appid={$appid} AND TO_DAYS(NOW())-TO_DAYS(addtime)=0");
	$count3=$DB->getColumn("SELECT count(*) FROM pre_accounts WHERE appid={$appid} AND TO_DAYS(NOW())-TO_DAYS(addtime)=1");
	$count4=$DB->getColumn("SELECT count(*) FROM pre_logs WHERE appid={$appid} AND TO_DAYS(NOW())-TO_DAYS(addtime)=0 AND status=1");

	$colors = ['#4d79f6', '#ff5da0', '#e0e7fd', '#4ac7ec', '#eeb422', '#76ee00', '#00f5ff', '#b03060', '#ffff00', '#b8860b'];
	$dates = [];
	$accounts = [];
	$logs = [];
	$typecount = [];

	for($i=6;$i>=0;$i--){
		$dates[] = date("m-d", strtotime("-{$i} days"));

		if($i==0)$accounts[] = $count2;
		else if($i==1)$accounts[] = $count3;
		else $accounts[] = $DB->getColumn("SELECT count(*) FROM pre_accounts WHERE appid={$appid} AND TO_DAYS(NOW())-TO_DAYS(addtime)={$i}");
		
		if($i==0)$logs[] = $count4;
		else $logs[] = $DB->getColumn("SELECT count(*) FROM pre_logs WHERE appid={$appid} AND TO_DAYS(NOW())-TO_DAYS(addtime)={$i} AND status=1");
	}

	$typelist = $DB->getAll("SELECT * FROM pre_type ORDER BY sort ASC");
	$types = [];
	foreach($typelist as $row){
		$count = $DB->getColumn("SELECT count(*) FROM pre_accounts WHERE appid={$appid} AND type='{$row['name']}'");
		if($count > 0){
			$types[] = $row['showname'];
			$typecount[] = $count;
		}
	}
	if(count($types) == 0){
		$types[] = '无登录记录';
		$typecount[] = 0;
	}

	$maxmaxaccounts = max($accounts);
	$maxmaxaccounts = $maxmaxaccounts + intval($maxmaxaccounts/3);
	if($maxmaxaccounts<10)$maxmaxaccounts = 10;

	$maxlogs = max($logs);
	$maxlogs = $maxlogs + intval($maxlogs/3);
	if($maxlogs<10)$maxlogs = 10;

	$result=['code'=>0, 'count1'=>$count1, 'count2'=>$count2, 'count3'=>$count3, 'count4'=>$count4, 'dates'=>$dates, 'accounts'=>$accounts, 'logs'=>$logs, 'maxaccounts'=>$maxmaxaccounts, 'maxlogs'=>$maxlogs, 'types'=>$types, 'typecount'=>$typecount, 'colors'=>$colors];
	exit(json_encode($result));
break;
case 'account_detail':
	$appid=intval($_POST['appid']);
	$type=trim($_POST['type']);
	$openid=trim($_POST['openid']);
	$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
	if(!$row)exit('{"code":-1,"msg":"应用不存在"}');
	$row = $DB->getRow("SELECT * FROM pre_accounts WHERE appid=:appid AND type=:type AND openid=:openid LIMIT 1", [":appid"=>$appid, ":type"=>$type, ":openid"=>$openid]);
	if(!$row)exit('{"code":-1,"msg":"记录不存在"}');
	$result=array("code"=>0,"type"=>$row['type'],"openid"=>$row['openid'],"access_token"=>$row['token'],"nickname"=>$row['nickname'],"faceimg"=>$row['faceimg'],"location"=>$row['location'],"gender"=>$row['gender'],"ip"=>$row['ip'],"addtime"=>$row['addtime'],"lasttime"=>$row['lasttime']);
	exit(json_encode($result));
break;
default:
	exit('{"code":-4,"msg":"No Act"}');
break;
}