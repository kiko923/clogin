<?php
$is_defend=true;
include("../includes/common.php");
if(!$conf['test_open'])sysmsg("未开启聚合登录接口测试");
$appkey = $DB->getColumn("select appkey from pre_apps where appid='{$conf['test_appid']}' limit 1");
if(!$appkey)sysmsg("测试应用APPID不存在");
if($_GET['code']){
	if($_GET['state'] != $_SESSION['Oauth_state']){
		sysmsg("The state does not match. You may be a victim of CSRF.");
	}
	$Oauth_config['appid'] = $conf['test_appid'];
	$Oauth_config['appkey'] = $appkey;
	$Oauth=new \lib\TestLogin($Oauth_config);
	$arr = $Oauth->callback();
	if(isset($arr['code']) && $arr['code']==0){
		$_SESSION['user'] = $arr;
		exit("<script language='javascript'>window.location.href='./test.php?ok=1';</script>");
	}elseif(isset($arr['code'])){
		sysmsg('登录失败，返回错误原因：'.$arr['msg']);
	}else{
		sysmsg('获取登录数据失败');
	}
}

$csrf_token = md5(mt_rand(0,999).time());
$_SESSION['csrf_token'] = $csrf_token;
$list = $DB->getAll("SELECT * FROM pre_type WHERE status=1 ORDER BY sort ASC");
?>
<!DOCTYPE html>
<html lang="zh-CN">
<body>
<head>
	<meta charset="utf-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
	<title><?php echo $conf['sitename']?> - 接口测试</title>
    <link href="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet"/>
	<style>
		img.logo{height:28px;margin: -2px 5px 0 5px;}
	</style>
</head>
<div class="container">
<div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<div class="page-header">
  <h4><?php echo $conf['sitename']?> - 接口测试<a href="/" class="pull-right"><small>返回首页</small></a></h4>
</div>
<div class="panel panel-primary">
<div class="panel-body">
<form name="alipayment">
<input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>">
<?php if(isset($_SESSION['user']) && isset($_GET['ok'])){?>
<div class="panel panel-success">
	<div class="panel-heading" style="text-align: center;"><h3 class="panel-title">
		登录成功
	</h3></div>
	<div class="panel-body">
		<div class="list-group">
			<div class="form-group">
				<label>social_uid：</label>
				<input type="text" value="<?php echo $_SESSION['user']['social_uid']?>" class="form-control" readonly="readonly"/>
			</div>
			<div class="form-group">
				<label>access_token：</label>
				<input type="text" value="<?php echo $_SESSION['user']['access_token']?>" class="form-control" readonly="readonly"/>
			</div>
			<div class="form-group">
				<label>faceimg：</label>
				<input type="text" value="<?php echo $_SESSION['user']['faceimg']?>" class="form-control" readonly="readonly"/>
			</div>
			<div class="form-group">
				<label>nickname：</label>
				<input type="text" value="<?php echo $_SESSION['user']['nickname']?>" class="form-control" readonly="readonly"/>
			</div>
			<div class="form-group">
				<label>gender：</label>
				<input type="text" value="<?php echo $_SESSION['user']['gender']?>" class="form-control" readonly="readonly"/>
			</div>
			<div class="form-group">
				<label>location：</label>
				<input type="text" value="<?php echo $_SESSION['user']['location']?>" class="form-control" readonly="readonly"/>
			</div>
		</div>
	</div>
</div>
<?php }?>
<div class="list-group">
<h4>请选择一种登录方式：</h4>
<?php foreach($list as $row){?>
	<button type="button" onclick="submitLogin('<?php echo $row['name']?>')" class="btn btn-default btn-lg"><img src="../assets/icon/<?php echo $row['name']?>.png" class="logo">&nbsp;<?php echo $row['showname']?></button>&nbsp;
<?php }?>
</div>
</form>
</div>
<div class="panel-footer text-center">
<?php echo $conf['sitename']?> © <?php echo date("Y")?> All Rights Reserved.
</div>
</div>
</div>
</div>
<script src="<?php echo $cdnpublic?>jquery/3.4.1/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
<script>
function submitLogin(type){
	var csrf_token=$("input[name='csrf_token']").val();
	var ii = layer.load();
	$.ajax({
		type: "POST",
		dataType: "json",
		data: {type:type, csrf_token:csrf_token},
		url: "ajax.php?act=test",
		success: function (data, textStatus) {
			layer.close(ii);
			if (data.code == 0) {
				window.location.href=data.url;
			}else{
				layer.alert(data.msg, {icon: 2});
			}
		},
		error: function (data) {
			layer.close(ii);
			layer.msg('服务器错误', {icon: 2});
		}
	});
	return false;
}
</script>
</body>