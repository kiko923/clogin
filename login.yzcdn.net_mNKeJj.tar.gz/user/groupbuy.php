<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='会员购买';
include './head.php';

if($conf['group_buy']==0)exit('未开启购买会员');

$logintype = [];
$rs = $DB->getAll("SELECT name,showname FROM pre_type WHERE status=1 ORDER BY sort ASC");
foreach($rs as $row){
	$logintype[$row['name']] = $row['showname'];
}
unset($rs);

function display_info($info){
	global $logintype;
	$result = '';
	if(!empty($info)){
		$arr = json_decode($info, true);
	}
	foreach($logintype as $name=>$showname){
		if($arr && isset($arr[$name]) && $arr[$name]=='0')continue;
		$result .= '<label><img src="../assets/icon/'.$name.'.png" width="18px" title="'.$showname.'">&nbsp;'.$showname.'</label>&nbsp;&nbsp;';
	}
	return $result;
}

$list=$DB->getAll("SELECT * FROM pre_group WHERE isbuy=1 ORDER BY SORT ASC");
$group=[];
foreach($list as $row){
	$group[$row['gid']] = $row['name'];
}
$csrf_token = md5(mt_rand(0,999).time());
$_SESSION['csrf_token'] = $csrf_token;


$mygroup = $DB->getRow("SELECT * FROM pre_group WHERE gid='{$userrow['gid']}'");
$mygroupname = $mygroup['name'] ? $mygroup['name'] : '默认用户组';
$gexpire = $userrow['gexpire'] ? $userrow['gexpire'] : '永久';
if($userrow['gexpire'] && $mygroup['isbuy']==1) $gexpire.=' [<a href="javascript:buy('.$userrow['gid'].',1)">续期</a>]';
$accountlimit = $mygroup['ucount'] ? $mygroup['ucount'].' 个' : '不限数量';
?>
<style>
@media (max-width: 576px){.contents{padding: 0;}}
</style>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active">会员购买</li>
					</ol>
				</div>
				<h4 class="page-title">会员购买</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-12 col-md-3 contents">
			<div class="card">
				<h5 class="card-header bg-info text-white mt-0"><i class="fas fa-info-circle"></i>&nbsp;我的会员等级信息</h5>
				<div class="card-body">
<?php if(isset($_GET['ok']) && $_GET['ok']==1){
	$order = $DB->getRow("SELECT * FROM pre_order WHERE trade_no=:trade_no limit 1", [':trade_no'=>$_GET['trade_no']]);
	if($order){
		$arr = json_decode($order['input'], true);
		$groupname = $DB->getColumn("SELECT name FROM pre_group WHERE gid={$arr['gid']}");
		$expirename = $arr['expire']?$arr['expire'].'个月':'永久';
	?>
	<div class="alert alert-success alert-dismissible fade show" role="alert">
	  <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	  会员等级 <b><?php echo $groupname?></b> 购买成功！
	</div>
<?php }}?>
					<ul class="list-group">
						<li class="list-group-item"><i class="fas fa-user-graduate fa-fw text-info font-18"></i> <b> 用户组 </b> : <strong><?php echo $mygroupname?></strong></li>
						<li class="list-group-item"><i class="fas fa-calendar-alt fa-fw text-info font-18"></i> <b> 到期时间 </b> : <?php echo $gexpire?></li>
						<li class="list-group-item"><i class="fas fa-sign-in-alt fa-fw text-info font-18"></i> <b> 当前可用登录方式 </b> : <br/><?php echo display_info($mygroup['info'])?></li>
						<li class="list-group-item"><i class="fas fa-chevron-circle-up fa-fw text-info font-18"></i> <b> 账号数量上限 </b> : <strong><?php echo $accountlimit?></strong></li>
					</ul>
				</div>
			</div>
		</div>
		<div class="col-12 col-md-9 contents">
			<div id="listFrame">
				<div class="row">
<?php
foreach($list as $res){
	$button = '<a class="btn btn-success btn-round waves-effect waves-light mt-2" href="javascript:buy('.$res['gid'].',0)">立即购买</a>';
	if($userrow['gid']==$res['gid']){
		if($userrow['gexpire'] && $res['isbuy']==1)$button = '<a class="btn btn-success btn-round waves-effect waves-light mt-2" href="javascript:buy('.$res['gid'].',1)">立即续期</a>';
		else $button = '<a class="btn btn-secondary btn-round waves-effect waves-light mt-2" href="javascript:;" disabled>当前等级</a>';
	}
	$expire = $res['expire']==0?'永久':$res['expire'].'个月';
?>
					<div class="col-12 col-sm-6 col-md-4">
						<div class="card">
							<div class="card-body">
								<div class="pricingTable1 text-center">
									<h3 class="title1 py-3 mt-2 mb-0"><?php echo $res['name']?></h3>
									<ul class="list-unstyled pricing-content-2 pb-3">
										<li>可用登录方式：<br/><?php echo display_info($res['info'])?></li>
										<li>账号数量上限：<strong><?php echo $res['ucount']>0?$res['ucount']:'无限'?></strong> 个</li>
									</ul>
									<div class="text-center">
										<h3 class="amount">￥<?php echo $res['price']?><small class="font-12 text-muted">/<?php echo $expire?></small></h3>
									</div> 
									<?php echo $button?>
								</div><!--end pricingTable-->
							</div><!--end card-body-->
						</div> <!--end card-->                                   
					</div><!--end col-->
<?php }?>
				</div><!--end row-->
			</div>

			<div class="card" id="infoFrame" style="display:none;">
				<h5 class="card-header bg-primary text-white mt-0"><i class="fas fa-shopping-cart"></i>&nbsp;<span id="buy_title">购买会员</span></h5>
				<div class="card-body">
					<form class="form-horizontal devform">
					<input type="hidden" name="csrf_token" value="<?php echo $csrf_token?>">
					<input type="hidden" name="group_id" value="">
					<input type="hidden" name="group_expire" value="">
					<input type="hidden" name="group_price" value="">
					<input id="num" name="num" type="hidden" value="1"/>
						<div class="form-group row">
							<label class="col-sm-3 col-form-label">会员等级</label>
							<div class="col-sm-8">
								<input class="form-control" type="text" name="group_name" value="" readonly="">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-3 col-form-label">有效期</label>
							<div class="col-sm-8">
								<div class="input-group" id="num_form1" style="display:none;">
								<span class="input-group-append"><button type="button" class="btn btn-info" style="border-radius: 0px;" id="num_min">━</button></span>
								<input class="form-control" type="text" name="group_expire_show" value="" readonly="">
								<span class="input-group-append"><button type="button" class="btn btn-info" style="border-radius: 0px;" id="num_add">✚</button></span>
								</div>
								<input class="form-control" id="num_form2" type="text" value="永久" readonly="">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-3 col-form-label">售价</label>
							<div class="col-sm-8">
								<input class="form-control" type="text" name="group_price_show" value="" readonly="">
							</div>
						</div>
						<div class="form-group row">
							<label class="col-sm-3 col-form-label">支付方式</label>
							<div class="col-sm-8">
								<?php if($userrow['money']>0){?><div class="form-check-inline my-1"><div class="custom-control custom-radio"><input type="radio" id="type1" name="type" value="rmb" class="custom-control-input"><label class="custom-control-label" for="type1">余额支付<span class="text-muted">（剩<?php echo $userrow['money']?>元）</span></label></div></div><?php }?>
								<?php if($conf['alipay_api']){?><div class="form-check-inline my-1"><div class="custom-control custom-radio"><input type="radio" id="type2" name="type" value="alipay" class="custom-control-input"><label class="custom-control-label" for="type2">支付宝</label></div></div><?php }?>
								<?php if($conf['wxpay_api']){?><div class="form-check-inline my-1"><div class="custom-control custom-radio"><input type="radio" id="type3" name="type" value="wxpay" class="custom-control-input"><label class="custom-control-label" for="type3">微信支付</label></div></div><?php }?>
								<?php if($conf['qqpay_api']){?><div class="form-check-inline my-1"><div class="custom-control custom-radio"><input type="radio" id="type4" name="type" value="qqpay" class="custom-control-input"><label class="custom-control-label" for="type4">QQ钱包</label></div></div><?php }?>
							</div>
						</div>
						<div class="form-group row">
						<label class="col-sm-3 col-form-label"></label><div class="col-sm-8"><input type="button" id="submit" value="立即购买" class="btn btn-gradient-primary btn-block"/><br/>
						<button type="button" class="btn btn-gradient-secondary btn-block" onclick="back()"><i class="fa fa-reply"></i>&nbsp;返回列表</button>
						</div>
						</div>
					</form>
				</div>
			</div>

			
		</div><!--end col-->
	</div><!--end row-->

</div><!-- container -->

<?php include 'foot.php';?>
<script>
function buy(gid, type){
	var ii = layer.load();
	$.ajax({
		type: "POST",
		dataType: "json",
		data: {gid:gid},
		url: "ajax2.php?act=groupinfo",
		success: function (data, textStatus) {
			layer.close(ii);
			if (data.code == 0) {
				$("#buy_title").text(type==1?'续期会员':'购买会员');
				$("input[name='group_id']").val(gid);
				$("input[name='group_name']").val(data.name);
				$("input[name='group_expire']").val(data.expire);
				$("input[name='group_expire_show']").val(data.expire==0?'永久':data.expire+'个月');
				$("input[name='group_price']").val(data.price);
				$("input[name='group_price_show']").val(data.price+'元');
				$("input[name='num']").val(1);
				if(data.expire==0){
					$("#num_form1").hide();
					$("#num_form2").show();
				}else{
					$("#num_form1").show();
					$("#num_form2").hide();
				}
				$("#listFrame").slideUp();
				$("#infoFrame").slideDown();
			}else{
				layer.alert(data.msg, {icon: 0});
			}
		},
		error: function (data) {
			layer.msg('服务器错误', {icon: 2});
		}
	});
}
function back(){
	$("#listFrame").slideDown();
	$("#infoFrame").slideUp();
}
$(document).ready(function(){
	$("input[name=type]:first").attr("checked",true);
	$("#submit").click(function(){
		var csrf_token=$("input[name='csrf_token']").val();
		var gid=$("input[name='group_id']").val();
		var type=$("input[name=type]:checked").val();
		var num=$("input[name='num']").val();
		var ii = layer.load();
		$.ajax({
			type: "POST",
			dataType: "json",
			data: {gid:gid, num:num, type:type, csrf_token:csrf_token},
			url: "ajax2.php?act=groupbuy",
			success: function (data, textStatus) {
				layer.close(ii);
				if (data.code == 0) {
					window.location.href='./other/submit.php?orderid='+data.orderid;
				}else if (data.code == 1) {
					layer.alert(data.msg, {icon: 1}, function(){ window.location.reload() });
				}else{
					layer.alert(data.msg, {icon: 2});
				}
			},
			error: function (data) {
				layer.msg('服务器错误', {icon: 2});
			}
		});
		return false;
	});
$("#num_add").click(function () {
	var i = parseInt($("#num").val());
	i++;
	$("#num").val(i);
	var price = parseFloat($("input[name='group_price']").val());
	var count = parseInt($("input[name='group_expire']").val());
	if(count==0){
		layer.alert('不支持选择数量');
		return false;
	}
	price = price * i;
	count = count * i;
	$("input[name='group_expire_show']").val(count+'个月');
	$("input[name='group_price_show']").val(price.toFixed(2)+'元');
});
$("#num_min").click(function (){
	var i = parseInt($("#num").val());
	if(i<=1){
      	return false;
    }
	var price = parseFloat($("input[name='group_price']").val());
	var count = parseInt($("input[name='group_expire']").val());
	if(count==0){
		layer.alert('不支持选择数量');
		return false;
	}
	i--;
	if (i <= 0) i = 1;
	$("#num").val(i);
	price = price * i;
	count = count * i;
	$("input[name='group_expire_show']").val(count+'个月');
	$("input[name='group_price_show']").val(price.toFixed(2)+'元');
});
});
</script>