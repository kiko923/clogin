<?php
namespace plugins;

use Exception;

class wework {

	static public $info = [
		'name'        => 'wework',
		'showname'    => '企业微信',
		'link'        => 'https://work.weixin.qq.com/',
		'sort'        => 21,
		'abroad'      => false,
		'input' => [
			'corp_id' => [
				'name' => '企业ID',
				'type' => 'input',
				'note' => '',
			],
			'secret' => [
				'name' => '应用Secret',
				'type' => 'input',
				'note' => '',
			],
			'agentid' => [
				'name' => '应用AgentId',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	private $corp_id;
	private $secret;
	private $agentid;
	private $callback;
	private $access_token;

	public function __construct($config)
	{
		global $siteurl;
		$this->corp_id = $config['corp_id'];
		$this->secret = $config['secret'];
		$this->agentid = $config['agentid'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;仅支持企业自建应用与代开发自建应用，应用回调地址填写：'.$siteurl.'return.php<br/>●&nbsp;<b>注意：配置好之后请勿随意更换企业，否则之前已登录的用户将全部失效！</b>';
	}

	public function login($state){
		global $siteurl;
		$url = $siteurl.'jump.php?state='.urlencode($state);
		return $url;
	}

	public function jump($state, $type = 0){
		if (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger')){
			$url = 'https://return.yzcdn.net/connect/oauth2/authorize';
			$param = [
				"appid" => $this->corp_id,
				"redirect_uri" => $this->callback,
				"response_type" => "code",
				"scope" => $type == 1 ? "snsapi_privateinfo" : "snsapi_base",
				"state" => $state,
				"agentid" => $this->agentid
			];
	
			$url .= '?'.http_build_query($param)."#wechat_redirect";
			header("Location: ".$url);
			exit;
		}else{
			return PAGE_ROOT.'wwqrcode.php';
		}
	}

	public function callback($code, $type = 0, $mode = 0){
		$this->getAccessToken();
		$userinfo = $this->get_userinfo($code);
		
		$result = [
			'access_token' => '',
		];

		if(isset($userinfo['userid'])){
			$result['social_uid'] = $userinfo['userid'];
			if($type == 1){
				if(empty($userinfo['user_ticket'])){
					throw new Exception('获取用户信息失败，当前用户不在应用可见范围之内');
				}
				$user = $this->get_user_detail($userinfo['user_ticket']);
				$result['faceimg'] = $user['avatar'];
				$result['mobile'] = $user['mobile'];
				$result['email'] = !empty($user['email'])?$user['email']:$user['biz_mail'];
				if($user['gender'] > 0){
					$result['gender'] = $user['gender'] == '2' ? '女' : '男';
				}
				$user = $this->get_corp_user($userinfo['userid']);
				$result['nickname'] = $user['name'];
			}
		}elseif(isset($userinfo['openid'])){
			$result['social_uid'] = $userinfo['openid'];
			if($type == 1 && !empty($userinfo['external_userid'])){
				$user = $this->get_external_user($userinfo['external_userid']);
				$result['faceimg'] = $user['avatar'];
				$result['nickname'] = $user['name'];
				if($user['gender'] > 0){
					$result['gender'] = $user['gender'] == '2' ? '女' : '男';
				}
			}
		}else{
			throw new Exception('获取用户信息失败，返回数据异常');
		}

		return $result;
	}

	private function get_userinfo($code){
		$url = 'https://qyapi.weixin.qq.com/cgi-bin/auth/getuserinfo';
		$param = [
			"access_token" => $this->access_token,
			"code" => $code
		];

		$url .= '?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['errcode']) && $arr['errcode'] == 0){
			return $arr;
		}else{
			throw new Exception('获取用户信息失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}
	}

	private function get_user_detail($user_ticket){
		$url = 'https://qyapi.weixin.qq.com/cgi-bin/auth/getuserdetail?access_token='.$this->access_token;
		$param = [
			"user_ticket" => $user_ticket
		];

		$response = get_curl_api(self::$info['abroad'], $url, json_encode($param));
		$arr = json_decode($response, true);
		if(isset($arr['errcode']) && $arr['errcode'] == 0){
			return $arr;
		}else{
			throw new Exception('访问用户敏感信息失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}
	}

	private function get_corp_user($userid){
		$url = 'https://qyapi.weixin.qq.com/cgi-bin/user/get';
		$param = [
			"access_token" => $this->access_token,
			"userid" => $userid
		];

		$url .= '?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['errcode']) && $arr['errcode'] == 0){
			return $arr;
		}else{
			throw new Exception('读取企业成员失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}
	}

	private function get_external_user($external_userid){
		$url = 'https://qyapi.weixin.qq.com/cgi-bin/externalcontact/get';
		$param = [
			"access_token" => $this->access_token,
			"external_userid" => $external_userid
		];
		$url .= '?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['errcode']) && $arr['errcode'] == 0){
			return $arr['external_contact'];
		}else{
			throw new Exception('获取客户详情失败 ['.$arr['errcode'].']'.$arr['errmsg']);
		}
	}

	private function getAccessToken(){
		global $DB;
		if(!empty($this->access_token)) return $this->access_token;
		$cachekey = 'wwtoken_'.$this->corp_id;
		$DB->beginTransaction();
		$data = $DB->getColumn("SELECT v FROM pre_cache WHERE k=:key LIMIT 1 FOR UPDATE", [':key'=>$cachekey]);
		$arr = json_decode($data, true);
		if($arr['access_token'] && strtotime($arr['expiretime']) - 200 >= time()){
			$DB->rollback();
			$this->access_token = $arr['access_token'];
			return $this->access_token;
		}

		$url = 'https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid='.$this->corp_id.'&corpsecret='.$this->secret;
		$response = get_curl_api(self::$info['abroad'], $url);
		$res = json_decode($response, true);
		if(isset($res['errcode']) && $res['errcode'] == 0){
			$arr['expire_time'] = time() + $res['expires_in'];
			$arr['access_token'] = $res['access_token'];
			$data = json_encode($arr);
			$DB->exec("REPLACE INTO pre_cache VALUES (:key, :value, :expire)", [':key'=>$cachekey, ':value'=>$data, ':expire'=>0]);
			$this->access_token = $res['access_token'];
			$DB->commit();
			return $this->access_token;
		}else{
			$DB->rollback();
			throw new Exception('获取access_token失败 ['.$res['errcode'].']'.$res['errmsg']);
		}
	}
}