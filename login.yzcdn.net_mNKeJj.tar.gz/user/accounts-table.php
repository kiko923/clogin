<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if(!checkRefererHost())exit("<script language='javascript'>window.location.href='./';</script>");

$appid=intval($_GET['appid']);
$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
if(!$row)exit("<script language='javascript'>window.location.href='./apps.php';</script>");

$logintype = [];
$rs = $DB->getAll("SELECT name,showname FROM pre_type ORDER BY sort ASC");
foreach($rs as $row){
	$logintype[$row['name']] = $row['showname'];
}
unset($rs);

$sqls="";
$links='';
if(isset($_GET['type']) && !empty($_GET['type']) && $_GET['type']!='0') {
	$type = daddslashes($_GET['type']);
	$sqls.=" AND `type`='$type'";
	$links.='&type='.$type;
}

if(isset($_GET['openid']) && !empty($_GET['openid']) && !empty($_GET['type'])) {
	$openid = trim(daddslashes($_GET['openid']));
	$type = trim(daddslashes($_GET['type']));
	$sql=" appid='$appid' AND type='{$type}' AND `openid`='{$openid}'";
	$sql.=$sqls;
	$numrows=$DB->getColumn("SELECT count(*) from pre_accounts WHERE{$sql}");
	$con='包含 '.$openid.' 的共有 <b>'.$numrows.'</b> 个账号';
	$link='&appid='.$appid.'&openid='.$openid.$links;
}elseif(isset($_GET['kw']) && !empty($_GET['kw'])) {
	$kw = trim(daddslashes($_GET['kw']));
	$sql=" appid='$appid' AND (`openid`='{$kw}' OR `nickname`='{$kw}')";
	$sql.=$sqls;
	$numrows=$DB->getColumn("SELECT count(*) from pre_accounts WHERE{$sql}");
	$con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个账号';
	$link='&appid='.$appid.'&kw='.$_GET['kw'].$links;
}else{
	$sql=" appid='$appid'";
	$sql.=$sqls;
	$numrows=$DB->getColumn("SELECT count(*) from pre_accounts WHERE{$sql}");
	$con='当前应用下共有 <b>'.$numrows.'</b> 个账号';
	$link='&appid='.$appid.$links;
}

$pagesize=20;
$pages=ceil($numrows/$pagesize);
$page=isset($_GET['page'])?intval($_GET['page']):1;
$offset=$pagesize*($page - 1);
?>
					<div class="table-responsive" id="accountlist">
						<table class="table mb-0 table-centered">
							<thead>
							<tr>
								<th>头像&昵称</th>
								<th>登录方式</th>
								<th>第三方账号UID</th>
								<th>性别</th>
								<th>最后登录时间</th>
							</tr>
							</thead>
							<tbody>
<?php
$rs=$DB->query("SELECT * FROM pre_accounts WHERE{$sql} order by id desc limit $offset,$pagesize");
while($res = $rs->fetch())
{
?>
							<tr>
								<td><div class="avatar-box thumb-md align-self-center mr-2"><img src="<?php echo $res['faceimg']?$res['faceimg']:'assets/images/user.png'?>" class="thumb-md rounded-circle"></div><?php echo $res['nickname']?>
								</td>
								<td><?php echo $logintype[$res['type']]?></td>
								<td><a href="javascript:account_detail('<?php echo $res['type']?>','<?php echo $res['openid']?>')"><?php echo $res['openid']?></a></td>
								<td><?php echo $res['gender']?></td>
								<td><?php echo $res['lasttime']?></td>
							</tr>
<?php }?>
							</tbody>
						</table><!--end /table-->
					</div><!--end /tableresponsive-->
<?php
echo'<nav aria-label="Page navigation example"><ul class="pagination justify-content-center">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="listTable(\'page='.$first.$link.'\')">首页</a></li>';
echo '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="listTable(\'page='.$prev.$link.'\')">&laquo;</a></li>';
} else {
echo '<li class="page-item disabled"><a class="page-link">首页</a></li>';
echo '<li class="page-item disabled"><a class="page-link">&laquo;</a></li>';
}
$start=$page-10>1?$page-10:1;
$end=$page+10<$pages?$page+10:$pages;
for ($i=$start;$i<$page;$i++)
echo '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="listTable(\'page='.$i.$link.'\')">'.$i .'</a></li>';
echo '<li class="page-item disabled"><a class="page-link">'.$page.'</a></li>';
for ($i=$page+1;$i<=$end;$i++)
echo '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="listTable(\'page='.$i.$link.'\')">'.$i .'</a></li>';
if ($page<$pages)
{
echo '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="listTable(\'page='.$next.$link.'\')">&raquo;</a></li>';
echo '<li class="page-item"><a class="page-link" href="javascript:void(0)" onclick="listTable(\'page='.$last.$link.'\')">尾页</a></li>';
} else {
echo '<li class="page-item disabled"><a class="page-link">&raquo;</a></li>';
echo '<li class="page-item disabled"><a class="page-link">尾页</a></li>';
}
echo'</ul></nav>';?>
