<?php
/**
 * 用户列表
**/
include("../includes/common.php");
$title='用户列表';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$select = '';
$rs = $DB->getAll("SELECT * FROM pre_group");
foreach($rs as $row){
	$select .= '<option value="'.$row['gid'].'">'.$row['name'].'</option>';
}
unset($rs);
?>
<style>
#orderItem .orderTitle{word-break:keep-all;}
#orderItem .orderContent{word-break:break-all;}
</style>
<div class="row">
<div class="col-xs-12 center-block" style="float: none;">
<div class="panel panel-default panel-intro">
<div class="panel-body">

<div class="modal" id="modal-rmb">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
				<h4 class="modal-title">余额充值与扣除</h4>
			</div>
			<div class="modal-body">
				<form id="form-rmb" onsubmit="return false;">
					<input type="hidden" name="uid" value="">
					<div class="form-group">
						<div class="input-group">
							<span class="input-group-addon p-0">
								<select name="do"
										style="-webkit-border-radius: 0;height:20px;border: 0;outline: none !important;border-radius: 5px 0 0 5px;padding: 0 5px 0 5px;">
									<option value="0">充值</option>
									<option value="1">扣除</option>
								</select>
							</span>
							<input type="number" class="form-control" name="rmb" placeholder="输入金额">
							<span class="input-group-addon">元</span>
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-outline-info" data-dismiss="modal">取消</button>
				<button type="button" class="btn btn-primary" id="recharge">确定</button>
			</div>
		</div>
	</div>
</div>
<div id="searchToolbar">
<form onsubmit="return searchSubmit()" method="GET" class="form-inline">
  <div class="form-group">
    <label>搜索</label>
	<select name="column" class="form-control"><option value="uid">UID</option><option value="user">用户名</option><option value="qq">QQ</option><option value="phone">手机号码</option><option value="email">邮箱</option></select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> 搜索</button>&nbsp;
  <a href="javascript:searchClear()" class="btn btn-default"><i class="fa fa-repeat"></i> 重置</a>
  &nbsp;<a href="./uset.php?my=add" class="btn btn-success">添加用户</a>
</form>
</div>

      <table id="listTable">
	  </table>
	  </div>
  </div>
</div>
</div>
<?php include './foot.php';?>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
<script src="<?php echo $cdnpublic?>clipboard.js/1.7.1/clipboard.min.js"></script>
<script src="<?php echo $cdnpublic?>bootstrap-table/1.21.4/bootstrap-table.min.js"></script>
<script src="<?php echo $cdnpublic?>bootstrap-table/1.21.4/extensions/page-jump-to/bootstrap-table-page-jump-to.min.js"></script>
<script src="./assets/js/custom.js"></script>
<script>
function setStatus(uid,status) {
	$.ajax({
		type : 'POST',
		url : 'ajax_user.php?act=setUser',
		data : {uid: uid, status: status},
		dataType : 'json',
		success : function(data) {
			if(data.code == 0){
				searchSubmit();
			}else{
				layer.msg(data.msg, {icon:2, time:1500});
			}
		},
		error:function(data){
			layer.msg('服务器错误');
		}
	});
}
function editGroup(uid, gid, gexpire){
	if(gexpire == 'null') gexpire = '';
	var html = '<div class="modal-body"><form class="form" id="form-info">';
	html += '<div class="form-group"><div class="input-group"><div class="input-group-addon">用户组</div><select class="form-control" id="gid"><?php echo $select?></select></div></div>';
	html += '<div class="form-group"><div class="input-group"><div class="input-group-addon">有效期</div><select class="form-control" id="gexpire_set"><option value="0">永久</option><option value="1">设置日期</option></select><input type="date" class="form-control" name="gexpire" value="'+gexpire+'" id="gexpire_show"></div></div>';
	html += '<div class="form-group"><button type="button" id="save" onclick="saveGroup('+uid+')" class="btn btn-primary btn-block">保存</button></div></form></div>';
	layer.open({
	  type: 1,
	  shadeClose: true,
	  title: '修改用户组',
	  content: html,
	  success: function(){
		  $("#gid").val(gid);
		  $("#gexpire_set").val(gexpire==''?0:1);
			$("#gexpire_set").change(function(){
				if($(this).val() == 1){
					$("#gexpire_show").show();
				}else{
					$("#gexpire_show").hide();
				}
			});
			$("#gid").change(function(){
				if($(this).val() == 0){
					$("#gexpire_set").val(0);
					$("#gexpire_set").change();
				}
			});
			$("#gexpire_set").change();
	  }
	});
}
function saveGroup(uid){
	var ii = layer.load(2, {shade:[0.1,'#fff']});
	var gid = $("#gid").val();
	var gexpire = $("#gexpire_set").val() == '1' ? $("#gexpire_show").val() : '';
	$.ajax({
		type : 'POST',
		url : 'ajax_user.php?act=setUserGroup',
		data : {uid:uid, gid:gid, gexpire:gexpire},
		dataType : 'json',
		success : function(data) {
			layer.close(ii);
			if(data.code == 0){
				layer.alert(data.msg,{
					icon: 1,
					closeBtn: false
				},function(){layer.closeAll();searchSubmit();});
			}else{
				layer.alert(data.msg, {icon: 2})
			}
		},
		error:function(data){
			layer.close(ii);
			layer.msg('服务器错误');
		}
	});
}
function showRecharge(uid) {
	$("input[name='uid']").val(uid);
	$('#modal-rmb').modal('show');
}
$(document).ready(function(){
	$("#recharge").click(function(){
		var uid=$("input[name='uid']").val();
		var actdo=$("select[name='do']").val();
		var rmb=$("input[name='rmb']").val();
		if(rmb==''){layer.alert('请输入金额');return false;}
		var ii = layer.load(2, {shade:[0.1,'#fff']});
		$.ajax({
			type : "POST",
			url : "ajax_user.php?act=recharge",
			data : {uid:uid,actdo:actdo,rmb:rmb},
			dataType : 'json',
			success : function(data) {
				layer.close(ii);
				if(data.code == 0){
					layer.msg('修改余额成功');
					$('#modal-rmb').modal('hide');
					searchSubmit();
				}else{
					layer.alert(data.msg);
				}
			},
			error:function(data){
				layer.close(ii);
				layer.msg('服务器错误');
			}
		});
	});
	
	updateToolbar();
	const defaultPageSize = 20;
	const pageNumber = typeof window.$_GET['pageNumber'] != 'undefined' ? parseInt(window.$_GET['pageNumber']) : 1;
	const pageSize = typeof window.$_GET['pageSize'] != 'undefined' ? parseInt(window.$_GET['pageSize']) : defaultPageSize;

	$("#listTable").bootstrapTable({
		url: 'ajax_user.php?act=userList',
		pageNumber: pageNumber,
		pageSize: pageSize,
		classes: 'table table-striped table-hover table-bordered',
		columns: [
			{
				field: 'uid',
				title: 'UID',
				formatter: function(value, row, index) {
					return '<b>'+value+'</b>';
				}
			},
			{
				field: 'user',
				title: '用户名'
			},
			{
				field: 'gid',
				title: '用户组',
				formatter: function(value, row, index) {
					return '<span onclick="editGroup('+row.uid+','+value+',\''+row.gexpire+'\')" style="color:blue" title="有效期：'+(row.gexpire!=null?row.gexpire:'永久')+'">'+row.gname+'</span>';
				}
			},
			{
				field: 'money',
				title: '余额',
				formatter: function(value, row, index) {
					return '<a href="javascript:showRecharge('+row.uid+')">'+value+'</a>';
				}
			},
			{
				field: 'qq',
				title: 'QQ',
				formatter: function(value, row, index) {
					if(!value) return '';
					return isMobile() ? '<a href="mqqwpa://im/chat?chat_type=wpa&version=1&src_type=web&web_src=oicqzone.com&uin='+value+'">'+value+'</a>' : '<a href="tencent://message/?uin='+value+'&amp;Site=qq&amp;Menu=yes">'+value+'</a>';
				}
			},
			{
				field: 'phone',
				title: '手机/邮箱',
				formatter: function(value, row, index) {
					if(value){
						return value;
					}else if(row.email){
						return row.email;
					}else{
						return '';
					}
				}
			},
			{
				field: 'addtime',
				title: '注册时间'
			},
			{
				field: 'status',
				title: '状态',
				formatter: function(value, row, index) {
					if(value == 1){
						return '<a href="javascript:setStatus('+row.uid+',0)"><font color=green><i class="fa fa-check-circle"></i>正常</font></a>';
					}else{
						return '<a href="javascript:setStatus('+row.uid+',1)"><font color=red><i class="fa fa-times-circle"></i>封禁</font></a>';
					}
				}
			},
			{
				field: '',
				title: '操作',
				formatter: function(value, row, index) {
					return '<a href="./uset.php?my=edit&uid='+row.uid+'" class="btn btn-xs btn-info">编辑</a>&nbsp;<a href="./sso.php?uid='+row.uid+'" target="_blank" class="btn btn-xs btn-success">登录</a>&nbsp;<a href="./uset.php?my=delete&uid='+row.uid+'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此用户吗？\');">删除</a>&nbsp;<a href="./apps.php?uid='+row.uid+'" target="_blank" class="btn btn-xs btn-default">应用</a>&nbsp;<a href="./order.php?uid='+row.uid+'" target="_blank" class="btn btn-xs btn-default">订单</a>';
				},
				
			},
		],
	})
})
</script>
</body>
</html>