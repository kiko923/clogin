<?php
namespace lib;

class Plugin {

	static public function getList(){
		$dir = PLUGIN_ROOT;
		$dirArray[] = NULL;
        if (false != ($handle = opendir($dir))) {
            $i = 0;
            while (false !== ($file = readdir($handle))) {
                if ($file != "." && $file != ".." && strpos($file, ".php")) {
                    $dirArray[$i] = $file;
                    $i++;
                }
            }
            closedir($handle);
        }
        return $dirArray;
	}

    static public function getConfig($name){
        $classname = '\\plugins\\'.$name;
		if(class_exists($classname) && property_exists($classname, 'info')){
			return $classname::$info;
		}else{
			return false;
		}
	}

    static public function updateAll(){
        global $DB;
        $list = self::getList();
        foreach($list as $name){
            $name = str_replace('.php','',$name);
            if ($config = self::getConfig($name)) {
                $DB->exec("INSERT INTO pre_type VALUES (:name, :showname, :sort, :link, 0, '', 0)  on duplicate key update showname=:showname, sort=:sort, link=:link", [':name'=>$config['name'], ':showname'=>$config['showname'], ':sort'=>$config['sort'], ':link'=>$config['link']]);
            }
        }
    }

}
