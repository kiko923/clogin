<?php
namespace plugins;

use Exception;

class sina {

	static public $info = [
		'name'        => 'sina',
		'showname'    => '微博',
		'link'        => 'https://open.weibo.com/',
		'sort'        => 14,
		'abroad'      => false,
		'input' => [
			'appkey' => [
				'name' => 'App Key',
				'type' => 'input',
				'note' => '',
			],
			'appsecret' => [
				'name' => 'App Secret',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://api.weibo.com/oauth2/authorize";
	const GET_ACCESS_TOKEN_URL = "https://api.weibo.com/oauth2/access_token";
	const GET_OPENID_URL = "https://api.weibo.com/2/users/show.json";

	private $appkey;
	private $appsecret;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->appkey = $config['appkey'];
		$this->appsecret = $config['appsecret'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		return '●&nbsp;<a href="https://open.weibo.com/" target="_blank" rel="noreferrer">申请地址</a>，“绑定安全域名”填写：'.$_SERVER['HTTP_HOST'];
	}

	public function login($state){
		$param = [
			"response_type" => "code",
			"client_id" => $this->appkey,
			"redirect_uri" => $this->callback,
			"state" => $state
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		list($access_token, $uid) = $this->get_access_token($code);

		$result = [
			'access_token' => $access_token,
			'social_uid' => $uid
		];
		if($type == 1){
			$userinfo = $this->get_userinfo($access_token, $uid);
			$result['faceimg'] = $userinfo['avatar_large'] ? $userinfo['avatar_large'] : $userinfo['profile_image_url'];
			$result['nickname'] = $userinfo['screen_name'];
			$gender_arr = ['M'=>'男', 'F'=>'女', 'm'=>'男', 'f'=>'女'];
			$result['gender'] = $gender_arr[$userinfo['gender']];
			$result['location'] = str_replace(' ', '', $userinfo['location']);
		}

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"grant_type" => "authorization_code",
			"code" => $code,
			"client_id" => $this->appkey,
			"client_secret" => $this->appsecret,
			"redirect_uri" => $this->callback
		];

		$url = self::GET_ACCESS_TOKEN_URL;
		$response = get_curl_api(self::$info['abroad'], $url, http_build_query($param));
		$arr = json_decode($response, true);
		if(isset($arr['access_token']) && isset($arr['uid'])){
			return [$arr['access_token'], $arr['uid']];
		}elseif(isset($arr['error'])){
			throw new Exception('获取access_token失败 '.$arr['error']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_userinfo($access_token, $uid){
		$param = [
			"access_token" => $access_token,
			"uid" => $uid
		];

		$url = self::GET_OPENID_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['screen_name'])){
			return $arr;
		}elseif(isset($arr['error'])){
			throw new Exception('获取用户信息失败 '.$arr['error']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}