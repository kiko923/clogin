<?php
require 'inc.php';

//微信小程序支付

@header('Content-Type: application/json; charset=UTF-8');
$trade_no=daddslashes($_GET['trade_no']);
if($conf['wxpay_api']!=1 && $conf['wxpay_api']!=3)exit('{"code":-1,"msg":"当前支付接口未开启"}');
$row=$DB->getRow("SELECT * FROM pre_order WHERE trade_no='{$trade_no}' LIMIT 1");
if(!$row)exit('{"code":-1,"msg":"该订单号不存在"}');

$code = isset($_GET['code'])?trim($_GET['code']):exit('{"code":-1,"msg":"code不能为空"}');

$ordername = !empty($conf['ordername'])?ordername_replace($conf['ordername'],$row['name'],$trade_no):$row['name'];

$wechatpay_config = require('inc/wxpay.config.php');

//①、获取用户openid
try{
    $tools = new \WeChatPay\JsApiTool($wechatpay_config['appid'], $wechatpay_config['appsecret']);
    $openid = $tools->AppGetOpenid($code);
}catch(Exception $e){
	exit('{"code":-1,"msg":"OpenId获取失败:'.$e->getMessage().'"}');
}

//②、统一下单
$params = [
    'body' => $ordername,
    'out_trade_no' => $trade_no,
    'total_fee' => strval($row['money']*100),
    'spbill_create_ip' => $clientip,
    'notify_url' => $siteurl.'user/other/wxpay_notify.php',
    'openid' => $openid,
];
try{
    $client = new \WeChatPay\PaymentService($wechatpay_config);
    $result = $client->jsapiPay($params);
	exit(json_encode(['code'=>0, 'data'=>$result]));
}catch(Exception $e){
	exit(json_encode(['code'=>-1, 'msg'=>'微信支付下单失败！'.$e->getMessage()]));
}
