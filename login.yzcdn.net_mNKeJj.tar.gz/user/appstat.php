<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='应用统计';
include './head.php';

$appid=intval($_GET['appid']);
$row = $DB->getRow("select * from pre_apps where appid='$appid' AND uid='$uid' AND status<4");
?>
<style>
label > span.required {
    color: #ff4d4d;
}
.domainitem{margin-top: -5px;margin-bottom: -6px;}
@media (max-width: 576px){.contents{padding: 0;}}
</style>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="./apps.php">应用列表</a></li>
						<li class="breadcrumb-item active">应用统计</li>
					</ol>
				</div>
				<h4 class="page-title">应用统计</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-sm-12 contents">
<?php if(!$row){?><div class="card">
				<div class="card-body">
					<div class="alert alert-danger alert-dismissible fade show" role="alert">
						<strong>该应用不存在</strong>
					</div>
				</div>
				</div>
<?php }else{?>
			<div class="row">
				<div class="col-6 col-md-3">
					<div class="card crm-data-card">
						<div class="card-body"> 
							<div class="row">
								<div class="col-4 align-self-center">
									<div class="icon-info">
										<i class="fas fa-user-friends rounded-circle bg-soft-success"></i>
									</div>
								</div><!-- end col-->
								<div class="col-8 text-right">
									<p class="text-muted font-14">账号总数</p>
									<h3 class="mb-0" id="count1">0</h3>
								</div><!-- end col-->
							</div><!-- end row-->                                                                                  
						</div><!--end card-body--> 
					</div><!--end card-->
				</div><!--end col-->
				<div class="col-6 col-md-3">
					<div class="card crm-data-card">
						<div class="card-body"> 
							<div class="row">
								<div class="col-4 align-self-center">
									<div class="icon-info">
										<i class="fas fa-calendar-plus rounded-circle bg-soft-pink"></i>
									</div>
								</div><!-- end col-->
								<div class="col-8 text-right">
									<p class="text-muted font-14">今日新增</p>
									<h3 class="mb-0" id="count2">0</h3>                                            
								</div><!-- end col-->
							</div><!-- end row-->
						</div><!--end card-body--> 
					</div><!--end card-->
				</div><!--end col-->
				<div class="col-6 col-md-3">
					<div class="card crm-data-card">
						<div class="card-body"> 
							<div class="row">
								<div class="col-4 align-self-center">
									<div class="icon-info">
										<i class="far fa-calendar-plus rounded-circle bg-soft-purple"></i>
									</div>
								</div><!-- end col-->
								<div class="col-8 text-right">
									<p class="text-muted font-14">昨日新增</p>
									<h3 class="mb-0" id="count3">0</h3>                                            
								</div><!-- end col-->
							</div><!-- end row-->                                                                                     
						</div><!--end card-body--> 
					</div><!--end card--> 
				</div><!--end col-->
				<div class="col-6 col-md-3">
					<div class="card crm-data-card">                                        
						<div class="card-body"> 
							<div class="row">
								<div class="col-4 align-self-center">
									<div class="icon-info">
										<i class="far fa-check-circle rounded-circle bg-soft-warning"></i>
									</div>
								</div><!-- end col-->
								<div class="col-8 text-right">
									<p class="text-muted font-14">今日请求</p>
									<h3 class="mb-0" id="count4">0</h3>
								</div><!-- end col-->
							</div><!-- end row-->
						</div><!--end card-body--> 
					</div><!--end card-->
				</div><!--end col-->
			</div>
			<div class="row">
                <div class="col-lg-12 col-xl-8">
					<div class="card">
						<div class="card-body">
							<h4 class="mt-0 header-title">一周内新账号数量统计</h4>
							<canvas id="lineChart1" class="drop-shadow"></canvas>
						</div><!--end card-body-->
					</div>
					<div class="card">
						<div class="card-body">
							<h4 class="mt-0 header-title">一周内请求次数统计</h4>
							<canvas id="lineChart2" class="drop-shadow"></canvas>
						</div><!--end card-body-->
					</div>
				</div>
				<div class="col-lg-12 col-xl-4">
					<div class="card">
						<div class="card-body">
							<h4 class="mt-0 header-title">登录方式统计</h4>
							<canvas id="pie" class="drop-shadow" height="300"></canvas>
						</div><!--end card-body-->
					</div>
				</div>
			</div>
<?php }?>
		</div><!--end col-->
	</div><!--end row-->

</div><!-- container -->

<?php include 'foot.php';?>
<script src="<?php echo $cdnpublic?>Chart.js/2.9.4/Chart.min.js"></script>
<script>
function generateLineChart(selector,labels,data,max,label,color){
	var lineChart = {
		labels: labels,
		datasets: [{
			label: label,
			fill: false,
			backgroundColor: color,
			borderColor: color,
			data: data
		}]
	};
	var lineOpts = {
		responsive: true,
		tooltips: {
			mode: 'index',
			intersect: false
		},
		hover: {
			mode: 'nearest',
			intersect: true
		},
		legend : {
			labels : {
				fontColor : '#8997bd'  
			}
		},
		scales: {
			xAxes: [{
				display: true,
				gridLines: {
					color: 'rgba(137, 151, 189, 0.15)',
				},
				ticks: {
					fontColor: '#8997bd'
				}
			}],
			yAxes: [{
				gridLines: {
					color: 'rgba(137, 151, 189, 0.15)',                      
				},
				ticks: {
					min: 0,
					max: max,
					fontColor: '#8997bd'
				}
			}]
		}
	};
	var ctx = selector.get(0).getContext("2d");
	new Chart(ctx, {type: 'line', data: lineChart, options: lineOpts});
}
function generatePieChart(selector,labels,data,colors){
	var pieChart = {
		labels: labels,
		datasets: [
			{
				data: data,
				backgroundColor: colors,
				borderColor: "transparent",
				hoverBackgroundColor: colors,
				hoverBorderColor: "#ffffff"
			}]
	};
	var pieChartOpts = {  
		legend : {
			labels : {
				fontColor : '#8997bd'  
			}
		}
	};
	var ctx = selector.get(0).getContext("2d");
	new Chart(ctx, {type: 'pie', data: pieChart, options: pieChartOpts});
}
$(document).ready(function(){
	var ii = layer.load();
	$.ajax({
		type : "GET",
		url : "ajax2.php?act=appstat&appid=<?php echo $appid?>",
		dataType : 'json',
		async: true,
		success : function(data) {
			layer.close(ii);
			$('#count1').html(data.count1);
			$('#count2').html(data.count2);
			$('#count3').html(data.count3);
			$('#count4').html(data.count4);
			generateLineChart($("#lineChart1"),data.dates,data.accounts,data.maxaccounts,'账号数量','#4d79f6');
			generateLineChart($("#lineChart2"),data.dates,data.logs,data.maxlogs,'请求次数','#4ac7ec');
			generatePieChart($("#pie"),data.types,data.typecount,data.colors);
		},
		error:function(data){
			layer.msg('服务器错误');
		}
	});
})
</script>