<?php
@header('Content-Type: text/html; charset=UTF-8');

$admin_cdnpublic = 2;
if($admin_cdnpublic==1){
	$cdnpublic = '//lib.baomitu.com/';
}elseif($admin_cdnpublic==2){
	$cdnpublic = 'https://s4.zstatic.net/ajax/libs/';
}elseif($admin_cdnpublic==4){
	$cdnpublic = '//lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/';
}else{
	$cdnpublic = '//mirrors.sustech.edu.cn/cdnjs/ajax/libs/';
}

$skin = $conf['admin_skin'] ? $conf['admin_skin'] : 'skin-purple-light';
?>
<!DOCTYPE html>
<html lang="zh-cn">
<head>
  <meta charset="utf-8"/>
  <meta name="renderer" content="webkit">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <title><?php echo $title ?></title>
  <link href="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet"/>
  <link href="<?php echo $cdnpublic?>font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet"/>
  <link href="./assets/css/app.min.css" rel="stylesheet">
  <link href="./assets/css/skins/<?php echo $skin?>.css" rel="stylesheet">
  <link href="./assets/css/bootstrap-table.css" rel="stylesheet"/>
  <script src="<?php echo $cdnpublic?>jquery/3.6.4/jquery.min.js"></script>
  <!--[if lt IE 9]>
    <script src="<?php echo $cdnpublic?>html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="<?php echo $cdnpublic?>respond.js/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<?php if(!$islogin) return;?>
<body class="hold-transition <?php echo $skin?> sidebar-mini <?php if(isset($is_collapse)){echo 'sidebar-collapse';}?>">
<div class="wrapper">
  <header class="main-header">
    <!-- Logo -->
    <a href="javascript:;" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><i class="fa fa-cube"></i></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">聚合登录管理中心</span>
    </a>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="visible-xs-inline">菜单</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li>
            <a href="./" title="平台首页"><i class="fa fa-home fa-fw"></i></a>
          </li>
          <li class="hidden-xs">
            <a href="#" data-toggle="fullscreen" title="全屏"><i class="fa fa-arrows-alt fa-fw"></i></a>
          </li>
          <li class="hidden-xs">
            <a href="#" data-toggle="control-sidebar" title="更换皮肤"><i class="fa fa-wrench fa-fw"></i></a>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="./assets/img/user.png" class="user-image" alt="User Image">
              <span class="hidden-xs"><?php echo $conf['admin_user']?></span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="./assets/img/user.png" class="img-circle" alt="User Image">
                <p>
                  <?php echo $conf['admin_user']?>
                  <small><?php echo $conf['build']?></small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="./set.php?mod=account" class="btn btn-primary"><i class="fa fa-lock"></i> 修改密码</a>
                </div>
                <div class="pull-right">
                  <a href="./login.php?logout" class="btn btn-danger"><i class="fa fa-sign-out"></i> 退出登录</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="./assets/img/user.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo $conf['admin_user']?></p>
          <i class="fa fa-circle text-success"></i> Online
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">功能导航</li>
        <li class="<?php echo checkIfActive('index,')?>">
            <a href="./"><i class="fa fa-home fa-fw"></i> <span>平台首页</span></a>
        </li>
		    <li class="<?php echo checkIfActive('apps,edit')?>">
            <a href="./apps.php"><i class="fa fa-cubes fa-fw"></i> <span>应用列表</span></a>
        </li>
		    <li class="treeview <?php echo checkIfActive('accounts,logs,domainstat')?>">
          <a href="#"><i class="fa fa-list-ul fa-fw"></i> <span>聚合登录</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
          <ul class="treeview-menu">
            <li class="<?php echo checkIfActive('accounts')?>"><a href="./accounts.php"><i class="fa fa-circle-o"></i> 第三方账号列表</a></li>
            <li class="<?php echo checkIfActive('logs')?>"><a href="./logs.php"><i class="fa fa-circle-o"></i> 登录记录</a></li>
            <li class="<?php echo checkIfActive('domainstat')?>"><a href="./domainstat.php"><i class="fa fa-circle-o"></i> 域名登录统计</a></li>
          </ul>
        </li>
		    <li class="treeview <?php echo checkIfActive('ulist,glist,group,uset,userlog')?>">
          <a href="#"><i class="fa fa-user fa-fw"></i> <span>用户管理</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
          <ul class="treeview-menu">
            <li class="<?php echo checkIfActive('ulist,uset')?>"><a href="./ulist.php"><i class="fa fa-circle-o"></i> 用户列表</a></li>
            <li class="<?php echo checkIfActive('glist')?>"><a href="./glist.php"><i class="fa fa-circle-o"></i> 用户组设置</a></li>
            <li class="<?php echo checkIfActive('group')?>"><a href="./group.php"><i class="fa fa-circle-o"></i> 用户组购买</a></li>
            <li class="<?php echo checkIfActive('userlog')?>"><a href="./userlog.php"><i class="fa fa-circle-o"></i> 登录日志</a></li>
          </ul>
        </li>
        <li class="<?php echo checkIfActive('order')?>">
            <a href="./order.php"><i class="fa fa-shopping-cart fa-fw"></i> <span>订单管理</span></a>
        </li>
		    <li class="<?php echo checkIfActive('set_login')?>">
          <a href="./set_login.php"><i class="fa fa-certificate fa-fw"></i> <span>接口配置</span></a>
        </li>
		    <li class="treeview <?php echo checkIfActive('set,gonggao,clean')?>">
          <a href="#"><i class="fa fa-cog fa-fw"></i> <span>系统设置</span><span class="pull-right-container"><i class="fa fa-angle-left pull-right"></i></span></a>
          <ul class="treeview-menu">
            <li class="<?php echo checkIfActiveMod('site')?>"><a href="./set.php?mod=site"><i class="fa fa-circle-o"></i> 网站信息配置</a></li>
            <li class="<?php echo checkIfActiveMod('oauth')?>"><a href="./set.php?mod=oauth"><i class="fa fa-circle-o"></i> 快捷登录配置</a><li>
            <li class="<?php echo checkIfActiveMod('pay')?>"><a href="./set.php?mod=pay"><i class="fa fa-circle-o"></i> 支付接口配置</a><li>
            <li class="<?php echo checkIfActive('gonggao')?>"><a href="./gonggao.php"><i class="fa fa-circle-o"></i> 网站公告配置</a></li>
            <li class="<?php echo checkIfActiveMod('mail')?>"><a href="./set.php?mod=mail"><i class="fa fa-circle-o"></i> 邮箱与短信配置</a><li>
            <li class="<?php echo checkIfActiveMod('upimg')?>"><a href="./set.php?mod=upimg"><i class="fa fa-circle-o"></i> 网站Logo上传</a><li>
            <li class="<?php echo checkIfActiveMod('iptype')?>"><a href="./set.php?mod=iptype"><i class="fa fa-circle-o"></i> IP地址获取设置</a><li>
            <li class="<?php echo checkIfActiveMod('proxy')?>"><a href="./set.php?mod=proxy"><i class="fa fa-circle-o"></i> 中转代理设置</a><li>
            <li class="<?php echo checkIfActive('clean')?>"><a href="./clean.php"><i class="fa fa-circle-o"></i> 数据清理</a><li>
          </ul>
        </li>
        <li class="<?php echo checkIfActive('update')?>">
          <a href="./update.php"><i class="fa fa-cloud-download fa-fw"></i> <span>检查更新</span></a>
        </li>
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content">