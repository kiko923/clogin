<?php
/**
 * 彩虹易支付同步通知页面
 */

include "../../includes/common.php";

$out_trade_no = isset($_GET['out_trade_no'])?daddslashes($_GET['out_trade_no']):exit('error');
$srow=$DB->getRow("SELECT * FROM pre_order WHERE trade_no='{$out_trade_no}' LIMIT 1");
$pay_config = get_pay_api($srow['channel']);

require('inc/EpayCore.class.php');

//计算得出通知验证结果
$epayNotify = new EpayCore($pay_config);
$verify_result = $epayNotify->verifyReturn();
if($verify_result && ($conf['alipay_api']==2 || $conf['qqpay_api']==2 || $conf['wxpay_api']==2 || $conf['qqpay_api']==8 || $conf['wxpay_api']==8 || $conf['wxpay_api']==9) && !empty($pay_config['pid']) && !empty($pay_config['key'])) {

	//易支付交易号
	$trade_no = daddslashes($_GET['trade_no']);

	//交易状态
	$trade_status = $_GET['trade_status'];

	//金额
	$money = $_GET['money'];

    if($_GET['trade_status'] == 'TRADE_SUCCESS' && round($srow['money'],2)==round($money,2)) {
		if($srow['status']==0){
			if($DB->exec("UPDATE `pre_order` SET `status` ='1' WHERE `trade_no`='{$out_trade_no}'")){
				$DB->exec("UPDATE `pre_order` SET `endtime` ='$date',`api_trade_no` ='$trade_no' WHERE `trade_no`='{$out_trade_no}'");
				processOrder($srow);
			}
		}
		pay_return($out_trade_no,$srow['tid']);
    }
    else {
		sysmsg('订单信息校验失败');
    }
}
else {
    //验证失败
	sysmsg('验证失败！');
}

?>