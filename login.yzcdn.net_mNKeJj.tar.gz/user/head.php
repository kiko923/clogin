<?php
@header('Content-Type: text/html; charset=UTF-8');
if($userrow['status']==0){
	sysmsg('你的账号由于违反相关法律法规与《<a href="../agreement.php">'.$conf['sitename'].'用户协议</a>》，已被禁用！');
}

?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
	<meta charset="utf-8" />
	<meta name="renderer" content="webkit">
	<title><?php echo $title?> - <?php echo $conf['sitename']?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no">
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<link href="<?php echo $cdnpublic?>twitter-bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>jqueryui/1.12.1/jquery-ui.min.css" rel="stylesheet">
	<link href="<?php echo $cdnpublic?>font-awesome/5.15.3/css/all.min.css" rel="stylesheet" type="text/css" />
	<link href="<?php echo $cdnpublic?>metisMenu/3.0.7/metisMenu.min.css" rel="stylesheet" type="text/css" />
	<link href="./assets/css/app.min.css" rel="stylesheet" type="text/css" />
</head>
<body>
	<!-- Top Bar Start -->
	<div class="topbar">
		<!-- LOGO -->
		<div class="topbar-left">
			<a href="../" class="logo">
				<span>
					<img src="../assets/img/logo.png" alt="logo-small" class="logo-sm">
				</span>
				<span>
					<?php echo $conf['sitename']?>
				</span>
			</a>
		</div>
		<!--end logo-->
		<!-- Navbar -->
		<nav class="navbar-custom">    
			<ul class="list-unstyled topbar-nav float-right mb-0"> 
				<li class="dropdown">
					<a class="nav-link dropdown-toggle waves-effect waves-light nav-user" data-toggle="dropdown" href="#" role="button"
						aria-haspopup="false" aria-expanded="false">
						<img src="<?php echo ($userrow['qq'])?'//q2.qlogo.cn/headimg_dl?bs=qq&dst_uin='.$userrow['qq'].'&src_uin='.$userrow['qq'].'&fid='.$userrow['qq'].'&spec=100&url_enc=0&referer=bu_interface&term_type=PC':'assets/images/user.png'?>" alt="profile-user" class="rounded-circle" /> 
						<span class="ml-1 nav-user-name hidden-sm"><?php echo $userrow['user']?> <i class="fas fa-chevron-down"></i> </span>
					</a>
					<div class="dropdown-menu dropdown-menu-right">
						<a class="dropdown-item" href="./"><i class="fas fa-user-circle fa-fw text-muted mr-2"></i> 用户中心</a>
						<a class="dropdown-item" href="userinfo.php"><i class="fas fa-user-cog fa-fw text-muted mr-2"></i> 修改资料</a>
						<a class="dropdown-item" href="userinfo.php?mod=account"><i class="fas fa-lock fa-fw text-muted mr-2"></i> 修改密码</a>
						<div class="dropdown-divider mb-0"></div>
						<a class="dropdown-item" href="login.php?logout"><i class="fas fa-sign-out-alt fa-fw text-muted mr-2"></i> 退出登录</a>
					</div>
				</li>
			</ul><!--end topbar-nav-->

			<ul class="list-unstyled topbar-nav mb-0">                        
				<li>
					<button class="nav-link button-menu-mobile waves-effect waves-light">
						<i class="fas fa-align-justify nav-icon"></i>
					</button>
				</li>
				<li class="hide-phone app-search">
					<form role="search" class="apps.php">
						<input type="text" name="appkw" placeholder="搜索应用" class="form-control" autocomplete="off">
						<a href="javascript:searchApp()"><i class="fas fa-search"></i></a>
					</form>
				</li>
			</ul>
		</nav>
		<!-- end navbar-->
	</div>
	<!-- Top Bar End -->

	
	<!-- Left Sidenav -->
	<div class="left-sidenav">
		<ul class="metismenu left-sidenav-menu">
			<li class="<?php echo checkIfActivemm(',index')?>">
				<a href="./"><i class="fas fa-user-circle fa-fw"></i><span>用户中心</span></a>
			</li>

			<li class="<?php echo checkIfActivemm('apps,accounts,logs,appinfo,appstat')?>">
				<a href="./apps.php"><i class="fas fa-cubes fa-fw"></i><span>应用列表</span></a>
			</li>

			<li class="<?php echo checkIfActivemm('appadd')?>">
				<a href="./appadd.php"><i class="fas fa-plus-circle fa-fw"></i><span>创建应用</span></a>
			</li>

			<li class="<?php echo checkIfActivemm('editinfo,userinfo')?>">
				<a href="./userinfo.php"><i class="fas fa-user-cog fa-fw"></i><span>个人资料</span></a>
			</li>

			<?php if($conf['group_buy']==1){?><li class="<?php echo checkIfActivemm('groupbuy')?>">
				<a href="./groupbuy.php"><i class="fas fa-cart-plus fa-fw"></i><span>会员购买</span></a>
			</li><?php }?>

			<li>
				<a href="../doc.php"><i class="fas fa-book fa-fw"></i><span>开发文档</span></a>
			</li>

			<?php if(!empty($conf['qqqun'])){?><li>
				<a href="<?php echo $conf['qqqun']?>" target="blank"><i class="fas fa-comments fa-fw"></i><span>产品QQ群</span></a>
			</li><?php }?>

			<li>
				<a href="https://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']?>&site=qq&menu=yes" target="blank"><i class="fab fa-qq fa-fw"></i><span>联系我们</span></a>
			</li>

		</ul>
	</div>
	<!-- end left-sidenav-->

	<div class="page-wrapper">
            <!-- Page Content-->
            <div class="page-content">