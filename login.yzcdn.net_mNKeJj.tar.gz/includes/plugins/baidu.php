<?php
namespace plugins;

use Exception;

class baidu {

	static public $info = [
		'name'        => 'baidu',
		'showname'    => '百度',
		'link'        => 'https://pan.baidu.com/union/home',
		'sort'        => 15,
		'abroad'      => false,
		'input' => [
			'appkey' => [
				'name' => 'AppKey',
				'type' => 'input',
				'note' => '',
			],
			'secretkey' => [
				'name' => 'SecretKey',
				'type' => 'input',
				'note' => '',
			],
		],
	];

	const GET_AUTH_CODE_URL = "https://openapi.baidu.com/oauth/2.0/authorize";
	const GET_ACCESS_TOKEN_URL = "https://openapi.baidu.com/oauth/2.0/token";
	const GET_OPENID_URL = "https://openapi.baidu.com/rest/2.0/passport/users/getInfo";

	private $appkey;
	private $secretkey;
	private $callback;

	public function __construct($config)
	{
		global $siteurl;
		$this->appkey = $config['appkey'];
		$this->secretkey = $config['secretkey'];
		$this->callback = $siteurl.'return.php';
	}

	public function help(){
		global $siteurl;
		return '●&nbsp;<a href="https://pan.baidu.com/union/home" target="_blank" rel="noreferrer">申请地址</a>，OAuth授权回调页填写：'.$siteurl.'return.php<br/>●&nbsp;<b>注意：配置好之后请勿随意更换应用，否则之前已登录的用户将全部失效！</b>';
	}

	public function login($state){
		$param = [
			"response_type" => "code",
			"client_id" => $this->appkey,
			"redirect_uri" => $this->callback,
			"scope" => 'basic',
			"display" => 'page',
			"state" => $state
		];

		$url =  self::GET_AUTH_CODE_URL.'?'.http_build_query($param);

		return $url;
	}

	public function callback($code, $type = 0, $mode = 0){
		$access_token = $this->get_access_token($code);
		$userinfo = $this->get_userinfo($access_token);

		$faceimg = 'https://himg.bdimg.com/sys/portrait/item/'.$userinfo['portrait'].'.jpg';

		$result = [
			'access_token' => $access_token,
			'social_uid' => $userinfo['openid'],
			'faceimg' => $faceimg,
			'nickname' => $userinfo['username'],
		];

		return $result;
	}

	private function get_access_token($code){
		$param = [
			"grant_type" => "authorization_code",
			"code" => $code,
			"client_id" => $this->appkey,
			"client_secret" => $this->secretkey,
			"redirect_uri" => $this->callback
		];

		$url = self::GET_ACCESS_TOKEN_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['access_token'])){
			return $arr['access_token'];
		}elseif(isset($arr['error'])){
			throw new Exception('获取access_token失败 ['.$arr['error'].']'.$arr['error_description']);
		}else{
			throw new Exception('获取access_token失败，原因未知');
		}
	}

	private function get_userinfo($access_token){
		$param = [
			"access_token" => $access_token
		];

		$url = self::GET_OPENID_URL.'?'.http_build_query($param);
		$response = get_curl_api(self::$info['abroad'], $url);
		$arr = json_decode($response, true);
		if(isset($arr['openid'])){
			return $arr;
		}elseif(isset($arr['error_msg'])){
			throw new Exception('获取用户信息失败 ['.$arr['error_code'].']'.$arr['error_msg']);
		}else{
			throw new Exception('获取用户信息失败，原因未知');
		}
	}

}