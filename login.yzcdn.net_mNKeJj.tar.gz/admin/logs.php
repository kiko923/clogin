<?php
include("../includes/common.php");
$title='登录记录';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<style>
td{overflow: hidden;text-overflow: ellipsis;white-space: nowrap;max-width:300px;}
</style>
<div class="row">
<div class="col-xs-12 center-block" style="float: none;">
<div class="panel panel-default panel-intro">
<div class="panel-body">
<?php
$logintype = [];
$loginselect = '';
$rs = $DB->getAll("SELECT name,showname FROM pre_type ORDER BY sort ASC");
foreach($rs as $row){
	$logintype[$row['name']] = $row['showname'];
	$loginselect .= '<option value="'.$row['name'].'">'.$row['showname'].'</option>';
}
unset($rs);

?>
<div id="searchToolbar">
<form onsubmit="return searchSubmit()" method="GET" class="form-inline">
  <div class="form-group">
    <label>搜索</label>
	<select name="column" class="form-control"><option value="openid">第三方账号UID</option><option value="domain">网站域名</option><option value="ip">登录IP</option></select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="搜索内容">
  </div>
  <div class="form-group">
	<select name="type" class="form-control"><option value="0">所有登录方式</option><?php echo $loginselect?></select>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="appid" style="width: 100px;" placeholder="APPID">
  </div>
  <div class="form-group">
	<input type="text" class="form-control" name="uid" style="width: 100px;" placeholder="UID">
  </div>
  <div class="form-group">
	<button class="btn btn-primary" type="submit"><i class="fa fa-search"></i> 搜索</button>&nbsp;
	<a href="javascript:searchClear()" class="btn btn-default"><i class="fa fa-repeat"></i> 重置</a>
  </div>
</form>
</div>
      <table id="listTable">
	  </table>
    </div>
</div>
</div>
</div>
<?php include './foot.php';?>
<script src="<?php echo $cdnpublic?>layer/3.1.1/layer.min.js"></script>
<script src="<?php echo $cdnpublic?>bootstrap-table/1.21.4/bootstrap-table.min.js"></script>
<script src="<?php echo $cdnpublic?>bootstrap-table/1.21.4/extensions/page-jump-to/bootstrap-table-page-jump-to.min.js"></script>
<script src="./assets/js/custom.js"></script>
<script>
$(document).ready(function(){
	updateToolbar();
	const defaultPageSize = 30;
	const pageNumber = typeof window.$_GET['pageNumber'] != 'undefined' ? parseInt(window.$_GET['pageNumber']) : 1;
	const pageSize = typeof window.$_GET['pageSize'] != 'undefined' ? parseInt(window.$_GET['pageSize']) : defaultPageSize;

	$("#listTable").bootstrapTable({
		url: 'ajax_accounts.php?act=logList',
		pageNumber: pageNumber,
		pageSize: pageSize,
		classes: 'table table-striped table-hover table-bottom-border',
		columns: [
			{
				field: 'id',
				title: 'ID',
				formatter: function(value, row, index) {
					return '<b>'+value+'</b>';
				}
			},
			{
				field: 'appid',
				title: 'APPID',
				formatter: function(value, row, index) {
					return '<a href="./apps.php?column=appid&value='+value+'" target="_blank">'+value+'</a>';
				}
			},
			{
				field: 'uid',
				title: 'UID',
				formatter: function(value, row, index) {
					return '<a href="./ulist.php?column=uid&value='+value+'" target="_blank">'+value+'</a>';
				}
			},
			{
				field: 'typename',
				title: '方式'
			},
			{
				field: 'openid',
				title: '第三方账号UID'
			},
			{
				field: 'domain',
				title: '网站域名',
				formatter: function(value, row, index) {
					return '<a href="http://'+value+'" target="_blank" rel="noopener noreferrer">'+value+'</a>';
				}
			},
			{
				field: 'ip',
				title: '登录IP',
				formatter: function(value, row, index) {
					return '<a href="https://m.ip138.com/iplookup.asp?ip='+value+'" target="_blank" rel="noreferrer">'+value+'</a>';
				}
			},
			{
				field: 'endtime',
				title: '登录时间'
			},
		],
	})
})
</script>
</body>
</html>