<?php
$wechatpay_config = [
	//绑定支付的APPID
	'appid' => $conf['wxpay_appid'],

	//商户号
	'mchid' => $conf['wxpay_mchid'],

	//商户APIv2密钥
	'apikey' => $conf['wxpay_key'],

	//公众帐号secert（仅JSAPI支付需要配置）
	'appsecret' => $conf['wxpay_appsecret'],

	//商户证书路径（仅退款、撤销订单时需要）
	'sslcert_path' => SYSTEM_ROOT.'wxpay/cert/apiclient_cert.pem',

	//商户证书私钥路径
	'sslkey_path' => SYSTEM_ROOT.'wxpay/cert/apiclient_key.pem',
];

return $wechatpay_config;