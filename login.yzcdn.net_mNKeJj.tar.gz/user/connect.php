<?php
/**
 * 第三方登录回调
**/
include("../includes/common.php");

if(!$conf['default_appid'])exit('{"code":-1,"msg":"未配置默认应用APPID"}');
$apptype = $DB->getcolumn("select type from pre_apps where appid='{$conf['default_appid']} limit 1");

$type = isset($_GET['type'])?$_GET['type']:exit('{"code":-1,"msg":"no type"}');
if($type == 'qq'){
	$typename = 'QQ';
	$typecolumn = 'qq_uid';
}elseif($type == 'wx'){
	$typename = '微信';
	$typecolumn = 'wx_uid';
}elseif($type == 'alipay'){
	$typename = '支付宝';
	$typecolumn = 'alipay_uid';
}

if ($_GET['code']) {
	if($_GET['state'] != $_SESSION['Oauth_state']){
		sysmsg("The state does not match. You may be a victim of CSRF.");
	}

    $connect = new \lib\Connect($conf['default_appid']);
    $arr = $connect->callback($_GET['code'], $apptype);
	if(isset($arr['code']) && $arr['code']==0){
		$social_uid=$arr['social_uid'];
		$access_token=$arr['access_token'];
	}elseif(isset($arr['code'])){
		sysmsg($arr['msg']);
	}else{
		sysmsg('获取登录数据失败');
	}

	$userrow=$DB->getRow("SELECT * FROM pre_user WHERE {$typecolumn}='{$social_uid}' limit 1");
	if($userrow){
		$uid=$userrow['uid'];
		$user=$userrow['user'];
		$pwd=$userrow['pwd'];
		if($islogin2==1){
			@header('Content-Type: text/html; charset=UTF-8');
			exit("<script language='javascript'>alert('当前{$typename}已绑定用户:{$user}，请勿重复绑定！');window.location.href='./userinfo.php';</script>");
		}
		$DB->exec("insert into `pre_log` (`uid`,`type`,`date`,`ip`) values ('".$uid."','第三方登录','".$date."','".$clientip."')");
		$session=md5($user.$pwd.$password_hash);
		$expiretime=time()+604800;
		$token=authcode("{$uid}\t{$session}\t{$expiretime}", 'ENCODE', SYS_KEY);
		ob_clean();
		setcookie("user_token", $token, time() + 604800);
		$DB->exec("update `pre_user` set `lasttime`=NOW() where `uid`='$uid'");
		exit("<script language='javascript'>window.location.href='./';</script>");
	}elseif($islogin2==1){
		$sds=$DB->exec("update `pre_user` set `{$typecolumn}` ='$social_uid' where `uid`='$uid'");
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('已成功绑定{$typename}！');window.location.href='./userinfo.php';</script>");
	}else{
		$_SESSION['Oauth_social_type']=$type;
		$_SESSION['Oauth_social_uid']=$social_uid;
		@header('Content-Type: text/html; charset=UTF-8');
		exit("<script language='javascript'>alert('请输入账号密码完成绑定');window.location.href='./login.php?connect=true';</script>");
	}
}
elseif($islogin2==1 && isset($_GET['unbind'])){
	$DB->exec("update `pre_user` set `{$typecolumn}`=NULL where `uid`='$uid'");
	@header('Content-Type: text/html; charset=UTF-8');
	exit("<script language='javascript'>alert('您已成功解绑{$typename}！');window.location.href='./userinfo.php';</script>");
}