<?php
$qqpay_config = [
	//商户号
	'mchid' => $conf['qqpay_mchid'],

	//商户API密钥
	'apikey' => $conf['qqpay_key'],

    //公众号APPID（可空）
	'appid' => '',

    //操作员账号（仅退款、撤销订单、企业付款时需要）
	//创建操作员说明：https://kf.qq.com/faq/170112AZ7Fzm170112VNz6zE.html
    'op_userid' => '',

    //操作员密码
    'op_userpwd' => '',

	//商户证书路径（仅退款、撤销订单、企业付款时需要）
	'sslcert_path' => SYSTEM_ROOT.'qqpay/cert/apiclient_cert.pem',

	//商户证书私钥路径
	'sslkey_path' => SYSTEM_ROOT.'qqpay/cert/apiclient_key.pem',
];

return $qqpay_config;