<?php
/**
 * 企业微信扫码登录页面
**/
if(!defined('IN_CRONLITE'))exit();
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8" />
<title>企业微信登录</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<link rel="stylesheet" href="<?php echo $cdnpublic?>twitter-bootstrap/3.4.1/css/bootstrap.min.css" type="text/css" />
<link rel="stylesheet" href="./assets/css/app.css?v=2" type="text/css" />
</head>
<body>
<div class="app app-header-fixed  ">
<div class="container w-xxl w-auto-xs" ng-controller="SigninFormController" ng-init="app.settings.container = false;">
<span class="navbar-brand block m-t" id="sitename">企业微信扫码登录</span>
<div class="m-b-lg">
<form name="form" class="form-validation">
<div class="text-danger wrapper text-center" ng-show="authError">
</div>
	<div class="form-group" style="text-align: center;">
		<div class="list-group-item list-group-item-success" style="font-weight: bold;" id="login">
			<span id="loginmsg">请使用企业微信扫描二维码登录</span>
		</div>
		<div class="list-group-item" style="font-weight: bold;padding:16px;">
			<div id="qrcode" class="qr-image">
			</div>
		</div>
		<div class="list-group-item" style="font-weight: bold; display:none" id="mobile">
			提示：手机用户可截图保存二维码，在企业微信内扫一扫，从相册识别二维码。
		</div>
		</div>
	</div>
</form>
</div>
<div id="footer" class="text-center" style="position: absolute;margin-top: auto;left: 0;bottom: 0;width: 100%;line-height: 30px;padding: 20px;">
<p>
<small class="text-muted"><?php echo $conf['sitename']?><br>&copy; <?php echo date("Y")?></small>
</p>
</div>
</div>
</div>
<script src="<?php echo $cdnpublic?>jquery/3.3.1/jquery.min.js"></script>
<script src="<?php echo $cdnpublic?>layer/3.5.1/layer.js"></script>
<script src="<?php echo $cdnpublic?>jquery.qrcode/1.0/jquery.qrcode.min.js"></script>
<script>
var qrcode_url = "<?php echo $qrcode_url?>";
var state = "<?php echo $_GET['state']?>";
$(document).ready(function(){
	$('#qrcode').qrcode({
        text: qrcode_url,
        width: 230,
        height: 230,
        foreground: "#000000",
        background: "#ffffff",
        typeNumber: -1
    });
	if( /Android|SymbianOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|Windows Phone|Midp/i.test(navigator.userAgent)) {
		$('#mobile').show();
	}
	setTimeout('checkopenid()', 2000);
});
function checkopenid(auto){
	auto = auto || true;
	$.ajax({
		type: "GET",
		dataType: "json",
		url: "ajax.php?act=login&state="+encodeURIComponent(state),
		success: function (data, textStatus) {
			if (data.code == 0) {
				layer.msg(data.msg, {icon: 16,time: 10000,shade:[0.3, "#000"]});
				setTimeout(function(){ window.location.href=data.url }, 1000);
			}else if (data.code == 1) {
				if(auto) setTimeout('checkopenid()', 2000);
			}else{
				layer.alert(data.msg, {icon:2});
			}
		},
		error: function (data) {
			layer.msg('服务器错误', {icon: 2});
			return false;
		}
	});
}
</script>
</body>
</html>