<?php
/**
 * 支付宝WAP登录页面
**/
if(!defined('IN_CRONLITE'))exit();
?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta charset="UTF-8">
    <title>支付宝快捷登录</title>
    <meta id="viewport" name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <link href="./assets/css/alipay_login.css" rel="stylesheet" type="text/css" />
</head>
<body>
    <div id="content">
        <header class="page_header_upice">
            <div class="logo_upice"><svg t="1653384581976" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="2968" width="115" height="200"><path d="M1024.0512 701.0304V196.864A196.9664 196.9664 0 0 0 827.136 0H196.864A196.9664 196.9664 0 0 0 0 196.864v630.272A196.9152 196.9152 0 0 0 196.864 1024h630.272a197.12 197.12 0 0 0 193.8432-162.0992c-52.224-22.6304-278.528-120.32-396.4416-176.64-89.7024 108.6976-183.7056 173.9264-325.3248 173.9264s-236.1856-87.2448-224.8192-194.048c7.4752-70.0416 55.552-184.576 264.2944-164.9664 110.08 10.3424 160.4096 30.8736 250.1632 60.5184 23.1936-42.5984 42.496-89.4464 57.1392-139.264H248.064v-39.424h196.9152V311.1424H204.8V267.776h240.128V165.632s2.1504-15.9744 19.8144-15.9744h98.4576V267.776h256v43.4176h-256V381.952h208.8448a805.9904 805.9904 0 0 1-84.8384 212.6848c60.672 22.016 336.7936 106.3936 336.7936 106.3936zM283.5456 791.6032c-149.6576 0-173.312-94.464-165.376-133.9392 7.8336-39.3216 51.2-90.624 134.4-90.624 95.5904 0 181.248 24.4736 284.0576 74.5472-72.192 94.0032-160.9216 150.016-253.0816 150.016z" p-id="2969" fill="#1890ff"></path></svg></div>
            <p class="title_upice">支付宝快捷登录</p>
        </header>
        <div class="page_content">
            <div id="web_login">
                <div class="login_form_panel">
                    <div class="btn_group">
                        <div href="javascript:void(0);" id="onekey" class="ui-button-main ui-button-primary">一键登录</div>
                        <div href="javascript:void(0);" class="ui-button-main ui-button-primary weak" style="margin-top:30px" id="logincomplete">已完成登录</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="error_tips" class="msgbox alert hide">
        <div id="error_message" class="text"></div>
    </div>
    <div class="copyright">
        <?php echo $conf['sitename']?><br/>&copy; <?php echo date("Y")?>
    </div>
<script src="<?php echo $cdnpublic?>jquery/1.12.4/jquery.min.js"></script>
<script src="./assets/js/loginui.js"></script>
<script>
var qrcode_url = "<?php echo $qrcode_url?>";
var state = "<?php echo $_GET['state']?>";
function jump(){
	var ua = window.navigator.userAgent;
	if(ua.match(/MicroMessenger/i)){
		ui_alert.show('请点击右上角，在浏览器打开。登录完成后返回微信查看结果。');
	}else{
		window.location.href='alipays://platformapi/startapp?appId=20000067&url='+encodeURIComponent(qrcode_url);
	}
}
$(document).ready(function(){
	var ua = window.navigator.userAgent;
	if(ua.indexOf('Android')>-1 && ua.match(/Quark|SogouMSE|SogouMobileBrowser|OppoBrowser|HeyTapBrowser|SamsungBrowser|MQQBrowser|baidubrowser|baiduboxapp|QihooBrowser|UCBrowser|2345Browser|Firefox|LieBaoFast|MiuiBrowser|opr|vivo/i) || ua.indexOf('Android')==-1){
		jump();
	}
	setTimeout('checkopenid()', 2000);
	$("#onekey").click(function(){
		var self = $(this);
		self.text('正在拉起支付宝APP...');
		jump();
		clearTimeout(window.openAppClock);
		window.openAppClock = setTimeout(function(){ self.text('一键登录'); }, 2000);
	});
	$("#logincomplete").click(function(){
		checkopenid(false)
	})
});
function checkopenid(auto){
	auto = auto || true;
	$.ajax({
		type: "GET",
		dataType: "json",
		url: "ajax.php?act=login&state="+encodeURIComponent(state),
		success: function (data, textStatus) {
			if (data.code == 0) {
				ui_load.startLoading();
				$("#logincomplete").text(data.msg);
				setTimeout(function(){ window.location.href=data.url }, 600);
			}else if (data.code == 1) {
				if(auto) setTimeout('checkopenid()', 2000);
			}else{
				ui_alert.show(data.msg);
			}
		},
		error: function (data) {
			ui_alert.show('服务器错误');
			return false;
		}
	});
}
</script>
</body>
</html>