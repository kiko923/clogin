<?php

namespace lib;

// 微信消息服务类
class WechatMsg
{
	private $request;

	/**
	 * 初始化，判断此次请求是否为验证请求，并以数组形式保存
	 *
	 * @param string $token 验证信息
	 */
	public function __construct($token)
	{
		if (!$this->validateSignature($token)) {
			exit('签名验证失败');
		}

		if ($this->isValid()) {
			// 网址接入验证
			exit($_GET['echostr']);
		}

		$xml = isset($GLOBALS['HTTP_RAW_POST_DATA']) ? $GLOBALS['HTTP_RAW_POST_DATA'] : file_get_contents("php://input");

		if (!$xml) {
			exit('缺少数据');
		}

		libxml_disable_entity_loader(true);
		$array = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);

		$this->request = $array;
	}

	/**
	 * 判断此次请求是否为验证请求
	 *
	 * @return boolean
	 */
	private function isValid()
	{
		return isset($_GET['echostr']);
	}

	/**
	 * 验证此次请求的签名信息
	 *
	 * @param  string $token 验证信息
	 * @return boolean
	 */
	private function validateSignature($token)
	{
		if (!(isset($_GET['signature']) && isset($_GET['timestamp']) && isset($_GET['nonce']))) {
			return FALSE;
		}

		$signature = $_GET['signature'];
		$timestamp = $_GET['timestamp'];
		$nonce = $_GET['nonce'];

		$signatureArray = array($token, $timestamp, $nonce);
		sort($signatureArray, SORT_STRING);

		return sha1(implode($signatureArray)) == $signature;
	}

	/**
	 * 获取本次请求中的参数
	 *
	 * @param  string $param 参数名，默认为无参
	 * @return mixed
	 */
	public function getRequest($param = FALSE)
	{
		if ($param === FALSE) {
			return $this->request;
		}

		if (isset($this->request[$param])) {
			return $this->request[$param];
		}

		return NULL;
	}

	/**
	 * 获取扫码后的scene_str
	 *
	 * @return mixed
	 */
	public function getSceneStr()
	{
		if($this->request['MsgType'] == 'event' && ($this->request['Event'] == 'subscribe' || $this->request['Event'] == 'SCAN')){
			$key = $this->request['EventKey'];
			$key = str_replace('qrscene_','',$key);
			return $key;
		}
		return false;
	}

	/**
	 * 回复文本消息
	 *
	 * @param  string  $content  消息内容
	 * @return void
	 */
	public function responseText($content)
	{
		$ToUserName = $this->getRequest('FromUserName');
		$FromUserName = $this->getRequest('ToUserName');
		$template = <<<XML
<xml>
  <ToUserName><![CDATA[%s]]></ToUserName>
  <FromUserName><![CDATA[%s]]></FromUserName>
  <CreateTime>%s</CreateTime>
  <MsgType><![CDATA[text]]></MsgType>
  <Content><![CDATA[%s]]></Content>
</xml>
XML;
		echo sprintf($template, $ToUserName, $FromUserName, time(), $content);
	}
}
