<?php
include("../includes/common.php");
$title='彩虹聚合登录管理中心';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<?php
$mysqlversion=$DB->getColumn("select VERSION()");
$checkupdate = getCheckString();
?>
<div class="row">
	<div class="col-md-3 col-xs-6">
		<!-- small box -->
		<div class="small-box bg-aqua">
		<div class="inner">
			<h3 id="count1">0</h3>
			<p>用户数量</p>
		</div>
		<div class="icon">
			<i class="fa fa-users"></i>
		</div>
		<a href="./ulist.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
		</div>
	</div>
	<!-- ./col -->
	<div class="col-md-3 col-xs-6">
		<!-- small box -->
		<div class="small-box bg-green">
		<div class="inner">
			<h3 id="count2">0</h3>
			<p>应用数量</p>
		</div>
		<div class="icon">
			<i class="fa fa-cubes"></i>
		</div>
		<a href="./apps.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
		</div>
	</div>
	<!-- ./col -->
	<div class="col-md-3 col-xs-6">
		<!-- small box -->
		<div class="small-box bg-yellow">
		<div class="inner">
			<h3 id="count3">0</h3>
			<p>第三方账号总数</p>
		</div>
		<div class="icon">
			<i class="fa fa-cloud"></i>
		</div>
		<a href="./accounts.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
		</div>
	</div>
	<!-- ./col -->
	<div class="col-md-3 col-xs-6">
		<!-- small box -->
		<div class="small-box bg-red">
		<div class="inner">
			<h3 id="count4">0</h3>
			<p>今日登录次数</p>
		</div>
		<div class="icon">
			<i class="fa fa-connectdevelop"></i>
		</div>
		<a href="./logs.php" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
		</div>
	</div>
	<!-- ./col -->
</div>
<!-- /.row -->
<div class="row">
<div class="col-md-7 col-sm-12">
	<div class="box box-primary">
		<div class="box-header with-border">
			<i class="fa fa-pie-chart"></i>
			<h3 class="box-title">登录次数统计</h3>
		</div>
		<div class="box-body">
		<canvas id="lineChart" class="drop-shadow"></canvas>
		</div>
	</div>
</div>
<div class="col-md-5 col-sm-12">
	<div id="browser-notice"></div>
	<div class="box box-success">
		<div class="box-header with-border">
			<i class="fa fa-server"></i>
			<h3 class="box-title">环境信息</h3>
		</div>
		<ul class="list-group">
            <li class="list-group-item">
				<b>PHP 版本：</b><?php echo phpversion() ?>
			</li>
			<li class="list-group-item">
				<b>MySQL 版本：</b><?php echo $mysqlversion ?>
			</li>
			<li class="list-group-item">
				<b>服务器软件：</b><?php echo $_SERVER['SERVER_SOFTWARE'] ?>
			</li>
			<li class="list-group-item">
				<b>服务器时间：</b><?php echo $date ?>
			</li>
			</li>
        </ul>
	</div>
	<div class="box box-default">
		<div class="box-header with-border">
			<i class="fa fa-volume-up"></i>
			<h3 class="box-title">检查更新</h3>
		</div>
		<ul class="list-group text-dark" id="checkupdate"></ul>
	</div>
</div>
</div>

<?php include './foot.php';?>
<script src="<?php echo $cdnpublic?>Chart.js/2.9.4/Chart.min.js"></script>
<script>
function generateLineChart(selector,labels,data,max,label,color){
	var lineChart = {
		labels: labels,
		datasets: [{
			label: label,
			fill: false,
			backgroundColor: color,
			borderColor: color,
			data: data
		}]
	};
	var lineOpts = {
		responsive: true,
		tooltips: {
			mode: 'index',
			intersect: false
		},
		hover: {
			mode: 'nearest',
			intersect: true
		},
		legend : {
			labels : {
				fontColor : '#8997bd'  
			}
		},
		scales: {
			xAxes: [{
				display: true,
				gridLines: {
					color: 'rgba(137, 151, 189, 0.15)',
				},
				ticks: {
					fontColor: '#8997bd'
				}
			}],
			yAxes: [{
				gridLines: {
					color: 'rgba(137, 151, 189, 0.15)',                      
				},
				ticks: {
					min: 0,
					max: max,
					fontColor: '#8997bd'
				}
			}]
		}
	};
	var ctx = selector.get(0).getContext("2d");
	new Chart(ctx, {type: 'line', data: lineChart, options: lineOpts});
}
$(document).ready(function(){
	$('#title').html('正在加载数据中...');
	$.ajax({
		type : "GET",
		url : "ajax.php?act=getcount",
		dataType : 'json',
		async: true,
		success : function(data) {
			$('#title').html('后台管理首页');
			$('#count1').html(data.count1);
			$('#count2').html(data.count2);
			$('#count3').html(data.count3);
			$('#count4').html(data.count4);
			generateLineChart($("#lineChart"),data.dates,data.logs,data.maxlogs,'请求次数','#4ac7ec');
			$.ajax({
				url: '<?php echo $checkupdate?>',
				type: 'get',
				dataType: 'jsonp',
				async: true,
				jsonpCallback: 'callback'
			}).done(function(data){
				$("#checkupdate").html(data.msg);
			})
		}
	});
})
</script>
<script>
function speedModeNotice(){
	var ua = window.navigator.userAgent;
	if(ua.indexOf('Windows NT')>-1 && ua.indexOf('Trident/')>-1){
		var html = "<div class=\"panel panel-default\"><div class=\"panel-body\">当前浏览器是兼容模式，为确保后台功能正常使用，请切换到<b style='color:#51b72f'>极速模式</b>！<br>操作方法：点击浏览器地址栏右侧的IE符号<b style='color:#51b72f;'><i class='fa fa-internet-explorer fa-fw'></i></b>→选择“<b style='color:#51b72f;'><i class='fa fa-flash fa-fw'></i></b><b style='color:#51b72f;'>极速模式</b>”</div></div>";
		$("#browser-notice").html(html)
	}
}
speedModeNotice();
</script>
</body>
</html>