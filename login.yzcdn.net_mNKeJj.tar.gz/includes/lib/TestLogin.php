<?php
namespace lib;

class TestLogin{
	private $appid;
	private $callback;
	private $connect;

	function __construct($config){
		global $siteurl;
		$this->appid = $config['appid'];
		$this->callback = $siteurl.'user/test.php';
		$this->connect = new \lib\Connect($this->appid);
	}

	//获取登录跳转url
	public function login($type){
		$state = md5(uniqid(rand(), TRUE));
		$_SESSION['Oauth_state'] = $state;
		return $this->connect->login($type, $this->callback, $state);
	}

	//登录成功返回网站
	public function callback(){
		return $this->connect->callback($_GET['code'], 1);
	}

	//查询用户信息
	public function query($type, $social_uid){
		return $this->connect->query($type, $social_uid);
	}
}
