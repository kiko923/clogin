<?php
namespace lib;

class Connect{
	private $appid;
	private $uid;

	function __construct($appid, $uid = 0){
		$this->appid = $appid;
		$this->uid = $uid;
	}

	//获取登录跳转url
	public function login($type, $redirect_uri, $state){
		global $DB;
		$typeinfo = $DB->getRow("select * from pre_type where name=:name limit 1", ["name"=>$type]);
		if($typeinfo['status']==0)return ['code'=>-1, 'errcode'=>104, 'msg'=>'当前登录方式未开启'];
		if(!$typeinfo || !$typeinfo['config'])return ['code'=>-1, 'errcode'=>104, 'msg'=>'当前登录方式未配置密钥'];
		$config = json_decode($typeinfo['config'], true);
	
		$code = strtoupper(md5(uniqid(rand(), TRUE)));
		$urlarr = parse_url($redirect_uri);
		$sds=$DB->exec("INSERT INTO `pre_logs` (`code`, `appid`, `uid`, `type`, `domain`, `redirect`, `state`, `addtime`, `status`) VALUES (:code, :appid, :uid, :type, :domain, :redirect, :state, NOW(), 0)", [':code'=>$code, ':appid'=>$this->appid, ':uid'=>$this->uid, ':type'=>$type, ':domain'=>$urlarr['host'], ':redirect'=>$redirect_uri, ':state'=>$state]);
		if($sds){
			$logid = $DB->lastInsertId();
			$state = authcode2($type.'||||'.$logid, 'ENCODE', SYS_KEY);
			
			try{
				if($typeinfo['third'] == 1){
					$x = new \lib\Third($config);
					$login_url = $x->login($state, $type);
				}else{
					$login_url = api_call($type, $config, 'login', [$state]);
				}
			}catch(\Exception $e){
				return ['code'=>-1, 'errcode'=>301, 'msg'=>$e->getMessage()];
			}
			if($login_url){
				$result = ['code'=>0, 'msg'=>'succ', 'type'=>$type, 'url'=>$login_url];
				if($type == 'wx' || $type == 'alipay') $result['qrcode'] = $login_url.'&client=1';
				return $result;
			}else{
				return ['code'=>-1, 'errcode'=>104, 'msg'=>'未知登录方式(type)'];
			}
		}else{
			return ['code'=>-1, 'errcode'=>201, 'msg'=>'数据库错误'.$DB->error()];
		}
	}

	//登录成功返回网站
	public function callback($code, $apptype){
		global $DB;
		$row = $DB->getRow("SELECT * FROM pre_logs WHERE appid=:appid AND code=:code ORDER BY id DESC LIMIT 1", [":code"=>$code, ":appid"=>$this->appid]);
		if(!$row)return ['code'=>-1, 'errcode'=>102, 'msg'=>'记录不存在'];
		if($row['status']==1){
			if(strtotime($row['endtime'])<time()-60)return ['code'=>-1, 'errcode'=>102, 'msg'=>'CODE已失效'];
			$account = $DB->getRow("SELECT * FROM pre_accounts WHERE appid=:appid AND type=:type AND openid=:openid ORDER BY id DESC LIMIT 1", [":appid"=>$this->appid, ":type"=>$row['type'], ":openid"=>$row['openid']]);
			$result = ['code'=>0, 'msg'=>'succ', 'type'=>$row['type'], 'access_token'=>$account['token'], 'social_uid'=>$account['openid'], 'faceimg'=>$account['faceimg'], 'nickname'=>$account['nickname'], 'location'=>$account['location'], 'gender'=>$account['gender'], 'ip'=>$row['ip']];
			return $result;
		}else{
			if(empty($row['ucode']))return ['code'=>2];

			$typeinfo = $DB->getRow("select * from pre_type where name=:name limit 1", ["name"=>$row['type']]);
			if($typeinfo['status']==0)return ['code'=>-1, 'errcode'=>104, 'msg'=>'当前登录方式未开启'];
			if(!$typeinfo || !$typeinfo['config'])return ['code'=>-1, 'errcode'=>104, 'msg'=>'当前登录方式未配置密钥'];
			$config = json_decode($typeinfo['config'], true);

			try{
				if($typeinfo['third'] == 1){
					$x = new \lib\Third($config);
					$res = $x->callback($row['ucode'], $row['type']);
				}else{
					$res = api_call($row['type'], $config, 'callback', [$row['ucode'], $apptype, $row['mode']]);
				}
			}catch(\Exception $e){
				return ['code'=>-1, 'errcode'=>301, 'msg'=>$e->getMessage()];
			}
			
			if($res){
				$result = ['code'=>0, 'msg'=>'succ', 'type'=>$row['type'], 'access_token'=>$res['access_token'], 'social_uid'=>$res['social_uid'], 'faceimg'=>$res['faceimg'], 'nickname'=>$res['nickname'], 'gender'=>$res['gender'], 'location'=>$res['location'], 'ip'=>$row['ip'], 'email'=>$row['email'], 'mobile'=>$row['mobile']];
			}else{
				return ['code'=>-1, 'errcode'=>104, 'msg'=>'未知登录方式(type)'];
			}

			$account = $DB->getRow("SELECT * FROM pre_accounts WHERE appid=:appid AND type=:type AND openid=:openid LIMIT 1", [":appid"=>$this->appid, ":type"=>$row['type'], ":openid"=>$result['social_uid']]);
			if($account){
				$DB->exec("UPDATE `pre_accounts` SET `token`=:token,`nickname`=:nickname,`faceimg`=:faceimg,`location`=:location,`gender`=:gender,`ip`=:ip,`lasttime`=NOW() WHERE id=:id", [':token'=>$result['access_token'], ':nickname'=>$result['nickname'], ':faceimg'=>$result['faceimg'], ':location'=>$result['location'], ':gender'=>$result['gender'], ':ip'=>$row['ip'], ':id'=>$account['id']]);
			}else{
				$DB->exec("INSERT INTO `pre_accounts` (`uid`, `appid`, `type`, `openid`, `token`, `nickname` ,`faceimg` ,`location` ,`gender` ,`ip`, `addtime`, `lasttime`, `status`) VALUES (:uid, :appid, :type, :openid, :token, :nickname, :faceimg, :location, :gender, :ip, NOW(), NOW(), 1)", [':uid'=>$this->uid, ':appid'=>$this->appid, ':type'=>$row['type'], ':openid'=>$result['social_uid'], ':token'=>$result['access_token'], ':nickname'=>$result['nickname'], ':faceimg'=>$result['faceimg'], ':location'=>$result['location'], ':gender'=>$result['gender'], ':ip'=>$row['ip']]);
			}

			$DB->exec("UPDATE `pre_logs` SET `openid`=:openid,`endtime`=NOW(),`status`=1 WHERE id=:id", [':openid'=>$result['social_uid'], ':id'=>$row['id']]);
			return $result;
		}
	}

	//查询用户信息
	public function query($type, $social_uid){
		global $DB;
		$row = $DB->getRow("SELECT * FROM pre_accounts WHERE appid=:appid AND type=:type AND openid=:openid LIMIT 1", [":appid"=>$this->appid, ":type"=>$type, ":openid"=>$social_uid]);
		if($row){
			$result=array("code"=>0,"msg"=>"succ","type"=>$row['type'],"social_uid"=>$row['openid'],"access_token"=>$row['token'],"nickname"=>$row['nickname'],"faceimg"=>$row['faceimg'],"location"=>$row['location'],"gender"=>$row['gender'],"ip"=>$row['ip']);
		}else{
			$result=array("code"=>-1,"msg"=>"none");
		}
		return $result;
	}
}
