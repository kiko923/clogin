<?php
include("../includes/common.php");
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");

$title='用户中心';
include './head.php';

if(strlen($userrow['phone'])==11){
	$userrow['phone']=substr($userrow['phone'],0,3).'****'.substr($userrow['phone'],7,10);
}

$list = $DB->getAll("SELECT * FROM pre_anounce WHERE status=1 ORDER BY sort ASC,id DESC");

if($userrow['gexpire']!=null && strtotime($userrow['gexpire'])<time()){
	$DB->exec("UPDATE pre_user SET gid=0,gexpire=NULL WHERE uid='$uid'");
	$userrow['gid']=0;
}

$group = $DB->getRow("SELECT * FROM pre_group WHERE gid='{$userrow['gid']}'");
$groupname = $group['name'] ? $group['name'] : '默认用户组';
$gexpire = $userrow['gexpire'] ? $userrow['gexpire'] : '永久';
$accountlimit = $group['ucount'] ? $group['ucount'].' 个' : '不限数量';
?>
<div class="container-fluid">
	<!-- Page-Title -->
	<div class="row">
		<div class="col-sm-12">
			<div class="page-title-box">
				<div class="float-right">
					<ol class="breadcrumb">
						<li class="breadcrumb-item active">用户中心</li>
					</ol>
				</div>
				<h4 class="page-title">用户中心</h4>
			</div><!--end page-title-box-->
		</div><!--end col-->
	</div>
	<!-- end page title end breadcrumb -->
	<div class="row">
		<div class="col-12">
			<div class="card">
				<div class="card-body  met-pro-bg">
					<div class="met-profile">
						<div class="row">
							<div class="col-lg-4 align-self-center mb-3 mb-lg-0">
								<div class="met-profile-main">
									<div class="met-profile-main-pic">
										<img src="<?php echo ($userrow['qq'])?'//q2.qlogo.cn/headimg_dl?bs=qq&dst_uin='.$userrow['qq'].'&src_uin='.$userrow['qq'].'&fid='.$userrow['qq'].'&spec=100&url_enc=0&referer=bu_interface&term_type=PC':'assets/images/user.png'?>" width="100" class="rounded-circle">
									</div>
									<div class="met-profile_user-detail">
										<h5 class="met-user-name">欢迎您，<?php echo $userrow['user']?></h5>                                                        
										<p class="mb-0 met-user-name-post">用户组：<a href="groupbuy.php" style="color:#a4abc5;"><?php echo $groupname?></a></p>
									</div>
								</div>                                                
							</div><!--end col-->
							<div class="col-lg-4 ml-auto">
								<ul class="list-unstyled personal-detail">
									<li><i class="fas fa-user-graduate fa-fw mr-2 text-info font-18"></i> <b> 用户组 </b> : <?php echo $groupname?></li>
									<li class="mt-2"><i class="fas fa-calendar-alt fa-fw text-info font-18 mt-2 mr-2"></i> <b> 到期时间 </b> : <?php echo $gexpire?></li>
									<li class="mt-2"><i class="fas fa-chevron-circle-up fa-fw text-info font-18 mt-2 mr-2"></i> <b> 账号数量上限 </b> : <?php echo $accountlimit?></li>
								</ul>
								<div class="button-list">                                                
									<button type="button" class="btn btn-info btn-round btn-sm" onclick="window.location.href='./groupbuy.php'" <?php if($conf['group_buy']==0){?>disabled<?php }?>><i class="fas fa-book"></i> 购买会员</button>
									<button type="button" class="btn btn-secondary btn-round btn-sm" onclick="window.location.href='userinfo.php'"><i class="fas fa-cog"></i> 个人资料</button>
								</div>
							</div><!--end col-->
						</div><!--end row-->
					</div><!--end f_profile-->                                                                                
				</div><!--end card-body-->
			</div><!--end card-->
		</div><!--end col-->
	</div><!--end row-->
	<div class="row">
		<div class="col-sm-6 col-md-3">
			<div class="card report-card">
				<div class="card-body">
					<div class="d-flex justify-content-between">
						<div>
							<p class="text-dark font-weight-semibold font-14">应用数量</p>
							<h3 class="my-3" id="count1">0</h3>
						</div>
						<div class="align-self-center">
							<i class="fas fa-cubes report-main-icon bg-soft-purple text-purple"></i>
						</div>
					</div>
				</div><!--end card-body--> 
			</div><!--end card--> 
		</div> <!--end col--> 
		<div class="col-sm-6 col-md-3">
			<div class="card report-card">
				<div class="card-body">
					<div class="d-flex justify-content-between">                                                
						<div>
							<p class="text-dark font-weight-semibold font-14">账号总数</p>
							<h3 class="my-3" id="count2">0</h3>
						</div>
						<div class="align-self-center">
							<i class="fas fa-user-friends report-main-icon bg-soft-danger text-danger"></i>
						</div> 
					</div>
				</div><!--end card-body--> 
			</div><!--end card--> 
		</div> <!--end col--> 
		<div class="col-sm-6 col-md-3">
			<div class="card report-card">
				<div class="card-body">
					<div class="d-flex justify-content-between">                                                
						<div>
							<p class="text-dark font-weight-semibold font-14">今日新增</p>
							<h3 class="my-3" id="count3">0</h3>
						</div>
						<div  class="align-self-center">
							<i class="fas fa-calendar-plus report-main-icon bg-soft-secondary text-secondary"></i>
						</div> 
					</div>
				</div><!--end card-body--> 
			</div><!--end card--> 
		</div> <!--end col--> 
		<div class="col-sm-6 col-md-3">
			<div class="card report-card">
				<div class="card-body">
					<div class="d-flex justify-content-between">
						<div>
							<p class="text-dark font-weight-semibold font-14">昨日新增</p>
							<h3 class="my-3" id="count4">0</h3>
						</div>
						<div class="align-self-center">
							<i class="far fa-calendar-plus report-main-icon bg-soft-warning text-warning"></i>
						</div> 
					</div>
				</div><!--end card-body--> 
			</div><!--end card--> 
		</div> <!--end col-->                               
	</div><!--end row--> 

	<div class="row">
		<div class="col-lg-6">
			<div class="card">
				<h5 class="card-header bg-primary text-white mt-0"><i class="far fa-chart-bar"></i>&nbsp;应用统计</h5>
				<div class="card-body">
					<div class="table-responsive browser_users">
						<table class="table mb-0">
							<thead class="thead-light">
								<tr>
									<th class="border-top-0">应用名称</th>
									<th class="border-top-0">应用状态</th>
									<th class="border-top-0">账号总数</th>
									<th class="border-top-0">登录次数</th>
								</tr><!--end tr-->
							</thead>
							<tbody id="applist">
							</tbody>
						</table> <!--end table-->                                               
					</div><!--end /div-->
				</div><!--end card-body-->
				<p class="card-footer bg-light m-0"><a href="apps.php">进入应用列表查看更多>></a></p>
			</div><!--end card-->
		</div><!--end col-->

		<div class="col-lg-6">
			<div class="card">
				<h5 class="card-header bg-secondary text-white mt-0"><i class="fas fa-volume-up"></i>&nbsp;公告通知</h5>
				<div class="card-body">
				<div class="list-group">
		<?php foreach($list as $row){?>
					<div class="list-group-item"><em class="fas fa-volume-up fa-fw"></em><font color="<?php echo $row['color']?$row['color']:null?>"><?php echo $row['content']?></font><span class="text-xs text-muted">&nbsp;-<?php echo $row['addtime']?></span></div>
		<?php }?>
				</div>
				</div><!--end card-body-->
			</div><!--end card-->
		</div><!--end col-->
	</div><!--end row--> 

</div><!-- container -->

<?php include 'foot.php';?>
<script>
$(document).ready(function(){
	$.ajax({
		type : "GET",
		url : "ajax2.php?act=getcount",
		dataType : 'json',
		async: true,
		success : function(data) {
			$('#count1').html(data.count1);
			$('#count2').html(data.count2);
			$('#count3').html(data.count3);
			$('#count4').html(data.count4);
			$.each(data.list, function(k,v){
				var status = '<i class="fas fa-cube mr-2 text-success font-16"></i>正常';
				if(v.status==0){
					status = '<i class="fas fa-cube mr-2 text-danger font-16"></i>关闭';
				}else if(v.status==2){
					status = '<i class="fas fa-cube mr-2 text-warning font-16"></i>待审核';
				}else if(v.status==3){
					status = '<i class="fas fa-cube mr-2 text-danger font-16"></i>未通过';
				}
				$("#applist").append('<tr><td>'+v.name+'</td><td>'+status+'</td><td>'+v.accounts+'</td><td>'+v.logs+'</td></tr>');
			})
		}
	});
});
</script>